# Gargul

## [v7.7.34](https://github.com/papa-smurf/Gargul/tree/v7.7.34) (2026-07-17)
[Full Changelog](https://github.com/papa-smurf/Gargul/compare/v7.7.33...v7.7.34) [Previous Releases](https://github.com/papa-smurf/Gargul/releases)

- Version v7.7.34  
- Clear loot priorities alongside TMB data when prios are identical to initial import  
- Sort item trade time by remaining seconds ASC > quality DESC > name (ASC) > itemGUID (ASC) so the order of items stays stable  
- Adjust roll button width to actual contents instead of strlen  
