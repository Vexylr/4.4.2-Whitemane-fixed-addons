--[[
  Whitemane Armory — datapack index, lookup, slash commands, public API
]]

local BRAND = WhitemaneArmory.BRAND
local DEFAULT_REALM = WhitemaneArmory.DEFAULT_REALM
local SEARCH_LIMIT = 10

local index -- lowercase key -> entry
local byName -- lowercase name -> best entry by ilvl
local keyByIndex -- lowercase key -> original key string
local nameKeys -- lowercase bare name -> list of { key, entry }
local indexCount = 0

local function DataPack()
  return WhitemaneArmory_DB
end

local function Trim(s)
  return (tostring(s or ""):match("^%s*(.-)%s*$")) or ""
end

local function NormalizeRealm(realm)
  realm = Trim(realm)
  if realm == "" then
    return DEFAULT_REALM
  end
  -- Collapse internal whitespace; keep a spaced form for display, nospace for keys.
  local spaced = realm:gsub("%s+", " ")
  local nospace = spaced:gsub("%s+", "")
  return spaced, nospace
end

local function StripRealm(name)
  if not name then
    return nil
  end
  name = Trim(name)
  if name == "" then
    return nil
  end
  -- Split on first dash (optional spaces around it).
  local bare = name:match("^([^-]-)%s*%-") or name:match("^([^-]+)")
  return Trim(bare or name)
end

local function BuildIndex()
  index, byName, keyByIndex, nameKeys = {}, {}, {}, {}
  indexCount = 0
  local db = DataPack()
  if not db or type(db.characters) ~= "table" then
    return 0
  end
  for key, entry in pairs(db.characters) do
    indexCount = indexCount + 1
    local keyStr = tostring(key)
    local lk = keyStr:lower()
    index[lk] = entry
    keyByIndex[lk] = keyStr

    -- Also index realm with spaces stripped (e.g. Area52 vs Area 52).
    local bare, realmPart = keyStr:match("^([^-]+)%-(.+)$")
    if bare and realmPart then
      local nospace = realmPart:gsub("%s+", "")
      if nospace ~= realmPart then
        local alt = (bare .. "-" .. nospace):lower()
        if not index[alt] then
          index[alt] = entry
          keyByIndex[alt] = keyStr
        end
      end
    end

    local bareLower = StripRealm(keyStr):lower()
    local prev = byName[bareLower]
    if not prev or (tonumber(entry.ilvl) or 0) >= (tonumber(prev.ilvl) or 0) then
      byName[bareLower] = entry
    end

    local list = nameKeys[bareLower]
    if not list then
      list = {}
      nameKeys[bareLower] = list
    end
    list[#list + 1] = { key = keyStr, entry = entry }
  end
  return indexCount
end

local function Lookup(name, realm)
  if not index then
    BuildIndex()
  end
  name = Trim(name)
  if name == "" then
    return nil, nil
  end

  local bare = name
  local realmPart = realm
  -- Name-Realm or Name - Realm embedded in the name argument.
  local embeddedBare, embeddedRealm = name:match("^([^-]-)%s*%-%s*(.+)$")
  if embeddedBare and embeddedRealm then
    bare = Trim(embeddedBare)
    realmPart = Trim(embeddedRealm)
  else
    bare = StripRealm(name) or name
  end

  local spaced, nospace = NormalizeRealm(realmPart)
  realmPart = spaced

  local function tryKey(b, r)
    local lk = (b .. "-" .. r):lower()
    local entry = index[lk]
    if entry then
      return entry, keyByIndex[lk] or (b .. "-" .. r)
    end
    return nil
  end

  local entry, key = tryKey(bare, realmPart)
  if entry then
    return entry, key
  end

  if nospace and nospace ~= realmPart then
    entry, key = tryKey(bare, nospace)
    if entry then
      return entry, key
    end
  end

  -- Case-insensitive bare-name fallback (highest ilvl).
  entry = byName[bare:lower()]
  if entry then
    local list = nameKeys[bare:lower()]
    local display = (list and list[1] and list[1].key) or (bare .. "-" .. DEFAULT_REALM)
    -- Prefer the matching highest-ilvl key for display.
    if list then
      local bestIlvl, bestKey = -1, display
      for i = 1, #list do
        local e = list[i].entry
        local il = tonumber(e and e.ilvl) or 0
        if e == entry and il >= bestIlvl then
          bestIlvl, bestKey = il, list[i].key
        end
      end
      display = bestKey
    end
    return entry, display
  end

  return nil, bare .. "-" .. realmPart
end

local function CountDB()
  if not index then
    return BuildIndex()
  end
  return indexCount
end

--- Parse "Name", "Name-Realm", "Name - Realm" (spaces ok).
local function ParseNameRealm(arg)
  arg = Trim(arg)
  if arg == "" then
    return nil, nil
  end
  local bare, realm = arg:match("^([^-]-)%s*%-%s*(.+)$")
  if bare then
    bare = Trim(bare)
    realm = Trim(realm)
    if bare ~= "" then
      local spaced = NormalizeRealm(realm)
      return bare, spaced
    end
  end
  return arg, GetRealmName() or DEFAULT_REALM
end

local function PrintChatBlock(entry, indent)
  indent = indent or "  "
  if WhitemaneArmory.FormatChatBlock then
    for line in string.gmatch(WhitemaneArmory.FormatChatBlock(entry), "[^\n]+") do
      print(indent .. line)
    end
  else
    print(indent .. ("ilvl %s"):format(tostring(entry.ilvl or 0)))
  end
end

local function PrintHelp()
  WhitemaneArmory.Print("commands:")
  print("  /warmory help                     — this list")
  print("  /warmory lookup Name[-Realm]      — full progress block")
  print("  /warmory who|search <partial>     — top " .. SEARCH_LIMIT .. " name matches by ilvl")
  print("  /warmory armory Name[-Realm]      — open/copy armory (or current target)")
  print("  /warmory stats|debug              — datapack info + sample keys")
  print("  /warmory config|options           — open options panel")
  print("  /warmory tooltip | ilvl | mod | armorybtn|menu | spec | loginmsg|login")
  print("  /warmory mod none|shift|alt|ctrl  — require modifier for tip panel")
  print("  /warmory <Name[-Realm]>           — shorthand for lookup")
  print("  Names: Vex, Vex-Gilneas, or Vex - Gilneas")
end

local function PrintInfo()
  local db = DataPack()
  if not db then
    WhitemaneArmory.Print("no datapack loaded")
    return
  end
  WhitemaneArmory.Print(("addon %s | datapack %s | updated %s | %d characters"):format(
    tostring(WhitemaneArmory.VERSION or "?"),
    tostring(db.version or "?"),
    tostring(db.updated or "?"),
    CountDB()
  ))
  WhitemaneArmory.Print("realm: " .. tostring(GetRealmName() or "?"))
  WhitemaneArmory.Print("type /warmory help for commands")
end

local function SlashLookup(arg)
  local name, realm = ParseNameRealm(arg)
  if not name then
    WhitemaneArmory.Print("usage: /warmory lookup Name[-Realm]")
    return
  end
  local entry, key = Lookup(name, realm)
  if not entry then
    WhitemaneArmory.Print("[" .. (key or arg) .. "] no data in datapack")
    return
  end
  local class = entry.class and tostring(entry.class) or nil
  local header = "[" .. key .. "]"
  if class and class ~= "" then
    header = header .. " " .. class
  end
  WhitemaneArmory.Print(header)
  PrintChatBlock(entry, "  ")
  local url = WhitemaneArmory.ArmoryURL(name, realm)
  if url then
    print("  |cff66ccff" .. url .. "|r")
  end
end

local function SlashSearch(arg)
  arg = Trim(arg)
  if arg == "" then
    WhitemaneArmory.Print("usage: /warmory who|search <partial name>")
    return
  end
  if not index then
    BuildIndex()
  end

  local needle = arg:lower()
  -- If user passed Name-Realm, search the bare name only.
  local bareNeedle = StripRealm(arg)
  if bareNeedle then
    needle = bareNeedle:lower()
  end

  local hits = {}
  local seen = {}
  for bare, list in pairs(nameKeys) do
    if bare:find(needle, 1, true) then
      for i = 1, #list do
        local item = list[i]
        local k = item.key
        if not seen[k] then
          seen[k] = true
          hits[#hits + 1] = {
            key = k,
            entry = item.entry,
            ilvl = tonumber(item.entry and item.entry.ilvl) or 0,
          }
        end
      end
    end
  end

  table.sort(hits, function(a, b)
    if a.ilvl ~= b.ilvl then
      return a.ilvl > b.ilvl
    end
    return a.key:lower() < b.key:lower()
  end)

  local n = math.min(SEARCH_LIMIT, #hits)
  if n == 0 then
    WhitemaneArmory.Print("no matches for \"" .. arg .. "\"")
    return
  end

  WhitemaneArmory.Print(("who \"%s\" — %d shown / %d match"):format(arg, n, #hits))
  for i = 1, n do
    local h = hits[i]
    local e = h.entry
    local class = (e and e.class) and tostring(e.class) or "?"
    local spec = WhitemaneArmory.SpecOnly and WhitemaneArmory.SpecOnly(e)
    local extra = spec and (" · " .. spec) or ""
    print(("  %2d. %s  ilvl %s  %s%s"):format(i, h.key, tostring(h.ilvl), class, extra))
  end
  if #hits > n then
    print(("  … +%d more (narrow the name)"):format(#hits - n))
  end
end

local function SlashArmory(arg)
  local name, realm = ParseNameRealm(arg)
  if not name then
    local n, r = UnitName("target")
    if n and UnitIsPlayer("target") then
      name, realm = n, (r and r ~= "" and r) or GetRealmName() or DEFAULT_REALM
    else
      WhitemaneArmory.Print("usage: /warmory armory Name[-Realm]  (or target a player)")
      return
    end
  end
  if WhitemaneArmory.OpenArmory then
    WhitemaneArmory.OpenArmory(name, realm)
  else
    WhitemaneArmory.Print(WhitemaneArmory.ArmoryURL(name, realm) or "invalid name")
  end
end

SLASH_WHITEMANEARMORY1 = "/warmory"
SLASH_WHITEMANEARMORY2 = "/whitemanearmory"
SlashCmdList.WHITEMANEARMORY = function(msg)
  msg = Trim(msg)
  if msg == "" then
    PrintInfo()
    return
  end
  local cmd, rest = msg:match("^(%S+)%s*(.-)$")
  cmd = cmd and cmd:lower() or ""
  rest = Trim(rest)

  if cmd == "help" or cmd == "?" then
    PrintHelp()
  elseif cmd == "lookup" or cmd == "l" then
    SlashLookup(rest)
  elseif cmd == "who" or cmd == "search" or cmd == "find" then
    SlashSearch(rest)
  elseif cmd == "armory" then
    SlashArmory(rest)
  elseif cmd == "stats" or cmd == "debug" then
    PrintInfo()
    local i = 0
    for key in pairs((DataPack() and DataPack().characters) or {}) do
      i = i + 1
      if i <= 8 then
        print("  · " .. tostring(key))
      end
    end
    if i > 8 then
      print(("  … +%d more"):format(i - 8))
    end
  elseif cmd == "config" or cmd == "options" then
    WhitemaneArmory.SlashConfig()
  elseif cmd == "tooltip" then
    local v = WhitemaneArmory.ToggleOption("showTooltip")
    WhitemaneArmory.Print("tooltips " .. (v and "on" or "off"))
  elseif cmd == "ilvl" then
    local v = WhitemaneArmory.ToggleOption("showIlvl")
    WhitemaneArmory.Print("tooltip ilvl " .. (v and "on" or "off"))
  elseif cmd == "mod" or cmd == "modifier" then
    local arg = Trim(rest or ""):upper()
    if arg == "" or arg == "STATUS" then
      WhitemaneArmory.Print("tooltip modifier: " .. tostring(WhitemaneArmory.GetOption("tooltipModifier") or "NONE"))
      return
    end
    if arg == "NONE" or arg == "OFF" or arg == "ALWAYS" then
      arg = "NONE"
    elseif arg == "CONTROL" then
      arg = "CTRL"
    end
    if arg ~= "NONE" and arg ~= "SHIFT" and arg ~= "ALT" and arg ~= "CTRL" then
      WhitemaneArmory.Print("usage: /warmory mod none|shift|alt|ctrl")
      return
    end
    WhitemaneArmory.SetOption("tooltipModifier", arg)
    WhitemaneArmory.Print("tooltip modifier: " .. arg)
  elseif cmd == "armorybtn" or cmd == "menu" then
    local v = WhitemaneArmory.ToggleOption("showArmoryButton")
    WhitemaneArmory.Print("armory menu button " .. (v and "on" or "off"))
    if WhitemaneArmory.RefreshArmoryMenus then
      WhitemaneArmory.RefreshArmoryMenus()
    end
  elseif cmd == "spec" then
    local v = WhitemaneArmory.ToggleOption("showSpec")
    WhitemaneArmory.Print("spec line " .. (v and "on" or "off"))
  elseif cmd == "loginmsg" or cmd == "login" then
    local v = WhitemaneArmory.ToggleOption("printOnLogin")
    WhitemaneArmory.Print("login message " .. (v and "on" or "off"))
  else
    -- Shorthand: /warmory Name[-Realm]
    SlashLookup(msg)
  end
end

WhitemaneArmory.Lookup = Lookup
WhitemaneArmory.BuildIndex = BuildIndex
WhitemaneArmory.CountDB = CountDB
WhitemaneArmory.StripRealm = StripRealm
WhitemaneArmory.ParseNameRealm = ParseNameRealm
WhitemaneArmory.NormalizeRealm = NormalizeRealm
WhitemaneArmory.DataPack = DataPack
WhitemaneArmory.DEFAULT_REALM = DEFAULT_REALM
WhitemaneArmory.BRAND = BRAND

local f = CreateFrame("Frame")
f:RegisterEvent("ADDON_LOADED")
f:RegisterEvent("PLAYER_LOGIN")
f:SetScript("OnEvent", function(_, event, name)
  if event == "ADDON_LOADED" and name == "WhitemaneArmory" then
    WhitemaneArmory.GetDB()
  elseif event == "PLAYER_LOGIN" then
    local n = BuildIndex()
    local db = DataPack()
    if not db or type(db.characters) ~= "table" then
      WhitemaneArmory.Print("|cffff6666no datapack loaded.|r Enable/replace |cff66ccffWhitemaneArmory_Data|r in Interface\\AddOns, then /reload.")
      return
    end
    if WhitemaneArmory.GetOption("printOnLogin") then
      WhitemaneArmory.Print(("loaded (%s, updated %s, %d chars)"):format(
        tostring(db.version or "?"),
        tostring(db.updated or "?"),
        n
      ))
    end
  end
end)
