--[[
  Whitemane Armory — tooltip progress panel
  Grid layout: Raid | Normal | (drawn divider) | Heroic
]]

local BRAND = WhitemaneArmory.BRAND

local C = {
  brand  = { 0.42, 0.82, 1.00 },
  ilvl   = { 0.72, 0.74, 0.80 },
  header = { 0.46, 0.56, 0.66 },
  raid   = { 0.68, 0.82, 0.96 },
  value  = { 0.88, 0.88, 0.90 },
  clear  = { 0.52, 0.78, 0.58 }, -- full clear: soft green tint
  zero   = { 0.46, 0.48, 0.52 }, -- 0/x: muted
  muted  = { 0.40, 0.40, 0.46 },
  spec   = { 0.56, 0.62, 0.70 },
  line   = { 0.40, 0.80, 1.00, 0.30 },
}

local PAD_X = 6
local PAD_Y = 5
local ROW_GAP = 3
local COL_GAP = 14
local SECTION_GAP = 4 -- brand → ilvl → grid breathing room
local TIP_INSET = 4
local TIP_GAP = 2
local TIP_WIDTH_PAD = 4 -- tip chrome beyond panel (keep small for TipTac/ElvUI)
local MAX_RAIDS = 4
local SPACER_LINE_H = 14 -- GameTooltip line height used to reserve panel space

local RAIDS = {
  { tag = "BWD",   split = true,  fallbackN = "0/6", fallbackH = "0/6" },
  -- BOT Heroic includes Sinestra → always /5
  { tag = "BOT",   split = true,  fallbackN = "0/4", fallbackH = "0/5" },
  { tag = "TOT4W", split = true,  fallbackN = "0/2", fallbackH = "0/2" },
  { tag = "BH",    split = false, fallbackN = "0/3", fallbackH = nil },
}

local CLASS_NAMES = {
  "Death Knight", "Demon Hunter", "Warrior", "Paladin", "Hunter",
  "Rogue", "Priest", "Shaman", "Mage", "Warlock", "Monk", "Druid",
}

local function SpecOnly(entry)
  local spec = entry and entry.spec
  if not spec or spec == "" or spec == "Unknown" or spec == "-" then
    return nil
  end
  spec = tostring(spec):match("^%s*(.-)%s*$") or ""
  if spec == "" or spec == "Unknown" then
    return nil
  end

  local class = entry.class and tostring(entry.class) or nil
  if class and class ~= "" then
    if spec:lower() == class:lower() then
      return nil
    end
    local stripped = spec:match("^" .. class .. "%s*%-?%s*(.+)$")
      or spec:match("^(.+)%s*%-?%s*" .. class .. "$")
    if stripped then
      stripped = stripped:match("^%s*(.-)%s*$")
      if stripped and stripped ~= "" and stripped:lower() ~= "unknown" then
        return stripped
      end
      return nil
    end
  end

  for _, cn in ipairs(CLASS_NAMES) do
    local stripped = spec:match("^" .. cn .. "%s*%-?%s*(.+)$")
      or spec:match("^(.+)%s*%-?%s*" .. cn .. "$")
    if stripped then
      stripped = stripped:match("^%s*(.-)%s*$")
      if stripped and stripped ~= "" and stripped:lower() ~= "unknown" then
        return stripped
      end
    end
  end

  return spec
end

local function TooltipsEnabled()
  if WhitemaneArmory.GetOption then
    return WhitemaneArmory.GetOption("showTooltip") ~= false
  end
  return true
end

local function ShowIlvlEnabled()
  if WhitemaneArmory.GetOption then
    return WhitemaneArmory.GetOption("showIlvl") ~= false
  end
  return true
end

-- "NONE" | "SHIFT" | "ALT" | "CTRL"
local function ModifierOk()
  local mod = "NONE"
  if WhitemaneArmory.GetOption then
    mod = tostring(WhitemaneArmory.GetOption("tooltipModifier") or "NONE"):upper()
  end
  if mod == "" or mod == "NONE" or mod == "ALWAYS" then
    return true
  end
  if mod == "SHIFT" then
    return IsShiftKeyDown and IsShiftKeyDown()
  end
  if mod == "ALT" then
    return IsAltKeyDown and IsAltKeyDown()
  end
  if mod == "CTRL" or mod == "CONTROL" then
    return IsControlKeyDown and IsControlKeyDown()
  end
  return true
end

local function TipBgColor()
  local r, g, b, a = 0.035, 0.06, 0.10, 0.96
  if WhitemaneArmory.GetOption then
    r = tonumber(WhitemaneArmory.GetOption("tipBgR")) or r
    g = tonumber(WhitemaneArmory.GetOption("tipBgG")) or g
    b = tonumber(WhitemaneArmory.GetOption("tipBgB")) or b
    a = tonumber(WhitemaneArmory.GetOption("tipBgA")) or a
  end
  return r, g, b, a
end

local function ParseBody(body, split)
  body = tostring(body or ""):match("^%s*(.-)%s*$") or ""
  if body == "" or body == "-" then
    if split then
      return "0/0", "0/0"
    end
    return "0/0", nil
  end

  -- Current: "6/6 N | 1/6 H"
  local n, h = body:match("([%d]+/[%d]+)%s*N%s*|%s*([%d]+/[%d]+)%s*H")
  if n and h then
    return n, h
  end

  -- Legacy: "1/6 H | 6/6 N" / "1/6 HC | 6/6 N"
  h, n = body:match("([%d]+/[%d]+)%s*HC?%s*|%s*([%d]+/[%d]+)%s*N")
  if n and h then
    return n, h
  end

  local single = body:match("([%d]+/[%d]+)")
  if split then
    return single or "0/0", "0/0"
  end
  return single or "0/0", nil
end

local function ParseRaidRows(progress)
  local byTag = {}
  if type(progress) == "string" and progress ~= "" and progress ~= "-" then
    for line in string.gmatch(progress, "[^\n]+") do
      local tag, rest = line:match("^(%S+)%s*%-%s*(.+)$")
      if not tag then
        tag, rest = line:match("^(%S+)%s+(.+)$")
      end
      if tag and rest then
        byTag[tag:upper()] = rest:match("^%s*(.-)%s*$")
      end
    end
  end

  local rows = {}
  for _, def in ipairs(RAIDS) do
    local body = byTag[def.tag] or (def.split
      and (def.fallbackN .. " N | " .. def.fallbackH .. " H")
      or def.fallbackN)
    local n, h = ParseBody(body, def.split)
    if not def.split then
      h = nil
    end
    rows[#rows + 1] = {
      tag = def.tag,
      n = n or def.fallbackN,
      h = h, -- nil for BH
    }
  end
  return rows
end

-- Legacy chat/export helper (plain text).
local function ParseProgressLines(progress)
  local lines = {}
  for _, row in ipairs(ParseRaidRows(progress)) do
    if row.h then
      lines[#lines + 1] = ("%s  %s N | %s H"):format(row.tag, row.n, row.h)
    else
      lines[#lines + 1] = ("%s  %s"):format(row.tag, row.n)
    end
  end
  return lines
end

local function ApplyBackdrop(frame)
  local backdrop = {
    bgFile = "Interface\\Buttons\\WHITE8x8",
    edgeFile = "Interface\\Buttons\\WHITE8x8",
    edgeSize = 1,
    insets = { left = 1, right = 1, top = 1, bottom = 1 },
  }
  local r, g, b, a = TipBgColor()
  if frame.SetBackdrop then
    frame:SetBackdrop(backdrop)
    frame:SetBackdropColor(r, g, b, a)
    frame:SetBackdropBorderColor(0.40, 0.80, 1.00, 0.72)
    return
  end
  if not frame.bg then
    frame.bg = frame:CreateTexture(nil, "BACKGROUND")
    frame.bg:SetAllPoints()
  end
  frame.bg:SetColorTexture(r, g, b, a)
end

function WhitemaneArmory.RefreshTooltipStyle()
  if GameTooltip and GameTooltip.WhitemaneArmoryPanel then
    ApplyBackdrop(GameTooltip.WhitemaneArmoryPanel)
  end
end

local function MakeFS(parent, justify)
  local fs = parent:CreateFontString(nil, "OVERLAY", "GameTooltipText")
  fs:SetJustifyH(justify or "LEFT")
  fs:SetWordWrap(false)
  fs:Hide()
  return fs
end

local function EnsurePanel(tooltip)
  local panel = tooltip.WhitemaneArmoryPanel
  if panel then
    return panel
  end

  panel = CreateFrame("Frame", nil, tooltip)
  panel:SetFrameStrata(tooltip:GetFrameStrata() or "TOOLTIP")
  panel:Hide()
  ApplyBackdrop(panel)

  panel.brand = MakeFS(panel, "LEFT")
  panel.ilvl = MakeFS(panel, "LEFT")
  panel.spec = MakeFS(panel, "LEFT")

  panel.hdrN = MakeFS(panel, "CENTER")
  panel.hdrH = MakeFS(panel, "CENTER")

  -- Horizontal rule under header labels.
  panel.rule = panel:CreateTexture(nil, "ARTWORK")
  panel.rule:SetColorTexture(C.line[1], C.line[2], C.line[3], C.line[4])
  panel.rule:SetHeight(1)
  panel.rule:Hide()

  -- Vertical divider between Normal / Heroic.
  panel.vdiv = panel:CreateTexture(nil, "ARTWORK")
  panel.vdiv:SetColorTexture(C.line[1], C.line[2], C.line[3], C.line[4])
  panel.vdiv:SetWidth(1)
  panel.vdiv:Hide()

  panel.rows = {}
  for i = 1, MAX_RAIDS do
    panel.rows[i] = {
      tag = MakeFS(panel, "LEFT"),
      n = MakeFS(panel, "CENTER"),
      h = MakeFS(panel, "CENTER"),
    }
  end

  tooltip.WhitemaneArmoryPanel = panel
  return panel
end

local function HidePanel(tooltip)
  local panel = tooltip and tooltip.WhitemaneArmoryPanel
  if panel then
    panel:Hide()
    panel._warmoryShown = nil
    panel._warmorySpacers = nil
    panel._warmoryTipW = nil
    panel._warmoryAnchor = nil
    panel._warmoryHeight = nil
    panel._warmoryWidth = nil
  end
end

local function SetFS(fs, text, color)
  if not text or text == "" then
    fs:Hide()
    fs:SetText("")
    return 0, 0
  end
  fs:SetText(text)
  fs:SetTextColor(color[1], color[2], color[3])
  fs:Show()
  return fs:GetStringWidth() or 0, fs:GetStringHeight() or 12
end

-- Subtle progress tint: full clear slightly brighter/green; zeros muted.
local function ProgressColor(frac)
  if not frac or frac == "" or frac == "-" or frac == "—" then
    return C.muted
  end
  local a, b = tostring(frac):match("^(%d+)/(%d+)$")
  if not a then
    return C.value
  end
  a, b = tonumber(a), tonumber(b)
  if not a or not b or b <= 0 then
    return C.value
  end
  if a <= 0 then
    return C.zero
  end
  if a >= b then
    return C.clear
  end
  return C.value
end

-- availW: current tip content width (optional). When the tip is already wider
-- (ElvUI/TipTac), fill it so N/H sit in real columns instead of a left clump.
local function LayoutPanel(panel, entry, availW)
  local raidRows = ParseRaidRows(entry.progress)
  local spec
  if not WhitemaneArmory.GetOption or WhitemaneArmory.GetOption("showSpec") ~= false then
    spec = SpecOnly(entry)
  end

  -- Measure column widths from content.
  local tagW, nW, hW = 0, 0, 0
  local hdrH = 12
  do
    local tw = SetFS(panel.hdrN, "N", C.header)
    nW = math.max(nW, tw)
    tw = SetFS(panel.hdrH, "H", C.header)
    hW = math.max(hW, tw)
  end

  for i = 1, MAX_RAIDS do
    local row = panel.rows[i]
    local data = raidRows[i]
    if data then
      local tw = SetFS(row.tag, data.tag, C.raid)
      tagW = math.max(tagW, tw)
      tw = SetFS(row.n, data.n, ProgressColor(data.n))
      nW = math.max(nW, tw)
      if data.h then
        tw = SetFS(row.h, data.h, ProgressColor(data.h))
        hW = math.max(hW, tw)
      else
        SetFS(row.h, "-", C.muted)
        hW = math.max(hW, row.h:GetStringWidth() or 8)
      end
    else
      SetFS(row.tag, nil)
      SetFS(row.n, nil)
      SetFS(row.h, nil)
    end
  end

  -- Minimum column widths so short tips still look like a table.
  tagW = math.max(tagW, 48)
  nW = math.max(nW, 36)
  hW = math.max(hW, 36)

  local colTag = PAD_X
  local colN = colTag + tagW + COL_GAP
  local colDiv = colN + nW + COL_GAP * 0.5
  local colH = colDiv + 1 + COL_GAP * 0.5
  local contentW = colH + hW + PAD_X

  -- Brand / ilvl / spec can be wider than the raid grid.
  local _, bh = SetFS(panel.brand, BRAND, C.brand)
  local textW = panel.brand:GetStringWidth() or 0
  if ShowIlvlEnabled() then
    SetFS(panel.ilvl, ("ilvl %s"):format(tostring(entry.ilvl or 0)), C.ilvl)
    textW = math.max(textW, panel.ilvl:GetStringWidth() or 0)
  else
    SetFS(panel.ilvl, nil)
  end
  if spec then
    SetFS(panel.spec, spec, C.spec)
    textW = math.max(textW, panel.spec:GetStringWidth() or 0)
  else
    SetFS(panel.spec, nil)
  end
  contentW = math.max(contentW, textW + PAD_X * 2)

  local minW = tonumber(WhitemaneArmory.GetOption and WhitemaneArmory.GetOption("minTipWidth")) or 0
  if minW > 0 then
    contentW = math.max(contentW, minW)
  end

  -- Stretch columns across the live tip width so wide skins don't leave a gutter.
  if availW and availW > contentW + 1 then
    local extra = availW - contentW
    colN = colN + extra
    colDiv = colDiv + extra
    colH = colH + extra
    contentW = availW
  end

  local y = -PAD_Y

  -- Brand (top of hierarchy)
  panel.brand:ClearAllPoints()
  panel.brand:SetPoint("TOPLEFT", panel, "TOPLEFT", PAD_X, y)
  y = y - (bh + 2)

  -- ilvl (optional — hide when another addon already shows live ilvl)
  if panel.ilvl:IsShown() then
    local ih = panel.ilvl:GetStringHeight() or 12
    panel.ilvl:ClearAllPoints()
    panel.ilvl:SetPoint("TOPLEFT", panel, "TOPLEFT", PAD_X, y)
    y = y - (ih + SECTION_GAP)
  else
    y = y - 2
  end

  -- Column headers N / H (muted labels), centered in their value columns
  panel.hdrN:ClearAllPoints()
  panel.hdrN:SetPoint("TOPLEFT", panel, "TOPLEFT", colN, y)
  panel.hdrN:SetWidth(nW)
  panel.hdrH:ClearAllPoints()
  panel.hdrH:SetPoint("TOPLEFT", panel, "TOPLEFT", colH, y)
  panel.hdrH:SetWidth(hW)
  hdrH = math.max(panel.hdrN:GetStringHeight() or 12, panel.hdrH:GetStringHeight() or 12)
  y = y - (hdrH + 2)

  -- Rule under headers
  panel.rule:ClearAllPoints()
  panel.rule:SetPoint("TOPLEFT", panel, "TOPLEFT", PAD_X, y)
  panel.rule:SetPoint("TOPRIGHT", panel, "TOPRIGHT", -PAD_X, y)
  panel.rule:SetColorTexture(C.line[1], C.line[2], C.line[3], C.line[4])
  panel.rule:Show()
  y = y - 4

  local gridTop = y
  local rowH = 12

  for i = 1, MAX_RAIDS do
    local row = panel.rows[i]
    local data = raidRows[i]
    if data then
      row.tag:ClearAllPoints()
      row.tag:SetPoint("TOPLEFT", panel, "TOPLEFT", colTag, y)
      row.tag:SetWidth(tagW)

      row.n:ClearAllPoints()
      row.n:SetPoint("TOPLEFT", panel, "TOPLEFT", colN, y)
      row.n:SetWidth(nW)

      row.h:ClearAllPoints()
      row.h:SetPoint("TOPLEFT", panel, "TOPLEFT", colH, y)
      row.h:SetWidth(hW)

      rowH = math.max(
        row.tag:GetStringHeight() or 12,
        row.n:GetStringHeight() or 12,
        row.h:GetStringHeight() or 12
      )
      y = y - (rowH + ROW_GAP)
    end
  end

  local gridBottom = y + ROW_GAP

  -- Vertical divider through the raid grid only (between N and H).
  panel.vdiv:ClearAllPoints()
  panel.vdiv:SetPoint("TOPLEFT", panel, "TOPLEFT", colDiv, gridTop)
  panel.vdiv:SetPoint("BOTTOMLEFT", panel, "TOPLEFT", colDiv, gridBottom)
  panel.vdiv:SetColorTexture(C.line[1], C.line[2], C.line[3], C.line[4])
  panel.vdiv:Show()

  if panel.spec:IsShown() then
    y = y - SECTION_GAP + 2
    local sh = panel.spec:GetStringHeight() or 12
    panel.spec:ClearAllPoints()
    panel.spec:SetPoint("TOPLEFT", panel, "TOPLEFT", PAD_X, y)
    y = y - (sh + 2)
  end

  local height = (-y) + PAD_Y
  panel._contentW = contentW
  panel:SetWidth(panel._contentW)
  panel:SetHeight(height)
  return panel._contentW, height
end

local function LastFilledLine(tooltip)
  local tipName = tooltip.GetName and tooltip:GetName()
  if not tipName then
    return nil
  end
  for i = tooltip:NumLines() or 0, 1, -1 do
    local fs = _G[tipName .. "TextLeft" .. i]
    local text = fs and fs:GetText()
    if fs and text and text:match("%S") then
      return fs
    end
  end
  return nil
end

-- Only widen the tip if our panel would clip. Never grow past content need.
local function EnsureTipFitsPanel(tooltip, needW)
  if not tooltip or not needW then
    return
  end
  local cur = tooltip:GetWidth() or 0
  if cur >= needW - 1 then
    return
  end
  if tooltip.SetMinimumWidth then
    tooltip:SetMinimumWidth(needW)
  end
  if tooltip.SetWidth then
    tooltip:SetWidth(needW)
  end
end

local function PlacePanel(tooltip, panel, width, height, anchor)
  panel:SetParent(tooltip)
  panel:SetFrameStrata(tooltip:GetFrameStrata() or "TOOLTIP")
  panel:SetFrameLevel((tooltip:GetFrameLevel() or 1) + 20)
  panel:ClearAllPoints()
  -- Content width from LayoutPanel (may fill an already-wide tip).
  panel:SetWidth(width)
  panel:SetHeight(height)
  panel:SetPoint("LEFT", tooltip, "LEFT", TIP_INSET, 0)
  if anchor then
    panel:SetPoint("TOP", anchor, "BOTTOM", 0, -TIP_GAP)
  else
    panel:SetPoint("TOPLEFT", tooltip, "TOPLEFT", TIP_INSET, -36)
  end
  panel:Show()
end

local function HookTipResize(tooltip, panel)
  if panel._warmorySizeHooked then
    return
  end
  panel._warmorySizeHooked = true
  tooltip:HookScript("OnSizeChanged", function(self, w)
    if not panel._warmoryShown or panel._warmoryResizing then
      return
    end
    local need = panel._warmoryTipW
    if not need or (w or 0) >= (need - 1) then
      return
    end
    panel._warmoryResizing = true
    EnsureTipFitsPanel(self, need)
    PlacePanel(
      self,
      panel,
      panel._warmoryWidth or need,
      panel._warmoryHeight or panel:GetHeight(),
      panel._warmoryAnchor
    )
    panel._warmoryResizing = nil
  end)
end

local function ShowPanel(tooltip, entry)
  local panel = EnsurePanel(tooltip)
  ApplyBackdrop(panel)

  -- Measure natural tip width BEFORE we add spacer lines / inflate.
  local tipWBefore = tooltip:GetWidth() or 0
  local availW = tipWBefore - (TIP_INSET * 2)
  if availW < 80 then
    availW = nil
  end

  local contentW, height = LayoutPanel(panel, entry, availW)
  local anchor = LastFilledLine(tooltip)

  -- Fit the tip to the panel only when the panel is actually wider.
  -- If we only stretched columns to fill an already-wide tip (ElvUI), do not
  -- bump SetMinimumWidth or the tip grows a few px every modifier toggle.
  local panelNeed = (contentW or 0) + (TIP_INSET * 2)
  local needW
  if tipWBefore >= panelNeed - 1 then
    needW = tipWBefore
  else
    needW = panelNeed + TIP_WIDTH_PAD
  end

  HookTipResize(tooltip, panel)

  if needW > tipWBefore + 1 then
    EnsureTipFitsPanel(tooltip, needW)
  end

  -- Reserve vertical space once per tip generation. Re-adding on every modifier
  -- toggle is what made the tip grow forever (spacers stayed after HidePanel).
  if not panel._warmorySpacers then
    local need = math.max(1, math.ceil((height + TIP_GAP + 2) / SPACER_LINE_H))
    for _ = 1, need do
      tooltip:AddLine(" ")
    end
    panel._warmorySpacers = need
    tooltip:Show()
  end

  if needW > (tooltip:GetWidth() or 0) + 1 then
    EnsureTipFitsPanel(tooltip, needW)
  end

  PlacePanel(tooltip, panel, contentW, height, anchor)
  panel._warmoryShown = true
  panel._warmoryAnchor = anchor
  panel._warmoryHeight = height
  panel._warmoryWidth = contentW
  panel._warmoryTipW = needW

  local function Relock()
    if not tooltip:IsShown() or not panel._warmoryShown then
      return
    end
    local w = panel._warmoryTipW or needW
    if w > (tooltip:GetWidth() or 0) + 1 then
      EnsureTipFitsPanel(tooltip, w)
    end
    PlacePanel(
      tooltip,
      panel,
      panel._warmoryWidth or contentW,
      panel._warmoryHeight or height,
      panel._warmoryAnchor
    )
  end

  if C_Timer and C_Timer.After then
    C_Timer.After(0, Relock)
    C_Timer.After(0.05, Relock)
  end
end

local function PanelShown(tooltip)
  local panel = tooltip and tooltip.WhitemaneArmoryPanel
  return panel and panel._warmoryShown and panel:IsShown()
end

local function FormatChatBlock(entry)
  local lines = { BRAND }
  if ShowIlvlEnabled() then
    lines[#lines + 1] = ("ilvl %s"):format(tostring(entry.ilvl or 0))
  end
  for _, line in ipairs(ParseProgressLines(entry.progress)) do
    lines[#lines + 1] = line
  end
  local spec = SpecOnly(entry)
  if spec then
    lines[#lines + 1] = spec
  end
  return table.concat(lines, "\n")
end

local function UnitNameRealm(unit)
  local name, realm = UnitName(unit)
  if not name then
    return nil, nil
  end
  if not realm or realm == "" then
    realm = GetRealmName() or WhitemaneArmory.DEFAULT_REALM
  end
  return name, realm
end

local function AnnotateTooltip(tooltip, unit)
  -- Modifier required: keep the tip completely normal until the key is held.
  if not TooltipsEnabled() or not ModifierOk() then
    HidePanel(tooltip)
    return
  end
  if not tooltip or not unit or not UnitExists(unit) or not UnitIsPlayer(unit) then
    return
  end
  local name, realm = UnitNameRealm(unit)
  if not name then
    return
  end
  local entry = WhitemaneArmory.Lookup and WhitemaneArmory.Lookup(name, realm)
  if not entry then
    HidePanel(tooltip)
    return
  end
  if PanelShown(tooltip) then
    return
  end
  ShowPanel(tooltip, entry)
end

-- Full rebuild clears spacer AddLines so hide/show modifier cannot leak height.
local function RefreshUnitTooltip()
  if not GameTooltip or not GameTooltip:IsShown() then
    return
  end
  local _, unit = GameTooltip:GetUnit()
  if not unit or not UnitExists(unit) then
    return
  end

  HidePanel(GameTooltip)
  if GameTooltip.SetMinimumWidth then
    GameTooltip:SetMinimumWidth(0)
  end

  -- Re-set the unit: OnTooltipSetUnit / SetUnit hooks re-annotate only if
  -- the modifier is currently held. Released = normal tip, no ghost space.
  GameTooltip:SetUnit(unit)
end

GameTooltip:HookScript("OnTooltipSetUnit", function(tooltip)
  local _, unit = tooltip:GetUnit()
  AnnotateTooltip(tooltip, unit)
end)
GameTooltip:HookScript("OnHide", function(self)
  HidePanel(self)
end)
pcall(function()
  GameTooltip:HookScript("OnTooltipCleared", function(self)
    HidePanel(self)
  end)
end)

if GameTooltip.SetUnit then
  hooksecurefunc(GameTooltip, "SetUnit", function(self, unit)
    if not unit or not UnitExists(unit) or not UnitIsPlayer(unit) then
      return
    end
    local function run()
      if self:IsShown() then
        AnnotateTooltip(self, unit)
      end
    end
    if C_Timer and C_Timer.After then
      C_Timer.After(0, run)
    else
      run()
    end
  end)
end

-- Show/hide mid-hover when Shift/Alt/Ctrl is required.
local modFrame = CreateFrame("Frame")
modFrame:RegisterEvent("MODIFIER_STATE_CHANGED")
modFrame:SetScript("OnEvent", function()
  local mod = WhitemaneArmory.GetOption and WhitemaneArmory.GetOption("tooltipModifier")
  if not mod or tostring(mod):upper() == "NONE" then
    return
  end
  RefreshUnitTooltip()
end)

WhitemaneArmory.AddWhitemaneBlock = function(tooltip, entry)
  ShowPanel(tooltip, entry)
end
WhitemaneArmory.FormatChatBlock = FormatChatBlock
WhitemaneArmory.SpecOnly = SpecOnly
WhitemaneArmory.ParseProgressLines = ParseProgressLines
WhitemaneArmory.TooltipHasBrand = PanelShown
WhitemaneArmory.HideTooltipPanel = HidePanel
WhitemaneArmory.ModifierOk = ModifierOk
WhitemaneArmory.RefreshUnitTooltip = RefreshUnitTooltip
