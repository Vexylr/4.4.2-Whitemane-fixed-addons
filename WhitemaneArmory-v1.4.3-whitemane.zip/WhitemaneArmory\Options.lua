--[[
  Whitemane Armory — options panel
]]

WhitemaneArmory = WhitemaneArmory or {}

local PANEL_NAME = "Whitemane Armory"
local panel
local widgets = {}

local ACCENT = "|cffc9a227"
local MUTED = "|cff999999"

local MOD_OPTIONS = {
  { value = "NONE", label = "Always (no modifier)" },
  { value = "SHIFT", label = "Hold Shift" },
  { value = "ALT", label = "Hold Alt" },
  { value = "CTRL", label = "Hold Ctrl" },
}

local function RefreshChecks()
  for key, check in pairs(widgets.checks or {}) do
    check:SetChecked(not not WhitemaneArmory.GetOption(key))
  end
  if widgets.widthEdit then
    widgets.widthEdit:SetText(tostring(WhitemaneArmory.GetOption("minTipWidth") or 180))
  end
  if widgets.alphaSlider then
    local a = tonumber(WhitemaneArmory.GetOption("tipBgA")) or 0.96
    widgets.alphaSlider:SetValue(a)
    if widgets.alphaLabel then
      widgets.alphaLabel:SetText(("Panel background alpha: %.2f"):format(a))
    end
  end
  if widgets.modDropdown and UIDropDownMenu_SetSelectedValue then
    local mod = tostring(WhitemaneArmory.GetOption("tooltipModifier") or "NONE"):upper()
    UIDropDownMenu_SetSelectedValue(widgets.modDropdown, mod)
    local label = mod
    for _, opt in ipairs(MOD_OPTIONS) do
      if opt.value == mod then
        label = opt.label
        break
      end
    end
    UIDropDownMenu_SetText(widgets.modDropdown, label)
  end
  if widgets.colorSwatch and widgets.colorSwatch.tex then
    local r = tonumber(WhitemaneArmory.GetOption("tipBgR")) or 0.035
    local g = tonumber(WhitemaneArmory.GetOption("tipBgG")) or 0.06
    local b = tonumber(WhitemaneArmory.GetOption("tipBgB")) or 0.10
    local a = tonumber(WhitemaneArmory.GetOption("tipBgA")) or 0.96
    widgets.colorSwatch.tex:SetColorTexture(r, g, b, math.max(a, 0.15))
  end
end

local function SetBool(key, checked)
  WhitemaneArmory.SetOption(key, not not checked)
  if key == "showArmoryButton" and WhitemaneArmory.RefreshArmoryMenus then
    WhitemaneArmory.RefreshArmoryMenus()
  end
  if WhitemaneArmory.RefreshTooltipStyle then
    WhitemaneArmory.RefreshTooltipStyle()
  end
end

local function ApplyMinTipWidth(raw)
  local n = tonumber(raw)
  if not n then
    RefreshChecks()
    return
  end
  n = math.floor(n + 0.5)
  if n < 0 then
    n = 0
  elseif n > 400 then
    n = 400
  end
  WhitemaneArmory.SetOption("minTipWidth", n)
  if widgets.widthEdit then
    widgets.widthEdit:SetText(tostring(n))
  end
end

local function MakeCheck(parent, key, label, y)
  local check = CreateFrame("CheckButton", nil, parent, "InterfaceOptionsCheckButtonTemplate")
  check:SetPoint("TOPLEFT", 16, y)
  local text = check.Text or check.text
  if text then
    text:SetText(label)
  else
    local fs = check:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
    fs:SetPoint("LEFT", check, "RIGHT", 2, 1)
    fs:SetText(label)
    check.Text = fs
  end
  check:SetScript("OnClick", function(self)
    SetBool(key, self:GetChecked())
  end)
  widgets.checks[key] = check
  return check
end

local function OpenBgColorPicker()
  local r = tonumber(WhitemaneArmory.GetOption("tipBgR")) or 0.035
  local g = tonumber(WhitemaneArmory.GetOption("tipBgG")) or 0.06
  local b = tonumber(WhitemaneArmory.GetOption("tipBgB")) or 0.10
  local a = tonumber(WhitemaneArmory.GetOption("tipBgA")) or 0.96

  local function apply(nr, ng, nb)
    WhitemaneArmory.SetOption("tipBgR", nr)
    WhitemaneArmory.SetOption("tipBgG", ng)
    WhitemaneArmory.SetOption("tipBgB", nb)
    if WhitemaneArmory.RefreshTooltipStyle then
      WhitemaneArmory.RefreshTooltipStyle()
    end
    RefreshChecks()
  end

  if ColorPickerFrame and ColorPickerFrame.SetupColorPickerAndShow then
    ColorPickerFrame:SetupColorPickerAndShow({
      r = r, g = g, b = b, opacity = a,
      hasOpacity = true,
      swatchFunc = function()
        local nr, ng, nb = ColorPickerFrame:GetColorRGB()
        apply(nr, ng, nb)
        if ColorPickerFrame.GetColorAlpha then
          local na = ColorPickerFrame:GetColorAlpha()
          if na then
            WhitemaneArmory.SetOption("tipBgA", na)
            if widgets.alphaSlider then
              widgets.alphaSlider:SetValue(na)
            end
          end
        end
        if WhitemaneArmory.RefreshTooltipStyle then
          WhitemaneArmory.RefreshTooltipStyle()
        end
        RefreshChecks()
      end,
      opacityFunc = function()
        if ColorPickerFrame.GetColorAlpha then
          local na = ColorPickerFrame:GetColorAlpha()
          if na then
            WhitemaneArmory.SetOption("tipBgA", na)
            if widgets.alphaSlider then
              widgets.alphaSlider:SetValue(na)
            end
            if WhitemaneArmory.RefreshTooltipStyle then
              WhitemaneArmory.RefreshTooltipStyle()
            end
            RefreshChecks()
          end
        end
      end,
      cancelFunc = function(prev)
        if type(prev) == "table" then
          apply(prev.r or r, prev.g or g, prev.b or b)
          if prev.a or prev.opacity then
            WhitemaneArmory.SetOption("tipBgA", prev.a or prev.opacity)
          end
        end
        RefreshChecks()
      end,
    })
    return
  end

  -- Classic / Cata ColorPickerFrame
  if not ColorPickerFrame then
    return
  end
  ColorPickerFrame.hasOpacity = true
  ColorPickerFrame.opacity = 1 - a -- classic uses inverted opacity on some builds
  ColorPickerFrame.func = function()
    local nr, ng, nb = ColorPickerFrame:GetColorRGB()
    apply(nr, ng, nb)
  end
  ColorPickerFrame.opacityFunc = function()
    local o = OpacitySliderFrame and OpacitySliderFrame:GetValue()
    if o then
      -- Many classic builds: 0 = opaque. Prefer tipBgA slider as source of truth;
      -- map slider value directly if GetColorAlpha exists, else invert.
      local na = (ColorPickerFrame.GetColorAlpha and ColorPickerFrame:GetColorAlpha()) or (1 - o)
      WhitemaneArmory.SetOption("tipBgA", math.max(0, math.min(1, na)))
      if widgets.alphaSlider then
        widgets.alphaSlider:SetValue(WhitemaneArmory.GetOption("tipBgA"))
      end
      if WhitemaneArmory.RefreshTooltipStyle then
        WhitemaneArmory.RefreshTooltipStyle()
      end
      RefreshChecks()
    end
  end
  ColorPickerFrame.cancelFunc = function(prev)
    if type(prev) == "table" then
      apply(prev.r or r, prev.g or g, prev.b or b)
    end
  end
  if ColorPickerFrame.SetColorRGB then
    ColorPickerFrame:SetColorRGB(r, g, b)
  end
  ColorPickerFrame:Hide()
  ColorPickerFrame:Show()
end

local function BuildPanel()
  if panel then
    return panel
  end

  panel = CreateFrame("Frame", "WhitemaneArmoryOptionsPanel")
  panel.name = PANEL_NAME
  widgets.checks = {}

  local title = panel:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
  title:SetPoint("TOPLEFT", 16, -16)
  title:SetText(ACCENT .. WhitemaneArmory.BRAND .. "|r")

  local sub = panel:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
  sub:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -4)
  sub:SetText(MUTED .. "v" .. tostring(WhitemaneArmory.VERSION or "?") .. "|r")

  local y = -56
  MakeCheck(panel, "showTooltip", "Show tooltip overlays", y)
  y = y - 28
  MakeCheck(panel, "showIlvl", "Show item level in tooltip", y)
  y = y - 28
  MakeCheck(panel, "showSpec", "Show specialization line", y)
  y = y - 28
  MakeCheck(panel, "showArmoryButton", "Show armory button in unit menus", y)
  y = y - 28
  MakeCheck(panel, "printOnLogin", "Print status message on login", y)

  y = y - 36
  local modLabel = panel:CreateFontString(nil, "ARTWORK", "GameFontNormal")
  modLabel:SetPoint("TOPLEFT", 20, y)
  modLabel:SetText("Armory on tooltips (normal until key held)")

  local dropdown = CreateFrame("Frame", "WhitemaneArmory_ModDropdown", panel, "UIDropDownMenuTemplate")
  dropdown:SetPoint("TOPLEFT", modLabel, "BOTTOMLEFT", -16, -4)
  UIDropDownMenu_SetWidth(dropdown, 180)
  UIDropDownMenu_Initialize(dropdown, function(self, level)
    for _, opt in ipairs(MOD_OPTIONS) do
      local info = UIDropDownMenu_CreateInfo()
      info.text = opt.label
      info.value = opt.value
      info.checked = (tostring(WhitemaneArmory.GetOption("tooltipModifier") or "NONE"):upper() == opt.value)
      info.func = function()
        WhitemaneArmory.SetOption("tooltipModifier", opt.value)
        UIDropDownMenu_SetSelectedValue(dropdown, opt.value)
        UIDropDownMenu_SetText(dropdown, opt.label)
      end
      UIDropDownMenu_AddButton(info, level)
    end
  end)
  widgets.modDropdown = dropdown
  y = y - 56

  local alphaLabel = panel:CreateFontString(nil, "ARTWORK", "GameFontNormal")
  alphaLabel:SetPoint("TOPLEFT", 20, y)
  alphaLabel:SetText("Panel background alpha: 0.96")
  widgets.alphaLabel = alphaLabel

  local slider = CreateFrame("Slider", "WhitemaneArmory_BgAlpha", panel, "OptionsSliderTemplate")
  slider:SetPoint("TOPLEFT", alphaLabel, "BOTTOMLEFT", 0, -12)
  slider:SetMinMaxValues(0, 1)
  slider:SetValueStep(0.01)
  if slider.SetObeyStepOnDrag then
    slider:SetObeyStepOnDrag(true)
  end
  slider:SetWidth(220)
  _G[slider:GetName() .. "Low"]:SetText("0")
  _G[slider:GetName() .. "High"]:SetText("1")
  _G[slider:GetName() .. "Text"]:SetText("")
  slider:SetScript("OnValueChanged", function(self, value)
    value = math.floor(value * 100 + 0.5) / 100
    WhitemaneArmory.SetOption("tipBgA", value)
    if widgets.alphaLabel then
      widgets.alphaLabel:SetText(("Panel background alpha: %.2f"):format(value))
    end
    if WhitemaneArmory.RefreshTooltipStyle then
      WhitemaneArmory.RefreshTooltipStyle()
    end
    if widgets.colorSwatch and widgets.colorSwatch.tex then
      local r = tonumber(WhitemaneArmory.GetOption("tipBgR")) or 0.035
      local g = tonumber(WhitemaneArmory.GetOption("tipBgG")) or 0.06
      local b = tonumber(WhitemaneArmory.GetOption("tipBgB")) or 0.10
      widgets.colorSwatch.tex:SetColorTexture(r, g, b, math.max(value, 0.15))
    end
  end)
  widgets.alphaSlider = slider

  local alphaHint = panel:CreateFontString(nil, "ARTWORK", "GameFontDisableSmall")
  alphaHint:SetPoint("TOPLEFT", slider, "BOTTOMLEFT", 0, -4)
  alphaHint:SetText("0 = transparent (best with TipTac). Default is 0.")

  y = y - 78
  local colorLabel = panel:CreateFontString(nil, "ARTWORK", "GameFontNormal")
  colorLabel:SetPoint("TOPLEFT", 20, y)
  colorLabel:SetText("Panel background color")

  local swatch = CreateFrame("Button", nil, panel)
  swatch:SetSize(28, 18)
  swatch:SetPoint("LEFT", colorLabel, "RIGHT", 12, 0)
  local border = swatch:CreateTexture(nil, "BACKGROUND")
  border:SetAllPoints()
  border:SetColorTexture(0.4, 0.4, 0.45, 1)
  local tex = swatch:CreateTexture(nil, "ARTWORK")
  tex:SetPoint("TOPLEFT", 1, -1)
  tex:SetPoint("BOTTOMRIGHT", -1, 1)
  swatch.tex = tex
  swatch:SetScript("OnClick", OpenBgColorPicker)
  widgets.colorSwatch = swatch

  y = y - 36
  local widthLabel = panel:CreateFontString(nil, "ARTWORK", "GameFontNormal")
  widthLabel:SetPoint("TOPLEFT", 20, y)
  widthLabel:SetText("Minimum tooltip width")

  local edit = CreateFrame("EditBox", "WhitemaneArmory_MinTipWidth", panel, "InputBoxTemplate")
  edit:SetSize(56, 20)
  edit:SetPoint("LEFT", widthLabel, "RIGHT", 12, 0)
  edit:SetAutoFocus(false)
  edit:SetMaxLetters(3)
  edit:SetNumeric(true)
  edit:SetScript("OnEnterPressed", function(self)
    ApplyMinTipWidth(self:GetText())
    self:ClearFocus()
  end)
  edit:SetScript("OnEditFocusLost", function(self)
    ApplyMinTipWidth(self:GetText())
  end)
  widgets.widthEdit = edit

  local hint = panel:CreateFontString(nil, "ARTWORK", "GameFontDisableSmall")
  hint:SetPoint("TOPLEFT", widthLabel, "BOTTOMLEFT", 0, -8)
  hint:SetText("0 = hug content (recommended) · 120–400 optional floor")

  local foot = panel:CreateFontString(nil, "ARTWORK", "GameFontDisableSmall")
  foot:SetPoint("BOTTOMLEFT", 16, 16)
  foot:SetText("/warmory config  ·  tooltip | ilvl | mod | spec | armorybtn | loginmsg")

  panel:SetScript("OnShow", RefreshChecks)

  if Settings and Settings.RegisterCanvasLayoutCategory and Settings.RegisterAddOnCategory then
    local category = Settings.RegisterCanvasLayoutCategory(panel, PANEL_NAME)
    category.ID = PANEL_NAME
    Settings.RegisterAddOnCategory(category)
    panel._settingsCategory = category
  elseif InterfaceOptions_AddCategory then
    InterfaceOptions_AddCategory(panel)
  end

  return panel
end

function WhitemaneArmory.OpenOptions()
  BuildPanel()
  RefreshChecks()

  if Settings and Settings.OpenToCategory and panel._settingsCategory then
    Settings.OpenToCategory(panel._settingsCategory:GetID())
    return
  end

  if InterfaceOptionsFrame_OpenToCategory then
    InterfaceOptionsFrame_OpenToCategory(panel)
    InterfaceOptionsFrame_OpenToCategory(panel)
    return
  end

  if not panel:GetParent() or panel:GetParent() == UIParent then
    panel:SetParent(UIParent)
    panel:SetSize(460, 520)
    panel:ClearAllPoints()
    panel:SetPoint("CENTER")
    panel:SetFrameStrata("DIALOG")
    if not panel.bg then
      local bg = panel:CreateTexture(nil, "BACKGROUND")
      bg:SetAllPoints()
      bg:SetColorTexture(0.08, 0.08, 0.09, 0.95)
      panel.bg = bg
      if not panel.close then
        local close = CreateFrame("Button", nil, panel, "UIPanelCloseButton")
        close:SetPoint("TOPRIGHT", -4, -4)
        panel.close = close
      end
    end
  end
  panel:Show()
end

function WhitemaneArmory.SlashConfig()
  WhitemaneArmory.OpenOptions()
end

BuildPanel()
