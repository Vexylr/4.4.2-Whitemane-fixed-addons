--[[
  Whitemane Armory — defaults + saved config
]]

WhitemaneArmory = WhitemaneArmory or {}

WhitemaneArmory.BRAND = "Whitemane Armory"
WhitemaneArmory.VERSION = "1.4.3"
WhitemaneArmory.DEFAULT_REALM = "Gilneas"
WhitemaneArmory.ARMORY_BASE = "https://whitemane.gg/en/armory/gilneas/character"

-- tooltipModifier: "NONE" | "SHIFT" | "ALT" | "CTRL"
WhitemaneArmory.Defaults = {
  showTooltip = true,
  showSpec = true,
  showIlvl = true,
  showArmoryButton = true,
  printOnLogin = false,
  minTipWidth = 0, -- 0 = size to content; do not inflate GameTooltip
  tooltipModifier = "NONE",
  tipBgR = 0.035,
  tipBgG = 0.06,
  tipBgB = 0.10,
  tipBgA = 0.0, -- transparent — TipTac / ElvUI skins show through
}

local function CopyDefaults(src, dst)
  dst = dst or {}
  for k, v in pairs(src) do
    if type(v) == "table" then
      dst[k] = CopyDefaults(v, type(dst[k]) == "table" and dst[k] or {})
    elseif dst[k] == nil then
      dst[k] = v
    end
  end
  return dst
end

function WhitemaneArmory.GetDB()
  if type(WhitemaneArmory_Config) ~= "table" then
    WhitemaneArmory_Config = {}
  end
  -- One-time migrate from old WhitemaneRIO saved vars (if present).
  if type(WhitemaneRIO_Config) == "table" then
    for k, v in pairs(WhitemaneRIO_Config) do
      if WhitemaneArmory_Config[k] == nil then
        WhitemaneArmory_Config[k] = v
      end
    end
  end
  if type(WhitemaneArmory_CharDB) == "table" then
    for k, v in pairs(WhitemaneArmory_CharDB) do
      if WhitemaneArmory_Config[k] == nil then
        WhitemaneArmory_Config[k] = v
      end
    end
  end
  CopyDefaults(WhitemaneArmory.Defaults, WhitemaneArmory_Config)
  -- v1.4.2: stop inflating tips; old default was 180.
  if not WhitemaneArmory_Config._migratedTipWidth142 then
    if WhitemaneArmory_Config.minTipWidth == nil or WhitemaneArmory_Config.minTipWidth == 180 then
      WhitemaneArmory_Config.minTipWidth = 0
    end
    WhitemaneArmory_Config._migratedTipWidth142 = true
  end
  return WhitemaneArmory_Config
end

function WhitemaneArmory.GetOption(key)
  local db = WhitemaneArmory.GetDB()
  if db[key] == nil then
    return WhitemaneArmory.Defaults[key]
  end
  return db[key]
end

function WhitemaneArmory.SetOption(key, value)
  local db = WhitemaneArmory.GetDB()
  db[key] = value
  return value
end

function WhitemaneArmory.ToggleOption(key)
  return WhitemaneArmory.SetOption(key, not WhitemaneArmory.GetOption(key))
end

function WhitemaneArmory.Print(msg)
  print("|cff66ccff" .. WhitemaneArmory.BRAND .. "|r " .. tostring(msg or ""))
end

function WhitemaneArmory.ArmoryURL(name, realm)
  name = tostring(name or ""):match("^%s*(.-)%s*$") or ""
  name = name:match("^([^-]+)") or name
  if name == "" then
    return nil
  end
  realm = (realm and realm ~= "" and realm) or WhitemaneArmory.DEFAULT_REALM
  realm = tostring(realm):lower():gsub("%s+", "")
  return ("https://whitemane.gg/en/armory/%s/character/%s"):format(realm, name)
end

function WhitemaneArmory.PrintConfigStatus()
  local tip = WhitemaneArmory.GetOption("showTooltip") and "on" or "off"
  local spec = WhitemaneArmory.GetOption("showSpec") and "on" or "off"
  local ilvl = WhitemaneArmory.GetOption("showIlvl") and "on" or "off"
  local armory = WhitemaneArmory.GetOption("showArmoryButton") and "on" or "off"
  local login = WhitemaneArmory.GetOption("printOnLogin") and "on" or "off"
  local mod = tostring(WhitemaneArmory.GetOption("tooltipModifier") or "NONE")
  local a = tonumber(WhitemaneArmory.GetOption("tipBgA")) or 0.96
  WhitemaneArmory.Print(("config — tip %s | mod %s | ilvl %s | spec %s | bgα %.2f | menu %s | login %s"):format(
    tip, mod, ilvl, spec, a, armory, login
  ))
  WhitemaneArmory.Print("/warmory config  ·  tooltip | ilvl | spec | mod | armorybtn | loginmsg")
end

function WhitemaneArmory.SlashConfig()
  if WhitemaneArmory.OpenOptions then
    WhitemaneArmory.OpenOptions()
  else
    WhitemaneArmory.PrintConfigStatus()
  end
end

