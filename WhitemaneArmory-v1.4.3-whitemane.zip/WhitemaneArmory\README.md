﻿# Whitemane Armory

Core addon. Pair with **WhitemaneArmory_Data**.

Slash: `/warmory` (alias `/whitemanearmory`)

See the repo root README for install and weekly update steps.
