--[[
  Whitemane Armory — InspectFrame progress panel (fail-soft if Inspect UI missing)
]]

local BRAND = WhitemaneArmory.BRAND

local panel
local hooked

local function UnitNameRealm(unit)
  if not unit or not UnitExists(unit) or not UnitIsPlayer(unit) then
    return nil, nil
  end
  local name, realm = UnitName(unit)
  if not name then
    return nil, nil
  end
  if not realm or realm == "" then
    realm = GetRealmName() or WhitemaneArmory.DEFAULT_REALM
  end
  return name, realm
end

local function InspectUnit()
  -- Cata Classic: InspectFrame.unit, or legacy InspectFrame_Unit / global.
  if InspectFrame and InspectFrame.unit then
    return InspectFrame.unit
  end
  if type(InspectFrame_Unit) == "string" and InspectFrame_Unit ~= "" then
    return InspectFrame_Unit
  end
  if type(InspectFrame_Unit) == "function" then
    local ok, u = pcall(InspectFrame_Unit)
    if ok and type(u) == "string" and u ~= "" then
      return u
    end
  end
  -- Fallback while inspecting.
  if UnitExists("target") and UnitIsPlayer("target") and CanInspect and CanInspect("target") then
    return "target"
  end
  return nil
end

local function ApplyBackdrop(frame)
  local backdrop = {
    bgFile = "Interface\\Buttons\\WHITE8x8",
    edgeFile = "Interface\\Buttons\\WHITE8x8",
    edgeSize = 1,
    insets = { left = 1, right = 1, top = 1, bottom = 1 },
  }
  if frame.SetBackdrop then
    frame:SetBackdrop(backdrop)
    frame:SetBackdropColor(0.04, 0.07, 0.11, 0.94)
    frame:SetBackdropBorderColor(0.40, 0.80, 1.00, 0.90)
    return
  end
  if not frame.bg then
    frame.bg = frame:CreateTexture(nil, "BACKGROUND")
    frame.bg:SetAllPoints()
    frame.bg:SetColorTexture(0.04, 0.07, 0.11, 0.94)
  end
end

local function EnsurePanel(parent)
  if panel and panel:GetParent() == parent then
    return panel
  end

  panel = CreateFrame("Frame", "WhitemaneArmoryInspectPanel", parent)
  panel:SetFrameStrata(parent:GetFrameStrata() or "HIGH")
  panel:SetFrameLevel((parent:GetFrameLevel() or 1) + 20)
  panel:SetWidth(168)
  panel:Hide()
  ApplyBackdrop(panel)

  panel.text = panel:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  panel.text:SetPoint("TOPLEFT", panel, "TOPLEFT", 8, -6)
  panel.text:SetPoint("TOPRIGHT", panel, "TOPRIGHT", -8, -6)
  panel.text:SetJustifyH("LEFT")
  panel.text:SetJustifyV("TOP")
  panel.text:SetSpacing(2)
  panel.text:SetTextColor(0.90, 0.90, 0.92)
  panel.text:SetWordWrap(true)

  panel.none = panel:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
  panel.none:SetPoint("TOPLEFT", panel, "TOPLEFT", 8, -6)
  panel.none:SetPoint("TOPRIGHT", panel, "TOPRIGHT", -8, -6)
  panel.none:SetJustifyH("LEFT")
  panel.none:SetTextColor(0.55, 0.55, 0.60)
  panel.none:Hide()

  return panel
end

local function PlacePanel(parent)
  panel:ClearAllPoints()
  -- Prefer right of InspectFrame; fall back below paper doll if needed.
  local anchor = InspectPaperDollFrame or InspectModelFrame or parent
  if anchor and anchor:IsShown() then
    panel:SetPoint("TOPLEFT", parent, "TOPRIGHT", 4, -16)
  else
    panel:SetPoint("TOPLEFT", parent, "TOPRIGHT", 4, -16)
  end
end

local function HidePanel()
  if panel then
    panel:Hide()
  end
end

local function ShowEntry(entry, key)
  if not panel then
    return
  end
  panel.none:Hide()
  panel.text:Show()

  local block
  if WhitemaneArmory.FormatChatBlock then
    block = WhitemaneArmory.FormatChatBlock(entry)
  else
    block = (BRAND .. "\nilvl " .. tostring(entry.ilvl or 0))
  end
  if key and key ~= "" then
    block = key .. "\n" .. block
  end
  panel.text:SetText(block)

  local h = (panel.text:GetStringHeight() or 60) + 14
  panel:SetHeight(math.max(h, 48))
  panel:Show()
end

local function ShowMissing(name)
  if not panel then
    return
  end
  panel.text:Hide()
  panel.none:Show()
  panel.none:SetText(BRAND .. "\n" .. (name or "?") .. "\nno datapack entry")
  panel:SetHeight(48)
  panel:Show()
end

local function Refresh()
  if not InspectFrame or not InspectFrame:IsShown() then
    HidePanel()
    return
  end

  local parent = InspectFrame
  EnsurePanel(parent)
  PlacePanel(parent)

  local unit = InspectUnit()
  local name, realm = UnitNameRealm(unit)
  if not name then
    -- Inspect may open before unit name is ready.
    HidePanel()
    return
  end

  local entry, key = WhitemaneArmory.Lookup and WhitemaneArmory.Lookup(name, realm)
  if entry then
    ShowEntry(entry, key)
  else
    ShowMissing(name)
  end
end

local function ScheduleRefresh()
  if C_Timer and C_Timer.After then
    C_Timer.After(0, Refresh)
    C_Timer.After(0.15, Refresh)
  else
    Refresh()
  end
end

local function HookInspectUI()
  if hooked then
    return true
  end
  if not InspectFrame then
    return false
  end

  local ok = pcall(function()
    InspectFrame:HookScript("OnShow", ScheduleRefresh)
    InspectFrame:HookScript("OnHide", HidePanel)
  end)
  if not ok then
    return false
  end

  -- PaperDoll tab switches / model updates.
  if InspectPaperDollFrame then
    pcall(function()
      InspectPaperDollFrame:HookScript("OnShow", ScheduleRefresh)
    end)
  end

  hooked = true

  if InspectFrame:IsShown() then
    ScheduleRefresh()
  end
  return true
end

local loader = CreateFrame("Frame")
loader:RegisterEvent("ADDON_LOADED")
loader:RegisterEvent("PLAYER_LOGIN")
-- INSPECT_READY exists on many Classic clients; ignore if missing.
pcall(function()
  loader:RegisterEvent("INSPECT_READY")
end)
loader:SetScript("OnEvent", function(_, event, arg1)
  if event == "ADDON_LOADED" then
    if arg1 == "Blizzard_InspectUI" then
      HookInspectUI()
    end
  elseif event == "PLAYER_LOGIN" then
    if not HookInspectUI() then
      -- Retry shortly in case InspectUI loads with first inspect.
      if C_Timer and C_Timer.After then
        C_Timer.After(2, function()
          HookInspectUI()
        end)
      end
    end
  elseif event == "INSPECT_READY" then
    if not hooked then
      HookInspectUI()
    end
    ScheduleRefresh()
  end
end)

-- Public escape hatch for other modules / slash debugging.
WhitemaneArmory.RefreshInspectPanel = function()
  if not hooked then
    HookInspectUI()
  end
  Refresh()
end
