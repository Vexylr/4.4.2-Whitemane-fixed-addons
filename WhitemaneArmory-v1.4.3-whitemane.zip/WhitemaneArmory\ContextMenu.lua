--[[
  Whitemane Armory — right-click "Copy Armory Link"
]]

local BUTTON_TEXT = "Copy Armory Link"
local POPUP_TITLE = WhitemaneArmory.BRAND

local function ArmoryEnabled()
  return WhitemaneArmory.GetOption("showArmoryButton") ~= false
end

local function Trim(s)
  if type(s) ~= "string" then
    return nil
  end
  s = s:match("^%s*(.-)%s*$")
  if not s or s == "" then
    return nil
  end
  return s
end

local function SplitNameRealm(full)
  full = Trim(full)
  if not full then
    return nil, nil
  end
  local bare, realm = full:match("^([^-]+)%-(.+)$")
  if bare then
    return Trim(bare), Trim(realm)
  end
  return full, nil
end

local function NormalizeRealm(realm)
  realm = Trim(realm)
  if not realm then
    return nil
  end
  -- Collapse spaces (cross-realm often has "Gilneas" already; some UIs use spaces)
  return realm:gsub("%s+", "")
end

local function PlayerRealmFallback()
  if GetNormalizedRealmName then
    local nr = Trim(GetNormalizedRealmName())
    if nr then
      return nr
    end
  end
  return NormalizeRealm(GetRealmName()) or WhitemaneArmory.DEFAULT_REALM
end

--- Prefer a focused WoW game account from a BN friend index.
local function CharFromBNFriendIndex(friendIndex)
  if not friendIndex or not BNGetNumFriendGameAccounts or not BNGetFriendGameAccountInfo then
    return nil, nil
  end
  local num = BNGetNumFriendGameAccounts(friendIndex) or 0
  local fallbackN, fallbackR
  for j = 1, num do
    local hasFocus, charName, client, realmName = BNGetFriendGameAccountInfo(friendIndex, j)
    if (client == "WoW" or client == BNET_CLIENT_WOW) and charName and charName ~= "" then
      local n, r = Trim(charName), NormalizeRealm(realmName)
      if hasFocus then
        return n, r
      end
      if not fallbackN then
        fallbackN, fallbackR = n, r
      end
    end
  end
  return fallbackN, fallbackR
end

--- Try Battle.net friend → active WoW character name/realm (Cata + modern).
local function ResolveBattleNet(dropdown)
  if not dropdown then
    return nil, nil
  end

  local accountInfo = dropdown.accountInfo
  if type(accountInfo) == "table" then
    local ga = accountInfo.gameAccountInfo
    if type(ga) == "table" and ga.characterName and ga.characterName ~= "" then
      return Trim(ga.characterName), NormalizeRealm(ga.realmName or ga.realmDisplayName)
    end
  end

  local bnetID = dropdown.bnetIDAccount or dropdown.bnAccountID or dropdown.accountID
  if not bnetID then
    return nil, nil
  end

  if C_BattleNet and C_BattleNet.GetAccountInfoByID then
    local info = C_BattleNet.GetAccountInfoByID(bnetID)
    local ga = info and info.gameAccountInfo
    if type(ga) == "table" and ga.characterName and ga.characterName ~= "" then
      return Trim(ga.characterName), NormalizeRealm(ga.realmName or ga.realmDisplayName)
    end
  end

  -- Classic-era: BNGetFriendInfo(i) first return is bnetIDAccount; game accounts use friend index.
  if BNGetNumFriends and BNGetFriendInfo then
    local total = BNGetNumFriends() or 0
    if type(total) ~= "number" then
      total = 0
    end
    for i = 1, total do
      if BNGetFriendInfo(i) == bnetID then
        return CharFromBNFriendIndex(i)
      end
    end
  end

  return nil, nil
end

--- Friends list index (FRIEND / FRIEND_OFFLINE).
local function ResolveFriendsList(dropdown)
  if not dropdown then
    return nil, nil
  end
  local idx = dropdown.friendsList or dropdown.friendIndex or dropdown.index
  if not idx or not GetFriendInfo then
    return nil, nil
  end
  local name = GetFriendInfo(idx)
  if type(name) == "string" and name ~= "" then
    return SplitNameRealm(name)
  end
  return nil, nil
end

local function ResolveFromUnit(unit)
  if not unit or unit == "" then
    return nil, nil
  end
  if not UnitExists(unit) then
    return nil, nil
  end
  if UnitIsPlayer and not UnitIsPlayer(unit) then
    return nil, nil
  end

  if GetUnitName then
    local full = GetUnitName(unit, true)
    local n, r = SplitNameRealm(full)
    if n then
      return n, r
    end
  end

  local un, ur = UnitName(unit)
  un = Trim(un)
  if not un then
    return nil, nil
  end
  return un, NormalizeRealm(ur)
end

--- Harden name/realm for target, party, raid, friends, chat roster, BN.
local function ResolveNameRealm(dropdown, unit, name, server)
  local n = Trim(name)
  local r = NormalizeRealm(server)

  unit = unit or (dropdown and dropdown.unit)

  -- Unit token first when present (target / party / raid / focus / self).
  local un, ur = ResolveFromUnit(unit)
  if un then
    n, r = un, ur or r
  end

  if dropdown then
    if not n then
      -- Chat roster often stores Name-Realm in chatTarget.
      local chat = dropdown.chatTarget or dropdown.chatName
      if chat then
        n, r = SplitNameRealm(chat)
      end
    end

    if not n and dropdown.name then
      local dn, dr = SplitNameRealm(dropdown.name)
      n = dn
      r = r or dr
    end

    if (not r or r == "") and dropdown.server then
      r = NormalizeRealm(dropdown.server)
    end
    if (not r or r == "") and dropdown.realm then
      r = NormalizeRealm(dropdown.realm)
    end

    if not n then
      local bn, br = ResolveBattleNet(dropdown)
      if bn then
        n, r = bn, br or r
      end
    end

    if not n then
      local fn, fr = ResolveFriendsList(dropdown)
      if fn then
        n, r = fn, fr or r
      end
    end
  end

  -- Name still "Name-Realm"?
  if n and n:find("-", 1, true) then
    local bare, realmPart = SplitNameRealm(n)
    if bare then
      n, r = bare, realmPart or r
    end
  end

  n = Trim(n)
  if not n then
    return nil, nil
  end

  r = NormalizeRealm(r) or PlayerRealmFallback()
  return n, r
end

-- Custom frame (not StaticPopup). Blizzard_StaticPopup routes clicks through
-- securecall, which keeps our OnAccept tainted and blocks CopyToClipboard.
local armoryFrame

local function ApplyFrameBackdrop(frame)
  local backdrop = {
    bgFile = "Interface\\Buttons\\WHITE8x8",
    edgeFile = "Interface\\Buttons\\WHITE8x8",
    edgeSize = 1,
    insets = { left = 1, right = 1, top = 1, bottom = 1 },
  }
  if frame.SetBackdrop then
    frame:SetBackdrop(backdrop)
    frame:SetBackdropColor(0.06, 0.07, 0.09, 0.96)
    frame:SetBackdropBorderColor(0.40, 0.80, 1.00, 0.85)
    return
  end
  if not frame.bg then
    frame.bg = frame:CreateTexture(nil, "BACKGROUND")
    frame.bg:SetAllPoints()
    frame.bg:SetColorTexture(0.06, 0.07, 0.09, 0.96)
  end
end

local function EnsureArmoryFrame()
  if armoryFrame then
    return armoryFrame
  end

  local f = CreateFrame("Frame", "WhitemaneArmoryLinkFrame", UIParent)
  f:SetSize(520, 118)
  f:SetPoint("CENTER")
  f:SetFrameStrata("DIALOG")
  f:SetFrameLevel(100)
  f:SetMovable(true)
  f:EnableMouse(true)
  f:RegisterForDrag("LeftButton")
  f:SetScript("OnDragStart", f.StartMoving)
  f:SetScript("OnDragStop", f.StopMovingOrSizing)
  f:Hide()
  ApplyFrameBackdrop(f)

  local title = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
  title:SetPoint("TOPLEFT", 16, -14)
  title:SetText(POPUP_TITLE)
  f.title = title

  local hint = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  hint:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -2)
  hint:SetTextColor(0.65, 0.68, 0.72)
  hint:SetText("Click Select, then Ctrl+C — paste in your browser")
  f.hint = hint

  local edit = CreateFrame("EditBox", "WhitemaneArmoryLinkEditBox", f, "InputBoxTemplate")
  edit:SetHeight(22)
  edit:SetPoint("TOPLEFT", 20, -52)
  edit:SetPoint("TOPRIGHT", -20, -52)
  edit:SetAutoFocus(false)
  edit:SetMaxLetters(512)
  edit:SetScript("OnEscapePressed", function(self)
    self:ClearFocus()
    f:Hide()
  end)
  edit:SetScript("OnEnterPressed", function()
    f.copy:Click()
  end)
  f.edit = edit

  local copy = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
  copy:SetSize(110, 24)
  copy:SetPoint("BOTTOMLEFT", 16, 14)
  copy:SetText("Select")
  copy:RegisterForClicks("LeftButtonUp")
  copy:SetScript("OnClick", function()
    -- This client forbids CopyToClipboard from any addon (tainted) path.
    -- Select + highlight is the only safe in-game copy flow.
    local text = (edit:GetText() or ""):match("^%s*(.-)%s*$") or ""
    if text == "" then
      return
    end
    edit:SetFocus()
    edit:HighlightText()
    WhitemaneArmory.Print("URL selected — press Ctrl+C, then paste in your browser")
  end)
  f.copy = copy

  local close = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
  close:SetSize(110, 24)
  close:SetPoint("BOTTOMRIGHT", -16, 14)
  close:SetText(CLOSE or "Close")
  close:SetScript("OnClick", function()
    f:Hide()
  end)
  f.close = close

  tinsert(UISpecialFrames, "WhitemaneArmoryLinkFrame")
  armoryFrame = f
  return f
end

local function ShowArmoryPopup(text)
  if type(text) ~= "string" or text == "" then
    return false
  end
  local f = EnsureArmoryFrame()
  f.edit:SetText(text)
  f.edit:HighlightText()
  f.edit:SetFocus()
  f:Show()
  f:Raise()
  return true
end

function WhitemaneArmory.OpenArmory(name, realm)
  local url = WhitemaneArmory.ArmoryURL(name, realm)
  if not url then
    WhitemaneArmory.Print("need a character name")
    return
  end

  ShowArmoryPopup(url)
  WhitemaneArmory.Print("armory link ready — Ctrl+C the selected URL")
  print("  |cff66ccff" .. url .. "|r")
end

-- ---------- Classic / Cata dropdown inject ----------
local function AddSeparator(level)
  level = level or UIDROPDOWNMENU_MENU_LEVEL or 1
  if UIDropDownMenu_AddSeparator then
    UIDropDownMenu_AddSeparator(level)
    return
  end
  if UIDROPDOWNMENU_SEPARATOR_INFO then
    UIDropDownMenu_AddButton(UIDROPDOWNMENU_SEPARATOR_INFO, level)
    return
  end
  local info = UIDropDownMenu_CreateInfo()
  info.text = ""
  info.isTitle = true
  info.notCheckable = true
  info.isUninteractable = true
  UIDropDownMenu_AddButton(info, level)
end

local function AddArmoryButton(name, realm, level)
  local info = UIDropDownMenu_CreateInfo()
  info.text = BUTTON_TEXT
  info.notCheckable = true
  info.func = function()
    if CloseDropDownMenus then
      CloseDropDownMenus()
    end
    WhitemaneArmory.OpenArmory(name, realm)
  end
  UIDropDownMenu_AddButton(info, level or UIDROPDOWNMENU_MENU_LEVEL or 1)
end

local function MenuAlreadyHasArmory()
  local maxBtn = UIDROPDOWNMENU_MAXBUTTONS or 32
  for i = 1, maxBtn do
    local btn = _G["DropDownList1Button" .. i]
    if btn and btn:IsShown() then
      local t = btn:GetText()
      if t == BUTTON_TEXT then
        return true
      end
      -- UnitPopupButtons path may wrap with color codes
      if type(t) == "string" and t:find(BUTTON_TEXT, 1, true) then
        return true
      end
    end
  end
  return false
end

-- Menus where we should not inject (markers, pets, etc.).
local SKIP_WHICH = {
  RAID_TARGET_ICON = true,
  PET = true,
  BATTLEPET = true,
  OTHERBATTLEPET = true,
  VEHICLE = true,
}

local function InjectClassic(dropdown, which, unit, name)
  if not ArmoryEnabled() then
    return
  end
  if not UIDropDownMenu_CreateInfo or not UIDropDownMenu_AddButton then
    return
  end
  if (UIDROPDOWNMENU_MENU_LEVEL or 1) ~= 1 then
    return
  end
  if MenuAlreadyHasArmory() then
    return
  end

  local whichUp = which and tostring(which):upper() or ""
  if SKIP_WHICH[whichUp] then
    return
  end

  -- Skip non-player unit tokens (keep friend/chat menus that have no unit).
  if unit and UnitExists(unit) and UnitIsPlayer and not UnitIsPlayer(unit) then
    return
  end

  local n, r = ResolveNameRealm(dropdown, unit, name, dropdown and dropdown.server)
  if not n then
    return
  end

  AddSeparator()
  AddArmoryButton(n, r)
end

local hookedShowMenu = false
local hookedOnClick = false

local function HookClassicMenus()
  if hookedShowMenu then
    return
  end
  if type(UnitPopup_ShowMenu) ~= "function" then
    return
  end
  hooksecurefunc("UnitPopup_ShowMenu", InjectClassic)
  hookedShowMenu = true
end

-- UnitPopupButtons backup when those globals exist.
local BUTTON = "WHITEMANE_ARMORY_LINK"
local MENU_KEYS = {
  "SELF", "PLAYER", "PARTY", "RAID_PLAYER", "RAID",
  "FRIEND", "FRIEND_OFFLINE", "BN_FRIEND", "CHAT_ROSTER",
  "FOCUS", "TARGET", "GUILD", "GUILD_OFFLINE",
}

local function EnsurePopupButton()
  if type(UnitPopupButtons) ~= "table" then
    return false
  end
  UnitPopupButtons[BUTTON] = {
    text = BUTTON_TEXT,
    dist = 0,
  }
  return true
end

local function InsertButton(menu)
  if type(menu) ~= "table" then
    return
  end
  for i = 1, #menu do
    if menu[i] == BUTTON then
      return
    end
  end
  for i = 1, #menu do
    if menu[i] == "CANCEL" then
      table.insert(menu, i, BUTTON)
      return
    end
  end
  menu[#menu + 1] = BUTTON
end

local function RemoveButton(menu)
  if type(menu) ~= "table" then
    return
  end
  for i = #menu, 1, -1 do
    if menu[i] == BUTTON then
      table.remove(menu, i)
    end
  end
end

function WhitemaneArmory.RefreshArmoryMenus()
  HookClassicMenus()
  if not EnsurePopupButton() or type(UnitPopupMenus) ~= "table" then
    return
  end
  local show = ArmoryEnabled()
  for _, key in ipairs(MENU_KEYS) do
    if show then
      InsertButton(UnitPopupMenus[key])
    else
      RemoveButton(UnitPopupMenus[key])
    end
  end
end

local function HookPopupOnClick()
  if hookedOnClick then
    return
  end
  if type(UnitPopup_OnClick) ~= "function" then
    return
  end
  hookedOnClick = true
  hooksecurefunc("UnitPopup_OnClick", function(self)
    local value = self and (self.value or self.arg1)
    if value ~= BUTTON or not ArmoryEnabled() then
      return
    end
    local dropdown = UIDROPDOWNMENU_INIT_MENU or UIDROPDOWNMENU_OPEN_MENU
    local n, r = ResolveNameRealm(
      dropdown,
      dropdown and dropdown.unit,
      dropdown and dropdown.name,
      dropdown and (dropdown.server or dropdown.realm)
    )
    if not n then
      WhitemaneArmory.Print("no player selected for armory link")
      return
    end
    WhitemaneArmory.OpenArmory(n, r)
  end)
end

local function SetupAll(forceRehook)
  if forceRehook then
    -- Blizzard_UnitPopup LoD may replace UnitPopup_* after we first hooked stubs.
    hookedShowMenu = false
    hookedOnClick = false
  end
  HookClassicMenus()
  HookPopupOnClick()
  WhitemaneArmory.RefreshArmoryMenus()
end

-- ---------- Modern Menu API (if this build ever exposes it) ----------
local modernMenusHooked = false
local function HookModernMenus()
  if modernMenusHooked then
    return
  end
  if type(Menu) ~= "table" or type(Menu.ModifyMenu) ~= "function" then
    return
  end
  modernMenusHooked = true

  local function Inject(_, rootDescription, contextData)
    if not ArmoryEnabled() then
      return
    end
    local n, r = ResolveNameRealm(
      contextData,
      contextData and contextData.unit,
      contextData and contextData.name,
      contextData and (contextData.server or contextData.realm)
    )
    if not n then
      return
    end
    if rootDescription.CreateDivider then
      rootDescription:CreateDivider()
    end
    if rootDescription.CreateButton then
      rootDescription:CreateButton(BUTTON_TEXT, function()
        WhitemaneArmory.OpenArmory(n, r)
      end)
    end
  end

  for _, key in ipairs({
    "MENU_UNIT_SELF", "MENU_UNIT_PLAYER", "MENU_UNIT_PARTY",
    "MENU_UNIT_RAID_PLAYER", "MENU_UNIT_RAID", "MENU_UNIT_FRIEND",
    "MENU_UNIT_FRIEND_OFFLINE", "MENU_UNIT_BN_FRIEND",
    "MENU_UNIT_TARGET", "MENU_UNIT_FOCUS", "MENU_UNIT_CHAT_ROSTER",
    "MENU_UNIT_GUILD", "MENU_UNIT_GUILD_OFFLINE",
  }) do
    pcall(Menu.ModifyMenu, key, Inject)
  end
end

-- Deferred setup: Blizzard_UnitPopup may be LoD.
local f = CreateFrame("Frame")
f:RegisterEvent("PLAYER_LOGIN")
f:RegisterEvent("ADDON_LOADED")
f:SetScript("OnEvent", function(_, event, name)
  if event == "ADDON_LOADED" then
    if name == "Blizzard_UnitPopup" or name == "Blizzard_UnitPopupShared" then
      SetupAll(true)
      HookModernMenus()
      return
    end
    if name ~= "WhitemaneArmory" then
      return
    end
  end

  SetupAll(false)
  HookModernMenus()

  if event == "PLAYER_LOGIN" and C_Timer and C_Timer.After then
    C_Timer.After(1, function()
      SetupAll(false)
      HookModernMenus()
    end)
  end
end)

-- Try immediately in case UnitPopup is already loaded.
SetupAll(false)
HookModernMenus()
