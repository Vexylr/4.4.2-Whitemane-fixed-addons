-- Restores /spit after Blizzard removed it from the default emote list.
-- Behaves like /emote spits on <target> or /emote spits on the ground.

local CMD_KEY = "SPITEMOTE"

local function SpitSlashHandler(msg, editBox)
	if UnitExists("target") then
		local name = UnitName("target")
		if name and name ~= "" then
			SendChatMessage("spits on " .. name .. ".", "EMOTE")
			return
		end
	end
	SendChatMessage("spits on the ground.", "EMOTE")
end

SlashCmdList[CMD_KEY] = SpitSlashHandler
SLASH_SPITEMOTE1 = "/spit"

-- Blizzard may still register /spit; override after login so our handler wins.
local frame = CreateFrame("Frame")
frame:RegisterEvent("PLAYER_LOGIN")
frame:SetScript("OnEvent", function()
	SlashCmdList[CMD_KEY] = SpitSlashHandler
	if hash_SlashCmdList then
		hash_SlashCmdList["/SPIT"] = SpitSlashHandler
	end
end)
