# Whitemane Armory Data (weekly pack)

This folder is the **only thing** players need to replace each week.

## Update

1. Download the new `WhitemaneArmory_Data` zip.
2. Close WoW.
3. Delete:
   `Interface\AddOns\WhitemaneArmory_Data`
4. Unzip into `Interface\AddOns\` so you have:
   `Interface\AddOns\WhitemaneArmory_Data\WhitemaneArmory_Data.toc`
5. Enable **Whitemane Armory | Data** → `/reload`
6. `/warmory` — check the updated date. Done.

Do **not** replace `WhitemaneArmory` (the main addon) unless a core update dropped.
