# Whitemane Armory

Offline Gilneas raid progress for **Whitemane Cataclysm Classic**.

Two folders in `Interface\AddOns\`:

| Folder | What it is | How often |
|--------|------------|-----------|
| `WhitemaneArmory` | The addon (tooltips, menu, `/warmory`) | Rarely |
| `WhitemaneArmory_Data` | The character datapack | **Weekly** |

## Players — weekly update

1. Download `WhitemaneArmory_Data_YYYY-MM-DD.zip`
2. Close WoW
3. Delete `Interface\AddOns\WhitemaneArmory_Data`
4. Unzip into `Interface\AddOns\`
5. Enable **Whitemane Armory** + **Whitemane Armory | Data** → `/reload`
6. `/warmory` — confirm the **updated** date

Do **not** touch `WhitemaneArmory` for a normal weekly refresh.

## First-time install

1. Put **both** folders under `Interface\AddOns\`
2. Esc → AddOns → enable both
3. `/reload`

## Commands

| Command | Result |
|--------|--------|
| `/warmory` | Addon + datapack version / updated / char count |
| `/warmory help` | Full command list |
| `/warmory lookup Name` | Progress block |
| `/warmory who <partial>` | Name search by ilvl |
| `/warmory armory [Name]` | Copy armory URL popup |
| `/warmory config` | Options panel |

Alias: `/whitemanearmory`

## Maintainers

```powershell
cd "D:\Whitemane Cata Classic\WhitemaneRIO-POC"
python tools\refresh_datapack.py
powershell -File tools\package_datapack.ps1
```

Ship only the Data zip.
