# Details! Damage Meter

## [Details.20250425.13551.164](https://github.com/Tercioo/Details-Damage-Meter/tree/Details.20250425.13551.164) (2025-04-25)
[Full Changelog](https://github.com/Tercioo/Details-Damage-Meter/compare/Details.20250413.13519.164...Details.20250425.13551.164) 

- Libraries, Tocs, Updates.  
- Merge pull request #900 from Numynum/feature/damage-taken-tooltips  
    Show tooltips in the damage taken breakdown window  
- Add stagger damage to the overall damage taken breakout window  
- Reverse whitespace changes  
- Add overall damage taken overview to the breakdown window, allow clicking on a specific name to "lock" the breakdown, and minor code cleanup  
- When restoring the m+ state, send the event COMBAT\_MYTHICDUNGEON\_CONTINUE  
- Merge branch 'master' into feature/damage-taken-tooltips  
- Open Raid update with Heartseeking Health Injector (engineering tinker) for potion usage.  
- Updates for M+ addons and fix the old compare window which was using deprecated GetSpellInfo() call  
- Open Raid update  
- Show tooltips in the damage taken breakdown window, and prevent the highlighted NPC from resetting  