--[[
  Auction House Filters v2.0 — Whitemane Cata Classic (4.4.2)

  Classic AH UI has Usable/Uncollected checkboxes but the private server
  ignores those SendBrowseQuery flags. Upgrade Only does not exist in
  Classic FrameXML at all.

  Fix: after Blizzard fills BrowseResultsFrame.browseResults, replace that
  table with a filtered copy and Reset() the ItemList (AHCC-style).
]]

local VERSION = "2.0.3"
local ADDON = ...

local E = Enum and Enum.AuctionHouseFilter
local CAT = Enum and Enum.AuctionHouseFilterCategory

local F_USABLE = E and E.UsableOnly
local F_UNCOLLECTED = E and E.UncollectedOnly
local F_UPGRADES = E and E.UpgradesOnly

-- Classic clients often have the enum value even when the UI omits the checkbox.
if not F_UPGRADES and E then
  F_UPGRADES = 4 -- matches documented Enum.AuctionHouseFilter.UpgradesOnly
  pcall(function() E.UpgradesOnly = F_UPGRADES end)
end

local wantUsable, wantUpgrades, wantUncollected = false, false, false
local cache = {}
local CACHE_CAP = 500

-- Blizzard stalls paging when filtered getNumEntries()==0 (spinner, no refresh callback).
local SPARSE_THRESHOLD = 30
local MAX_PAGE_REQUESTS = 25
local PAGE_COOLDOWN = 0.35
local pageRequests = 0
local pageInFlight = false
local pageNextAt = 0

local EQUIP_SLOTS = {
  INVTYPE_HEAD = { 1 }, INVTYPE_NECK = { 2 }, INVTYPE_SHOULDER = { 3 },
  INVTYPE_BODY = { 4 }, INVTYPE_CHEST = { 5 }, INVTYPE_ROBE = { 5 },
  INVTYPE_WAIST = { 6 }, INVTYPE_LEGS = { 7 }, INVTYPE_FEET = { 8 },
  INVTYPE_WRIST = { 9 }, INVTYPE_HAND = { 10 }, INVTYPE_FINGER = { 11, 12 },
  INVTYPE_TRINKET = { 13, 14 }, INVTYPE_CLOAK = { 15 },
  INVTYPE_WEAPON = { 16, 17 }, INVTYPE_WEAPONMAINHAND = { 16 },
  INVTYPE_WEAPONOFFHAND = { 17 }, INVTYPE_2HWEAPON = { 16 },
  INVTYPE_SHIELD = { 17 }, INVTYPE_HOLDABLE = { 17 },
  INVTYPE_RANGED = { 18 }, INVTYPE_RANGEDRIGHT = { 18 },
  INVTYPE_THROWN = { 18 }, INVTYPE_RELIC = { 18 },
}

local function Print(msg)
  DEFAULT_CHAT_FRAME:AddMessage("|cff33ccffAuction House Filters " .. VERSION .. "|r: " .. tostring(msg))
end

local function Active()
  return wantUsable or wantUpgrades or wantUncollected
end

local function ArrayHas(t, v)
  if not t or v == nil then return false end
  for i = 1, #t do
    if t[i] == v then return true end
  end
  return false
end

local function EnsureUIStrings()
  AUCTION_HOUSE_FILTER_UPGRADES_ONLY = AUCTION_HOUSE_FILTER_UPGRADES_ONLY or "Upgrade Only"
  AUCTION_HOUSE_FILTER_USABLE_ONLY = AUCTION_HOUSE_FILTER_USABLE_ONLY or "Usable Only"
  AUCTION_HOUSE_FILTER_UNCOLLECTED_ONLY = AUCTION_HOUSE_FILTER_UNCOLLECTED_ONLY or "Uncollected Only"

  if type(AUCTION_HOUSE_FILTER_STRINGS) ~= "table" then
    AUCTION_HOUSE_FILTER_STRINGS = {}
  end
  if F_UPGRADES then
    AUCTION_HOUSE_FILTER_STRINGS[F_UPGRADES] = AUCTION_HOUSE_FILTER_UPGRADES_ONLY
  end
  if F_USABLE and not AUCTION_HOUSE_FILTER_STRINGS[F_USABLE] then
    AUCTION_HOUSE_FILTER_STRINGS[F_USABLE] = AUCTION_HOUSE_FILTER_USABLE_ONLY
  end
  if F_UNCOLLECTED and not AUCTION_HOUSE_FILTER_STRINGS[F_UNCOLLECTED] then
    AUCTION_HOUSE_FILTER_STRINGS[F_UNCOLLECTED] = AUCTION_HOUSE_FILTER_UNCOLLECTED_ONLY
  end

  if type(AUCTION_HOUSE_DEFAULT_FILTERS) ~= "table" then
    AUCTION_HOUSE_DEFAULT_FILTERS = {}
  end
  if F_UPGRADES and AUCTION_HOUSE_DEFAULT_FILTERS[F_UPGRADES] == nil then
    AUCTION_HOUSE_DEFAULT_FILTERS[F_UPGRADES] = false
  end
end

local function InjectUpgradeOnly(groups)
  if not F_UPGRADES or type(groups) ~= "table" then
    return groups
  end
  for _, g in ipairs(groups) do
    if g.filters and ArrayHas(g.filters, F_UPGRADES) then
      return groups
    end
  end
  local target
  for _, g in ipairs(groups) do
    if not CAT or g.category == CAT.Uncategorized or g.category == 0 then
      target = g
      break
    end
  end
  target = target or groups[1]
  if not target then
    return groups
  end
  target.filters = target.filters or {}
  local at = #target.filters + 1
  if F_USABLE then
    for i, f in ipairs(target.filters) do
      if f == F_USABLE then
        at = i + 1
        break
      end
    end
  end
  table.insert(target.filters, at, F_UPGRADES)
  return groups
end

local function SyncFlags(filtersArray)
  if type(filtersArray) == "table" then
    wantUsable = ArrayHas(filtersArray, F_USABLE)
    wantUpgrades = ArrayHas(filtersArray, F_UPGRADES)
    wantUncollected = ArrayHas(filtersArray, F_UNCOLLECTED)
    return
  end
  local btn = AuctionHouseFrame and AuctionHouseFrame.SearchBar and AuctionHouseFrame.SearchBar.FilterButton
  if not btn then
    return
  end
  if btn.CalculateFiltersArray then
    local ok, arr = pcall(btn.CalculateFiltersArray, btn)
    if ok and type(arr) == "table" then
      SyncFlags(arr)
      return
    end
  end
  local f = btn.filters
  if type(f) == "table" then
    wantUsable = not not (F_USABLE and f[F_USABLE])
    wantUpgrades = not not (F_UPGRADES and f[F_UPGRADES])
    wantUncollected = not not (F_UNCOLLECTED and f[F_UNCOLLECTED])
  end
end

local function CacheKey(itemKey)
  return (itemKey.itemID or 0) .. ":" .. (itemKey.itemLevel or 0) .. ":" .. (itemKey.itemSuffix or 0)
end

local function CacheSet(key, data)
  if not cache[key] then
    cache._n = (cache._n or 0) + 1
    if cache._n > CACHE_CAP then
      wipe(cache)
      cache._n = 1
    end
  end
  cache[key] = data
end

local function ItemLinkFromKey(itemKey)
  local id = itemKey.itemID
  local suffix = itemKey.itemSuffix or 0
  if suffix ~= 0 then
    return ("item:%d::::::%d"):format(id, suffix)
  end
  return "item:" .. id
end

local function InstantEquipLoc(itemID)
  if GetItemInfoInstant then
    return select(4, GetItemInfoInstant(itemID))
  end
  if C_Item and C_Item.GetItemInfoInstant then
    return select(4, C_Item.GetItemInfoInstant(itemID))
  end
  return nil
end

local function LowestEquipped(slots)
  local lowest = math.huge
  for i = 1, #slots do
    local link = GetInventoryItemLink("player", slots[i])
    if not link then
      lowest = 0
    else
      local ilvl = (GetDetailedItemLevelInfo and GetDetailedItemLevelInfo(link))
        or select(4, GetItemInfo(link))
        or 0
      if ilvl < lowest then
        lowest = ilvl
      end
    end
  end
  return (lowest == math.huge) and 0 or lowest
end

local function IsUncollected(itemID)
  if not itemID or not C_TransmogCollection then
    return false
  end
  if C_TransmogCollection.PlayerHasTransmogByItemInfo then
    local ok, has = pcall(C_TransmogCollection.PlayerHasTransmogByItemInfo, itemID)
    if ok and has ~= nil then
      return not has
    end
  end
  if C_TransmogCollection.PlayerHasTransmog then
    local ok, has = pcall(C_TransmogCollection.PlayerHasTransmog, itemID)
    if ok and has ~= nil then
      return not has
    end
  end
  -- API missing/broken: don't pretend everything is uncollected
  return false
end

local tip = CreateFrame("GameTooltip", "AHFilterFixTip", nil, "GameTooltipTemplate")
tip:SetOwner(UIParent, "ANCHOR_NONE")

local function HasRedRequirement(link)
  if not link then
    return false
  end
  tip:SetOwner(UIParent, "ANCHOR_NONE")
  tip:ClearLines()
  if not pcall(tip.SetHyperlink, tip, link) then
    return false
  end
  for i = 2, tip:NumLines() or 0 do
    local fs = _G["AHFilterFixTipTextLeft" .. i]
    if fs then
      local r, g, b = fs:GetTextColor()
      local text = fs:GetText()
      if text and text ~= "" and r and r > 0.9 and g and g < 0.35 and b and b < 0.35 then
        return true
      end
    end
  end
  return false
end

-- Returns usable, upgrade, uncollected, known
local function Evaluate(itemKey)
  local itemID = itemKey and itemKey.itemID
  if not itemID then
    return false, false, false, true
  end

  local key = CacheKey(itemKey)
  local keyIlvl = itemKey.itemLevel or 0
  local c = cache[key]
  if c and c.known then
    return c.usable, c.upgrade, c.uncollected, true
  end

  local instantEquip = InstantEquipLoc(itemID)
  local slots = instantEquip and EQUIP_SLOTS[instantEquip]

  -- Upgrade-only: non-gear never passes (Instant is sync — safe to reject).
  if wantUpgrades and not wantUsable and not slots then
    CacheSet(key, { known = true, usable = false, upgrade = false, uncollected = false })
    return false, false, false, true
  end

  local name, _, _, baseIlvl, reqLevel, _, _, _, equipLoc = GetItemInfo(itemID)
  if equipLoc and EQUIP_SLOTS[equipLoc] then
    slots = EQUIP_SLOTS[equipLoc]
  end

  if not name then
    if C_Item and C_Item.RequestLoadItemDataByID then
      pcall(C_Item.RequestLoadItemDataByID, itemID)
    end
    -- Fail open: don't hide until we know (except non-gear upgrade-only above).
    return true, not not (wantUpgrades and slots), false, false
  end

  local link = ItemLinkFromKey(itemKey)
  local playerLevel = UnitLevel("player") or 1
  local usable = true
  if reqLevel and reqLevel > playerLevel then
    usable = false
  elseif (wantUsable or wantUpgrades) and HasRedRequirement(link) then
    usable = false
  end

  local upgrade = false
  if usable and slots then
    local ilvl = (keyIlvl > 0 and keyIlvl) or baseIlvl or 0
    upgrade = ilvl > LowestEquipped(slots)
  end

  local uncollected = false
  if wantUncollected then
    uncollected = IsUncollected(itemID)
  end

  CacheSet(key, {
    known = true,
    usable = usable,
    upgrade = upgrade,
    uncollected = uncollected,
  })
  return usable, upgrade, uncollected, true
end

local function Passes(row)
  if not row or not row.itemKey then
    return false
  end
  local usable, upgrade, uncollected, known = Evaluate(row.itemKey)
  -- Unknown: keep row (fail open). Refilter when item info arrives.
  if not known then
    return true
  end
  if wantUsable and not usable then
    return false
  end
  if wantUpgrades and not upgrade then
    return false
  end
  if wantUncollected and not uncollected then
    return false
  end
  return true
end

local function FilterTable(src)
  if type(src) ~= "table" then
    return src, 0, 0
  end
  local out = {}
  local n = #src
  for i = 1, n do
    if Passes(src[i]) then
      out[#out + 1] = src[i]
    end
  end
  return out, #out, n
end

-- fullReplace=true → ItemList:Reset() (UPDATED path); else DirtyScrollFrame (ADDED path)
local function RefreshItemList(frame, fullReplace)
  local list = frame and frame.ItemList
  if not list then
    return
  end
  if fullReplace and list.Reset then
    list:Reset()
    return
  end
  if list.DirtyScrollFrame then
    list:DirtyScrollFrame()
  elseif list.RefreshScrollFrame then
    list:RefreshScrollFrame()
  elseif list.Reset then
    list:Reset()
  end
end

local function MaybeRequestMore(frame)
  if not Active() or not frame then
    return
  end
  if not C_AuctionHouse or not C_AuctionHouse.RequestMoreBrowseResults then
    return
  end
  if C_AuctionHouse.HasFullBrowseResults and C_AuctionHouse.HasFullBrowseResults() then
    return
  end
  local n = type(frame.browseResults) == "table" and #frame.browseResults or 0
  -- Empty is mandatory (UI never pages). Sparse helps fill a usable first screen.
  if n > 0 and n >= SPARSE_THRESHOLD then
    return
  end
  if pageInFlight or pageRequests >= MAX_PAGE_REQUESTS then
    return
  end
  local now = GetTime()
  if now < pageNextAt then
    return
  end

  pageInFlight = true
  pageNextAt = now + PAGE_COOLDOWN
  pageRequests = pageRequests + 1
  C_Timer.After(PAGE_COOLDOWN, function()
    pageInFlight = false
    if not Active() then
      return
    end
    if C_AuctionHouse.HasFullBrowseResults and C_AuctionHouse.HasFullBrowseResults() then
      return
    end
    pcall(C_AuctionHouse.RequestMoreBrowseResults)
  end)
end

local function ApplyFilterToFrame(frame, quiet, fullReplace)
  if not frame or type(frame.browseResults) ~= "table" then
    return
  end
  SyncFlags()
  if not Active() then
    return
  end

  local filtered, kept, total = FilterTable(frame.browseResults)
  if kept ~= total then
    frame.browseResults = filtered
    RefreshItemList(frame, fullReplace ~= false)
    if not quiet then
      Print(("kept %d / %d"):format(kept, total))
    end
  end

  MaybeRequestMore(frame)
end

local function GetBrowseFrame()
  return AuctionHouseFrame and AuctionHouseFrame.BrowseResultsFrame
end

-- Replace UpdateBrowseResults on the LIVE frame (mixin hooks miss already-created frames).
local function HookBrowseFrame(frame)
  if not frame or frame.AHFF_V2 then
    return frame and true or false
  end
  if type(frame.UpdateBrowseResults) ~= "function" then
    return false
  end

  frame.AHFF_V2 = true
  local orig = frame.UpdateBrowseResults

  frame.UpdateBrowseResults = function(self, addedBrowseResults)
    SyncFlags()

    if Active() and type(addedBrowseResults) == "table" then
      local filtered = FilterTable(addedBrowseResults)
      orig(self, filtered)
      -- ADDED: re-filter whole table; dirty scroll (don't jump to top)
      ApplyFilterToFrame(self, true, false)
      return
    end

    orig(self, addedBrowseResults)

    if Active() then
      -- UPDATED: full replace + Reset
      ApplyFilterToFrame(self, false, true)
    end
  end

  return true
end

local function HookFilterGroups()
  if not C_AuctionHouse or not C_AuctionHouse.GetFilterGroups or C_AuctionHouse.AHFF_V2_Groups then
    return
  end
  C_AuctionHouse.AHFF_V2_Groups = true
  local orig = C_AuctionHouse.GetFilterGroups
  C_AuctionHouse.GetFilterGroups = function(...)
    return InjectUpgradeOnly(orig(...))
  end
end

local function HookSendBrowseQuery()
  local ah = AuctionHouseFrame
  if not ah or ah.AHFF_V2_Send or type(ah.SendBrowseQuery) ~= "function" then
    return
  end
  ah.AHFF_V2_Send = true
  hooksecurefunc(ah, "SendBrowseQuery", function(_, _, _, _, filtersArray)
    wipe(cache)
    cache._n = 0
    pageRequests = 0
    pageInFlight = false
    pageNextAt = 0
    SyncFlags(filtersArray)
    if Active() then
      Print(("on —%s%s%s"):format(
        wantUsable and " usable" or "",
        wantUpgrades and " upgrade" or "",
        wantUncollected and " uncollected" or ""))
    end
  end)
end

local function PatchFilterButton()
  local btn = AuctionHouseFrame and AuctionHouseFrame.SearchBar and AuctionHouseFrame.SearchBar.FilterButton
  if not btn or not F_UPGRADES then
    return
  end
  -- SearchBar:OnShow → FilterButton:Reset() copies DEFAULT_FILTERS; keep our key present
  if btn.filters and btn.filters[F_UPGRADES] == nil then
    btn.filters[F_UPGRADES] = false
  end
  if not btn.AHFF_V2_ResetHook and type(btn.Reset) == "function" then
    btn.AHFF_V2_ResetHook = true
    hooksecurefunc(btn, "Reset", function(self)
      EnsureUIStrings()
      if self.filters and self.filters[F_UPGRADES] == nil then
        self.filters[F_UPGRADES] = false
      end
    end)
  end
end

local function Init()
  EnsureUIStrings()
  HookFilterGroups()
  HookSendBrowseQuery()
  PatchFilterButton()
  HookBrowseFrame(GetBrowseFrame())
end

local infoRefreshPending = false

local f = CreateFrame("Frame")
f:RegisterEvent("ADDON_LOADED")
f:RegisterEvent("PLAYER_LOGIN")
f:RegisterEvent("AUCTION_HOUSE_SHOW")
f:RegisterEvent("PLAYER_EQUIPMENT_CHANGED")
f:RegisterEvent("AUCTION_HOUSE_BROWSE_RESULTS_UPDATED")
f:RegisterEvent("AUCTION_HOUSE_BROWSE_RESULTS_ADDED")
f:RegisterEvent("GET_ITEM_INFO_RECEIVED")
f:SetScript("OnEvent", function(_, event, name)
  if event == "PLAYER_EQUIPMENT_CHANGED" then
    wipe(cache)
    cache._n = 0
    return
  end

  if event == "GET_ITEM_INFO_RECEIVED" then
    if not Active() or infoRefreshPending then
      return
    end
    infoRefreshPending = true
    C_Timer.After(0.2, function()
      infoRefreshPending = false
      local frame = GetBrowseFrame()
      if frame and Active() then
        -- Drop unknown cache entries by wiping; known results recompute cheaply
        wipe(cache)
        cache._n = 0
        ApplyFilterToFrame(frame, true, false)
      end
    end)
    return
  end

  if event == "AUCTION_HOUSE_BROWSE_RESULTS_UPDATED" or event == "AUCTION_HOUSE_BROWSE_RESULTS_ADDED" then
    -- Safety net if something else wrote browseResults after our hook
    C_Timer.After(0, function()
      local frame = GetBrowseFrame()
      if not frame then
        return
      end
      HookBrowseFrame(frame)
      ApplyFilterToFrame(frame, true, event == "AUCTION_HOUSE_BROWSE_RESULTS_UPDATED")
    end)
    return
  end

  if event == "ADDON_LOADED" then
    if name ~= ADDON and name ~= "Blizzard_AuctionHouseUI" then
      return
    end
    if name == ADDON then
      Print("loaded")
    end
  end

  Init()
  if event == "AUCTION_HOUSE_SHOW" then
    C_Timer.After(0, Init)
  end
end)

SLASH_AHFILTERFIX1 = "/ahff"
SlashCmdList.AHFILTERFIX = function()
  SyncFlags()
  local frame = GetBrowseFrame()
  local raw = frame and frame.browseResults and #frame.browseResults or "?"
  Print(("usable=%s upgrade=%s uncollected=%s | hooked=%s | rows=%s | enum up=%s"):format(
    tostring(wantUsable), tostring(wantUpgrades), tostring(wantUncollected),
    tostring(frame and frame.AHFF_V2 or false),
    tostring(raw),
    tostring(F_UPGRADES)))
  if frame then
    ApplyFilterToFrame(frame, false)
  end
end

Init()
