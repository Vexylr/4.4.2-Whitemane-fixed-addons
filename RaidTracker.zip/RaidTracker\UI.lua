--[[
  RaidTracker — weekly raid GUI with selectable themes
]]

local RT = RaidTracker
local C = {}

local function LoadColors()
  -- Prefer saved theme once SV/API are ready; fall back to ElvUI defaults at file load.
  local id = RT.DEFAULT_THEME or "elvui"
  if RT.GetSelectedThemeId and RaidTrackerDB then
    id = RT.GetSelectedThemeId()
  end
  wipe(C)
  if RT.CopyThemeColors then
    RT.CopyThemeColors(id, C)
  end
  if not C.accent and RT.CopyThemeColors then
    RT.CopyThemeColors("elvui", C)
  end
end

-- Safe defaults for frame construction before PLAYER_LOGIN ApplyTheme.
LoadColors()

local themePanel

local WIDTH = 680
local BASE_HEIGHT = 410
local BASE_ROWS = 4 -- height tuned for BH/BWD/BoT/To4W
local PAD = 12
local COL_GAP = 10
local ROW_H = 42
local ROW_GAP = 5
local HEADER_H = 52
local CHAR_BAR_H = 34
-- Status columns: wide enough for "PARTIAL", evenly split by a center divider.
local STATUS_W = 72
local STATUS_PAD = 10
local STATUS_GAP = 12 -- space between N and H columns (divider centered in this)
local ACTIVE = {}

local function FrameHeightForRows(n)
  return BASE_HEIGHT + math.max(0, (n or BASE_ROWS) - BASE_ROWS) * (ROW_H + ROW_GAP)
end

local function SetBackdrop(frame, bg, border)
  if frame.SetBackdrop then
    frame:SetBackdrop({
      bgFile = "Interface\\Buttons\\WHITE8X8",
      edgeFile = "Interface\\Buttons\\WHITE8X8",
      edgeSize = 1,
      insets = { left = 1, right = 1, top = 1, bottom = 1 },
    })
    frame:SetBackdropColor(bg[1], bg[2], bg[3], bg[4])
    frame:SetBackdropBorderColor(border[1], border[2], border[3], border[4])
  end
end

local function Font(parent, size, flags, justify)
  local fs = parent:CreateFontString(nil, "OVERLAY")
  fs:SetFont("Fonts\\FRIZQT__.TTF", size or 12, flags or "")
  fs:SetJustifyH(justify or "LEFT")
  fs:SetTextColor(1, 1, 1, 1)
  return fs
end

local function ClassColor(classFile)
  if classFile and RAID_CLASS_COLORS and RAID_CLASS_COLORS[classFile] then
    local c = RAID_CLASS_COLORS[classFile]
    return c.r, c.g, c.b
  end
  return 0.8, 0.8, 0.8
end

local function StatusColor(kind)
  if kind == "DONE" then
    return C.done
  end
  if kind == "PARTIAL" then
    return C.partial
  end
  if kind == "OPEN" then
    return C.open
  end
  return C.unlocked
end

local function SlotDisplay(slot, expected)
  local text, kind = RT.SlotLabel(slot, expected)
  return text, StatusColor(kind), kind
end

-- ── Main frame ───────────────────────────────────────────────

local UI = CreateFrame("Frame", "RaidTrackerFrame", UIParent, "BackdropTemplate")
UI:SetSize(WIDTH, FrameHeightForRows(BASE_ROWS))
UI:SetFrameStrata("HIGH")
UI:SetClampedToScreen(true)
UI:SetMovable(true)
UI:EnableMouse(true)
UI:RegisterForDrag("LeftButton")
UI:SetScript("OnDragStart", function(self)
  self:StartMoving()
end)
UI:SetScript("OnDragStop", function(self)
  self:StopMovingOrSizing()
  local db = RT.GetDB()
  local point, _, relPoint, x, y = self:GetPoint(1)
  db.point, db.relPoint, db.x, db.y = point, relPoint, x, y
end)
UI:Hide()
SetBackdrop(UI, C.bg, C.border)

-- Soul-energy rim
local accentTop = UI:CreateTexture(nil, "ARTWORK")
accentTop:SetHeight(2)
accentTop:SetPoint("TOPLEFT", 1, -1)
accentTop:SetPoint("TOPRIGHT", -1, -1)
accentTop:SetColorTexture(C.accent[1], C.accent[2], C.accent[3], 0.95)

local accentBot = UI:CreateTexture(nil, "ARTWORK")
accentBot:SetHeight(1)
accentBot:SetPoint("BOTTOMLEFT", 1, 1)
accentBot:SetPoint("BOTTOMRIGHT", -1, 1)
accentBot:SetColorTexture(C.header10[1], C.header10[2], C.header10[3], 0.45)

-- Header
local header = CreateFrame("Frame", nil, UI, "BackdropTemplate")
header:SetPoint("TOPLEFT", PAD, -PAD)
header:SetPoint("TOPRIGHT", -PAD, -PAD)
header:SetHeight(HEADER_H)
SetBackdrop(header, C.panel, C.border)

-- Close
local closeBtn = CreateFrame("Button", nil, header)
closeBtn:SetSize(28, 28)
closeBtn:SetPoint("TOPRIGHT", -6, -6)
closeBtn:SetFrameLevel(header:GetFrameLevel() + 40)
closeBtn:SetScript("OnClick", function()
  UI:Hide() -- OnHide closes char dropdown + theme panel
end)
local closeX = Font(closeBtn, 14, "OUTLINE", "CENTER")
closeX:SetPoint("CENTER", 0, 1)
closeX:SetText("X")
closeX:SetTextColor(C.subtitle[1], C.subtitle[2], C.subtitle[3], 1)
closeBtn:SetScript("OnEnter", function()
  closeX:SetTextColor(C.close[1], C.close[2], C.close[3], 1)
end)
closeBtn:SetScript("OnLeave", function()
  closeX:SetTextColor(C.subtitle[1], C.subtitle[2], C.subtitle[3], 1)
end)

-- Settings cog (theme picker)
local gearBtn = CreateFrame("Button", nil, header)
gearBtn:SetSize(28, 28)
gearBtn:SetPoint("RIGHT", closeBtn, "LEFT", -2, 0)
gearBtn:SetFrameLevel(header:GetFrameLevel() + 40)
local gearIcon = gearBtn:CreateTexture(nil, "ARTWORK")
gearIcon:SetTexture("Interface\\Buttons\\UI-OptionsButton")
gearIcon:SetSize(16, 16)
gearIcon:SetPoint("CENTER", 0, 0)
gearIcon:SetVertexColor(C.subtitle[1], C.subtitle[2], C.subtitle[3], 1)
gearBtn:SetScript("OnEnter", function()
  gearIcon:SetVertexColor(C.accent[1], C.accent[2], C.accent[3], 1)
  GameTooltip:SetOwner(gearBtn, "ANCHOR_LEFT")
  GameTooltip:SetText("Themes", C.accent[1], C.accent[2], C.accent[3])
  GameTooltip:AddLine("Pick a color scheme", 0.7, 0.7, 0.7)
  GameTooltip:Show()
end)
gearBtn:SetScript("OnLeave", function()
  if not (themePanel and themePanel:IsShown()) then
    gearIcon:SetVertexColor(C.subtitle[1], C.subtitle[2], C.subtitle[3], 1)
  end
  GameTooltip:Hide()
end)

local title = Font(header, 18, "OUTLINE")
title:SetPoint("TOPLEFT", 14, -10)
title:SetPoint("RIGHT", gearBtn, "LEFT", -8, 0)
title:SetText("|cff" .. (C.titleHex or "1784d1") .. "WEEKLY|r RAID TRACKER")
title:SetTextColor(C.title[1], C.title[2], C.title[3], 1)

-- Reset countdown sits under the title, clear of the buttons.
local weekResetFS = Font(header, 12, "OUTLINE")
weekResetFS:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -4)
weekResetFS:SetText("Resets in —")
weekResetFS:SetTextColor(C.resetHot[1], C.resetHot[2], C.resetHot[3], 1)

-- Character bar
local charBar = CreateFrame("Frame", nil, UI, "BackdropTemplate")
charBar:SetPoint("TOPLEFT", header, "BOTTOMLEFT", 0, -8)
charBar:SetPoint("TOPRIGHT", header, "BOTTOMRIGHT", 0, -8)
charBar:SetHeight(CHAR_BAR_H)
SetBackdrop(charBar, C.panel, C.border)

local charLabel = Font(charBar, 11)
charLabel:SetPoint("LEFT", 12, 0)
charLabel:SetText("CHARACTER")
charLabel:SetTextColor(C.subtitle[1], C.subtitle[2], C.subtitle[3], 1)

local DROP_W = 168
local DROP_H = 22
local DROP_ROW_H = 22

-- Character dropdown (right side of char bar).
local charDrop = CreateFrame("Button", nil, charBar, "BackdropTemplate")
charDrop:SetSize(DROP_W, DROP_H)
charDrop:SetPoint("RIGHT", -12, 0)
charDrop:SetFrameLevel(charBar:GetFrameLevel() + 25)
SetBackdrop(charDrop, C.dropBtn, C.border)
charDrop:EnableMouse(true)
charDrop:RegisterForClicks("LeftButtonUp")

local charDropText = Font(charDrop, 12, "OUTLINE")
charDropText:SetPoint("LEFT", 8, 0)
charDropText:SetPoint("RIGHT", -20, 0)
charDropText:SetJustifyH("LEFT")
charDropText:SetText("—")

local charDropArrow = Font(charDrop, 10, nil, "CENTER")
charDropArrow:SetPoint("RIGHT", -6, 1)
charDropArrow:SetText("v")
charDropArrow:SetTextColor(C.subtitle[1], C.subtitle[2], C.subtitle[3], 1)

-- Week range sits left of the dropdown on the right side of the bar.
local weekLabel = Font(charBar, 12, "OUTLINE", "RIGHT")
weekLabel:SetPoint("RIGHT", charDrop, "LEFT", -10, 0)
weekLabel:SetText("— / —")
weekLabel:SetTextColor(C.ember[1], C.ember[2], C.ember[3], 0.85)

local dropList = CreateFrame("Frame", nil, UI, "BackdropTemplate")
dropList:SetFrameStrata("DIALOG")
dropList:SetFrameLevel(UI:GetFrameLevel() + 20)
dropList:SetPoint("TOPRIGHT", charDrop, "BOTTOMRIGHT", 0, -2)
dropList:SetWidth(DROP_W)
dropList:Hide()
SetBackdrop(dropList, C.drop, C.border)

-- Below header controls / char dropdown so gear + X stay clickable while open.
local dropCatcher = CreateFrame("Button", nil, UI)
dropCatcher:SetAllPoints(UI)
dropCatcher:SetFrameLevel(math.max(1, UI:GetFrameLevel() + 2))
dropCatcher:EnableMouse(true)
dropCatcher:Hide()
header:SetFrameLevel(UI:GetFrameLevel() + 20)
charBar:SetFrameLevel(UI:GetFrameLevel() + 20)
charDrop:SetFrameLevel(charBar:GetFrameLevel() + 5)

local dropRows = {}

local function CloseCharDrop()
  dropList:Hide()
  dropCatcher:Hide()
  charDropArrow:SetText("v")
  charDrop:SetBackdropBorderColor(C.border[1], C.border[2], C.border[3], C.border[4])
  charDropArrow:SetTextColor(C.subtitle[1], C.subtitle[2], C.subtitle[3], 1)
end

charDrop:SetScript("OnEnter", function(self)
  self:SetBackdropBorderColor(C.accent[1], C.accent[2], C.accent[3], 0.7)
  charDropArrow:SetTextColor(C.accent[1], C.accent[2], C.accent[3], 1)
end)
charDrop:SetScript("OnLeave", function(self)
  if not dropList:IsShown() then
    self:SetBackdropBorderColor(C.border[1], C.border[2], C.border[3], C.border[4])
    charDropArrow:SetTextColor(C.subtitle[1], C.subtitle[2], C.subtitle[3], 1)
  end
end)

local function NeedsRealmSuffix(list)
  local realms = {}
  local count = 0
  for _, entry in ipairs(list) do
    local realm = entry.data and entry.data.realm
    if realm and not realms[realm] then
      realms[realm] = true
      count = count + 1
      if count > 1 then
        return true
      end
    end
  end
  return false
end

local function CharDisplayName(data, key, showRealm)
  local name = (data and data.name) or (key and key:match("^([^-]+)")) or key or "?"
  if showRealm then
    local realm = data and data.realm
    if not realm and key and key:find("-", 1, true) then
      realm = key:match("^[^-]+%-(.+)$")
    end
    if realm and realm ~= "" then
      return name .. "-" .. realm
    end
  end
  return name
end

local function OpenCharDrop()
  local list = RT.GetCharacterList()
  local selected = select(1, RT.GetSelectedCharacter())
  local me = RT.CharKey and RT.CharKey()
  local showRealm = NeedsRealmSuffix(list)
  local n = math.max(#list, 1)

  for i = 1, n do
    local entry = list[i]
    local row = dropRows[i]
    if not row then
      row = CreateFrame("Button", nil, dropList, "BackdropTemplate")
      row:SetHeight(DROP_ROW_H)
      SetBackdrop(row, { 0, 0, 0, 0 }, { 0, 0, 0, 0 })
      row.label = Font(row, 12, "OUTLINE")
      row.label:SetPoint("LEFT", 8, 0)
      row.label:SetPoint("RIGHT", -8, 0)
      row.label:SetJustifyH("LEFT")
      row:RegisterForClicks("LeftButtonUp")
      row:SetScript("OnEnter", function(self)
        self:SetBackdropColor(C.accent[1], C.accent[2], C.accent[3], 0.18)
      end)
      row:SetScript("OnLeave", function(self)
        if self._selected then
          self:SetBackdropColor(C.accent[1], C.accent[2], C.accent[3], 0.10)
        else
          self:SetBackdropColor(0, 0, 0, 0)
        end
      end)
      dropRows[i] = row
    end

    row:ClearAllPoints()
    row:SetPoint("TOPLEFT", 2, -2 - (i - 1) * DROP_ROW_H)
    row:SetPoint("TOPRIGHT", -2, -2 - (i - 1) * DROP_ROW_H)

    if entry then
      local isSelected = entry.key == selected
      local label = CharDisplayName(entry.data, entry.key, showRealm)
      if me and entry.key == me then
        label = label .. "  (you)"
      end
      row._key = entry.key
      row._selected = isSelected
      row.label:SetText(label)
      local r, g, b = ClassColor(entry.data and entry.data.class)
      row._classR, row._classG, row._classB = r, g, b
      row.label:SetTextColor(r, g, b, 1)
      if isSelected then
        row:SetBackdropColor(C.accent[1], C.accent[2], C.accent[3], 0.10)
      else
        row:SetBackdropColor(0, 0, 0, 0)
      end
      row:SetScript("OnClick", function(self)
        if self._key then
          RT.SelectCharacter(self._key)
          CloseCharDrop()
          UI:Refresh()
        end
      end)
    else
      row._key = nil
      row._selected = false
      row._classR, row._classG, row._classB = C.subtitle[1], C.subtitle[2], C.subtitle[3]
      row.label:SetText("Log each alt once to sync")
      row.label:SetTextColor(C.subtitle[1], C.subtitle[2], C.subtitle[3], 1)
      row:SetBackdropColor(0, 0, 0, 0)
      row:SetScript("OnClick", CloseCharDrop)
    end
    row:Show()
  end

  for i = n + 1, #dropRows do
    dropRows[i]:Hide()
  end

  local widest = DROP_W
  for i = 1, n do
    local w = (dropRows[i].label:GetStringWidth() or 0) + 28
    if w > widest then
      widest = w
    end
  end
  dropList:SetWidth(math.min(widest, 280))
  dropList:SetHeight(n * DROP_ROW_H + 4)
  dropCatcher:Show()
  dropList:Show()
  charDropArrow:SetText("^")
  charDrop:SetBackdropBorderColor(C.accent[1], C.accent[2], C.accent[3], 0.7)
end

dropCatcher:SetScript("OnClick", CloseCharDrop)

charDrop:SetScript("OnClick", function()
  if dropList:IsShown() then
    CloseCharDrop()
  else
    OpenCharDrop()
  end
end)

UI:HookScript("OnHide", CloseCharDrop)

-- Columns
local function CreateColumn(parent, titleText, headerKey, anchorPoint, relFrame, relPoint, xOff)
  local col = CreateFrame("Frame", nil, parent, "BackdropTemplate")
  col:SetPoint(anchorPoint, relFrame, relPoint, xOff, 0)
  col:SetPoint("BOTTOM", parent, "BOTTOM", 0, PAD)
  SetBackdrop(col, C.panel, C.border)
  col.headerKey = headerKey

  local titleColor = C[headerKey] or C.accent
  local stripe = col:CreateTexture(nil, "ARTWORK")
  stripe:SetHeight(3)
  stripe:SetPoint("TOPLEFT", 1, -1)
  stripe:SetPoint("TOPRIGHT", -1, -1)
  stripe:SetColorTexture(titleColor[1], titleColor[2], titleColor[3], 0.85)
  col.stripe = stripe

  local h = Font(col, 14, "OUTLINE", "CENTER")
  h:SetPoint("TOP", 0, -12)
  h:SetText(titleText)
  h:SetTextColor(titleColor[1], titleColor[2], titleColor[3], 1)
  col.titleFS = h

  local sub = Font(col, 10, nil, "CENTER")
  sub:SetPoint("TOP", h, "BOTTOM", 0, -2)
  sub:SetText("Normal  ·  Heroic")
  sub:SetTextColor(C.subtitle[1], C.subtitle[2], C.subtitle[3], 1)
  col.subFS = sub

  local rule = col:CreateTexture(nil, "ARTWORK")
  rule:SetHeight(1)
  rule:SetPoint("TOPLEFT", 10, -42)
  rule:SetPoint("TOPRIGHT", -10, -42)
  rule:SetColorTexture(C.line[1], C.line[2], C.line[3], C.line[4])
  col.rule = rule

  col.rows = {}
  col.bodyTop = -48
  return col
end

local colWidth = (WIDTH - PAD * 2 - COL_GAP) / 2
local col10 = CreateColumn(UI, "10  MAN", "header10", "TOPLEFT", charBar, "BOTTOMLEFT", 0)
col10:SetWidth(colWidth)
local col25 = CreateColumn(UI, "25  MAN", "header25", "TOPRIGHT", charBar, "BOTTOMRIGHT", 0)
col25:SetWidth(colWidth)

local BOX_H = ROW_H - 8
local BOX_GAP = 6

local function StyleStatusBox(box, borderColor, lit)
  local bgA = lit and 0.16 or 0.08
  local bd = borderColor or C.line
  SetBackdrop(box, { C.accent[1], C.accent[2], C.accent[3], bgA }, { bd[1], bd[2], bd[3], lit and 0.85 or 0.45 })
end

local function CreateStatusBox(row, labelText, labelColorKey)
  local box = CreateFrame("Frame", nil, row, "BackdropTemplate")
  box:SetSize(STATUS_W, BOX_H)
  box:EnableMouse(true)
  box:SetFrameLevel(row:GetFrameLevel() + 2)
  StyleStatusBox(box, C.line, false)

  box.label = Font(box, 9, nil, "CENTER")
  box.label:SetPoint("TOP", 0, -4)
  box.label:SetWidth(STATUS_W - 4)
  box.label:SetText(labelText)
  box.labelKey = labelColorKey

  box.val = Font(box, 12, "OUTLINE", "CENTER")
  box.val:SetPoint("TOP", box.label, "BOTTOM", 0, -1)
  box.val:SetWidth(STATUS_W - 4)
  box.val:SetJustifyH("CENTER")
  if box.val.SetWordWrap then
    box.val:SetWordWrap(false)
  end

  box:SetScript("OnEnter", function(self)
    StyleStatusBox(self, self._borderColor or C.line, true)
    if self._showTooltip and self._tooltipTitle then
      GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
      GameTooltip:ClearLines()
      GameTooltip:AddLine(self._tooltipTitle, C.accent[1], C.accent[2], C.accent[3])
      if self._tooltipSub then
        GameTooltip:AddLine(self._tooltipSub, C.subtitle[1], C.subtitle[2], C.subtitle[3])
      end
      if self._tooltipBosses then
        for _, boss in ipairs(self._tooltipBosses) do
          -- ReadyCheck icons read clearly at 16px; ●/○ glyphs are tiny in Friz.
          local icon = boss.killed
            and "|TInterface\\RaidFrame\\ReadyCheck-Ready:16:16:0:0|t "
            or "|TInterface\\RaidFrame\\ReadyCheck-Waiting:16:16:0:0|t "
          GameTooltip:AddLine(
            icon .. (boss.name or "?"),
            boss.killed and 0.85 or 0.50,
            boss.killed and 0.92 or 0.50,
            boss.killed and 0.85 or 0.52
          )
        end
      end

      GameTooltip:Show()
    end
  end)
  box:SetScript("OnLeave", function(self)
    StyleStatusBox(self, self._borderColor or C.line, false)
    GameTooltip:Hide()
  end)

  return box
end

local function CreateRaidRow(parent, index)
  local row = CreateFrame("Frame", nil, parent, "BackdropTemplate")
  row:SetHeight(ROW_H)
  row:SetPoint("TOPLEFT", 8, parent.bodyTop - (index - 1) * (ROW_H + ROW_GAP))
  row:SetPoint("TOPRIGHT", -8, parent.bodyTop - (index - 1) * (ROW_H + ROW_GAP))
  SetBackdrop(row, index % 2 == 0 and C.rowEven or C.rowOdd, { 0, 0, 0, 0 })

  -- Left accent pip
  row.pip = row:CreateTexture(nil, "ARTWORK")
  row.pip:SetWidth(2)
  row.pip:SetPoint("TOPLEFT", 0, 0)
  row.pip:SetPoint("BOTTOMLEFT", 0, 0)
  row.pip:SetColorTexture(C.accentDim[1], C.accentDim[2], C.accentDim[3], C.accentDim[4])

  -- Boxed N / H status cells (hover tooltip only when PARTIAL).
  row.hBox = CreateStatusBox(row, "H", "labelH")
  row.hBox:SetPoint("RIGHT", row, "RIGHT", -STATUS_PAD, 0)

  row.nBox = CreateStatusBox(row, "N", "labelN")
  row.nBox:SetPoint("RIGHT", row.hBox, "LEFT", -BOX_GAP, 0)

  -- Convenience aliases used by Fill/Recolor
  row.hLabel = row.hBox.label
  row.hVal = row.hBox.val
  row.nLabel = row.nBox.label
  row.nVal = row.nBox.val

  row.tag = Font(row, 12, "OUTLINE")
  row.tag:SetPoint("TOPLEFT", 10, -7)
  row.tag:SetTextColor(C.raid[1], C.raid[2], C.raid[3], 1)

  row.raidName = Font(row, 9)
  row.raidName:SetPoint("TOPLEFT", row.tag, "BOTTOMLEFT", 0, -2)
  row.raidName:SetPoint("RIGHT", row.nBox, "LEFT", -8, 0)
  row.raidName:SetJustifyH("LEFT")
  row.raidName:SetTextColor(C.subtitle[1], C.subtitle[2], C.subtitle[3], 1)
  if row.raidName.SetWordWrap then
    row.raidName:SetWordWrap(false)
  end
  if row.raidName.SetNonSpaceWrap then
    row.raidName:SetNonSpaceWrap(false)
  end

  row:EnableMouse(true)
  row:SetScript("OnEnter", function(self)
    self:SetBackdropColor(C.accent[1], C.accent[2], C.accent[3], 0.12)
  end)
  row:SetScript("OnLeave", function(self)
    local bg = self._even and C.rowEven or C.rowOdd
    self:SetBackdropColor(bg[1], bg[2], bg[3], bg[4])
  end)

  return row
end

-- Pre-create a row slot for every known raid (FL/DS start hidden until visited).
for i = 1, #RT.RAIDS do
  col10.rows[i] = CreateRaidRow(col10, i)
  col10.rows[i]._even = (i % 2 == 0)
  col10.rows[i]:Hide()
  col25.rows[i] = CreateRaidRow(col25, i)
  col25.rows[i]._even = (i % 2 == 0)
  col25.rows[i]:Hide()
end

local function SyncActiveLayout()
  wipe(ACTIVE)
  local list = RT.ActiveRaids()
  for i, raid in ipairs(list) do
    ACTIVE[i] = raid
  end
  local n = #ACTIVE
  for i = 1, #RT.RAIDS do
    local r10 = col10.rows[i]
    local r25 = col25.rows[i]
    if i <= n then
      local y = col10.bodyTop - (i - 1) * (ROW_H + ROW_GAP)
      r10:ClearAllPoints()
      r10:SetPoint("TOPLEFT", 8, y)
      r10:SetPoint("TOPRIGHT", -8, y)
      r10._even = (i % 2 == 0)
      r10:Show()
      r25:ClearAllPoints()
      r25:SetPoint("TOPLEFT", 8, y)
      r25:SetPoint("TOPRIGHT", -8, y)
      r25._even = (i % 2 == 0)
      r25:Show()
    else
      r10:Hide()
      r25:Hide()
    end
  end
  UI:SetHeight(FrameHeightForRows(n > 0 and n or BASE_ROWS))
end

SyncActiveLayout()

local function BindStatusBox(box, raidName, modeLabel, slot, expected)
  local text, color, kind = SlotDisplay(slot, expected)
  box.val:SetText(text)
  box.val:SetTextColor(color[1], color[2], color[3], 1)
  box._borderColor = color
  StyleStatusBox(box, color, false)

  -- Boss list tooltip only for PARTIAL lockouts.
  if kind == "PARTIAL" and slot and slot.bosses and #slot.bosses > 0 then
    box._showTooltip = true
    box._tooltipTitle = raidName
    local frac = RT.ProgressFraction(slot)
    box._tooltipSub = modeLabel .. (frac and ("  ·  " .. frac) or "  ·  PARTIAL")
    box._tooltipBosses = slot.bosses
  else
    box._showTooltip = false
    box._tooltipTitle = nil
    box._tooltipSub = nil
    box._tooltipBosses = nil
  end
end

local function PipForSlots(nSlot, hSlot, hasHeroic)
  local function kind(slot)
    if not slot or not slot.locked or slot.status == "OPEN" then
      return "OPEN"
    end
    if slot.status == "DONE" or (slot.total > 0 and slot.killed >= slot.total) then
      return "DONE"
    end
    return "PARTIAL"
  end
  local nk = kind(nSlot)
  local hk = hasHeroic and kind(hSlot) or "OPEN"
  if nk == "DONE" and (not hasHeroic or hk == "DONE") then
    return C.done
  end
  if nk ~= "OPEN" or (hasHeroic and hk ~= "OPEN") then
    return C.partial
  end
  return C.open
end

local function FillRow(row, raid, sizeData)
  row.tag:SetText(raid.tag)
  row.raidName:SetText(raid.short or raid.name)

  local nSlot = sizeData and sizeData.N
  local hSlot = sizeData and sizeData.H

  if raid.encountersH then
    row.hBox:Show()
    row.nBox:ClearAllPoints()
    row.nBox:SetPoint("RIGHT", row.hBox, "LEFT", -BOX_GAP, 0)
    BindStatusBox(row.hBox, raid.name, "Heroic", hSlot, raid.encountersH)
  else
    row.hBox:Hide()
    row.nBox:ClearAllPoints()
    row.nBox:SetPoint("RIGHT", row, "RIGHT", -STATUS_PAD, 0)
  end
  BindStatusBox(row.nBox, raid.name, "Normal", nSlot, raid.encountersN)

  local pip = PipForSlots(nSlot, hSlot, raid.encountersH ~= nil)
  row.pip:SetColorTexture(pip[1], pip[2], pip[3], 0.85)
  row:Show()
end

local function FillColumn(col, sizeKey, data)
  local side = data and data.lockouts and data.lockouts[sizeKey]
  for i, raid in ipairs(ACTIVE) do
    local row = col.rows[i]
    if row then
      FillRow(row, raid, side and side[raid.key])
    end
  end
  for i = #ACTIVE + 1, #col.rows do
    col.rows[i]:Hide()
  end
end

function UI:ApplyPosition()
  local db = RT.GetDB()
  self:ClearAllPoints()
  self:SetPoint(db.point or "CENTER", UIParent, db.relPoint or "CENTER", db.x or 0, db.y or 0)
  self:SetScale(db.scale or 1)
end

local function UpdateWeeklyResetText()
  local s = RT.GetWeeklyResetSeconds()
  if not s then
    weekResetFS:SetText("Resets in —")
    weekResetFS:SetTextColor(C.reset[1], C.reset[2], C.reset[3], 1)
  else
    weekResetFS:SetText("Resets in " .. RT.FormatDuration(s))
    if s < 6 * 3600 then
      weekResetFS:SetTextColor(C.close[1], C.close[2], C.close[3], 1)
    elseif s > 6.5 * 24 * 3600 then
      weekResetFS:SetTextColor(C.ember[1], C.ember[2], C.ember[3], 1)
    else
      weekResetFS:SetTextColor(C.resetHot[1], C.resetHot[2], C.resetHot[3], 1)
    end
  end
  if RT.IsTestMode() then
    weekLabel:SetText("|cffff6666TEST DATA|r")
  else
    weekLabel:SetText(RT.FormatWeekLabel())
  end
end

function UI:OnActiveRaidsChanged()
  SyncActiveLayout()
  if self:IsShown() then
    self:Refresh({ skipSave = true })
  end
end

function UI:Refresh(opts)
  opts = opts or {}
  SyncActiveLayout()
  -- Persist the LOGGED-IN character only (never overwrites a viewed alt's row).
  -- Skip saves in test mode so demo data never hits SavedVariables.
  if not opts.skipSave and not RT.IsTestMode() then
    RT.ApplyWeeklyRollover()
    RT.SaveCurrentCharacter()
  end
  local key, data = RT.GetSelectedCharacter()

  if not data then
    local lockouts = RT.ScanLockouts()
    data = {
      name = UnitName("player"),
      realm = GetRealmName(),
      class = select(2, UnitClass("player")),
      updated = GetServerTime and GetServerTime() or time(),
      lockouts = lockouts,
    }
    key = key or (data.name or "?")
  elseif data.lockouts then
    RT.ExpireStaleLockouts(data.lockouts)
  end

  if RT.IsTestMode() then
    data = {
      name = data.name or UnitName("player"),
      realm = data.realm or GetRealmName(),
      class = data.class or select(2, UnitClass("player")),
      updated = data.updated,
      lockouts = RT.BuildTestLockouts(),
    }
  end

  local list = RT.GetCharacterList()
  local showRealm = NeedsRealmSuffix(list)
  local r, g, b = ClassColor(data.class)
  local dropLabel = CharDisplayName(data, key, showRealm)
  if RT.IsTestMode() then
    dropLabel = dropLabel .. "  |cffff6666TEST|r"
  end
  charDropText:SetText(dropLabel)
  charDropText:SetTextColor(r, g, b, 1)

  -- Keep list in sync if open (e.g. after lockout update while browsing).
  if dropList:IsShown() then
    OpenCharDrop()
  end

  UpdateWeeklyResetText()
  FillColumn(col10, "10", data)
  FillColumn(col25, "25", data)
end

local tickerElapsed = 0

function UI:ResetTicker()
  tickerElapsed = 0
end

UI:SetScript("OnUpdate", function(self, elapsed)
  if not self:IsShown() then
    return
  end
  tickerElapsed = tickerElapsed + elapsed
  if tickerElapsed < 30 then
    return
  end
  tickerElapsed = 0
  UpdateWeeklyResetText()
  -- Never paint real lockouts over /rt test demo data.
  if RT.IsTestMode() then
    self:Refresh({ skipSave = true })
    return
  end
  -- Re-expire cached lockouts so the UI flips to OPEN after reset without reload.
  local _, data = RT.GetSelectedCharacter()
  if data and data.lockouts then
    RT.ExpireStaleLockouts(data.lockouts)
    FillColumn(col10, "10", data)
    FillColumn(col25, "25", data)
  end
end)

function UI:Toggle()
  if self:IsShown() then
    self:Hide()
  else
    self:ApplyPosition()
    local db = RT.GetDB()
    local me = RT.CharKey and RT.CharKey()
    -- Keep last viewed alt; only default to logged-in when nothing valid is selected.
    if not (db.selectedChar and db.characters[db.selectedChar]) then
      if me then
        RT.SelectCharacter(me)
      end
    end
    self:Show() -- OnShow handles RequestRaidInfo + single Refresh
  end
end

UI:SetScript("OnShow", function(self)
  tickerElapsed = 0
  if RequestRaidInfo then
    RequestRaidInfo()
  end
  self:Refresh()
end)

-- Minimap button — LibDBIcon-style layout (icon sits inside TrackingBorder hole)
local mm = CreateFrame("Button", "RaidTrackerMinimapButton", Minimap)
mm:SetSize(32, 32)
mm:SetFrameStrata("MEDIUM")
mm:SetFrameLevel(8)
mm:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")

local mmBg = mm:CreateTexture(nil, "BACKGROUND")
mmBg:SetSize(20, 20)
mmBg:SetPoint("TOPLEFT", 7, -5)
mmBg:SetTexture("Interface\\Minimap\\UI-Minimap-Background")
mmBg:SetVertexColor(0.08, 0.08, 0.09, 1)

local mmIcon = mm:CreateTexture(nil, "ARTWORK")
mmIcon:SetSize(17, 17)
mmIcon:SetPoint("TOPLEFT", 7, -5)
mmIcon:SetTexture("Interface\\AddOns\\RaidTracker\\Media\\minimap")
mmIcon:SetTexCoord(0.05, 0.95, 0.05, 0.95)

local mmBorder = mm:CreateTexture(nil, "OVERLAY")
mmBorder:SetSize(53, 53)
mmBorder:SetPoint("TOPLEFT")
mmBorder:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")

local angle = 220
local function UpdateMinimapPos()
  local radius = (Minimap:GetWidth() / 2) + 5
  local x = math.cos(math.rad(angle)) * radius
  local y = math.sin(math.rad(angle)) * radius
  mm:ClearAllPoints()
  mm:SetPoint("CENTER", Minimap, "CENTER", x, y)
end

mm:RegisterForDrag("LeftButton")
mm:SetScript("OnDragStart", function(self)
  self:SetScript("OnUpdate", function()
    local mx, my = GetCursorPosition()
    local cx, cy = Minimap:GetCenter()
    local scale = Minimap:GetEffectiveScale()
    angle = math.deg(math.atan2(my / scale - cy, mx / scale - cx))
    UpdateMinimapPos()
  end)
end)
mm:SetScript("OnDragStop", function(self)
  self:SetScript("OnUpdate", nil)
  local db = RT.GetDB()
  db.minimapAngle = angle
end)
mm:SetScript("OnClick", function()
  UI:Toggle()
end)
mm:SetScript("OnEnter", function(self)
  GameTooltip:SetOwner(self, "ANCHOR_LEFT")
  GameTooltip:AddLine("RaidTracker", C.accent[1], C.accent[2], C.accent[3])
  local s = RT.GetWeeklyResetSeconds()
  if s then
    GameTooltip:AddDoubleLine("Weekly reset", RT.FormatDuration(s), 0.7, 0.7, 0.7, C.resetHot[1], C.resetHot[2], C.resetHot[3])
  end
  GameTooltip:Show()
end)
mm:SetScript("OnLeave", function()
  GameTooltip:Hide()
end)

-- ── Theme settings panel ─────────────────────────────────────
local THEME_ROW_H = 26
local THEME_PANEL_W = 248
local THEME_TAB_H = 24
local THEME_PAD = 10
local themeActiveGroup = "Style"
local themeRows = {}
local themeTabs = {}

themePanel = CreateFrame("Frame", "RaidTrackerThemePanel", UIParent, "BackdropTemplate")
themePanel:SetFrameStrata("FULLSCREEN_DIALOG")
themePanel:SetFrameLevel(UI:GetFrameLevel() + 100)
themePanel:SetClampedToScreen(true)
themePanel:SetWidth(THEME_PANEL_W)
themePanel:Hide()
SetBackdrop(themePanel, C.drop, C.border)

local themeTitle = Font(themePanel, 11, "OUTLINE")
themeTitle:SetPoint("TOPLEFT", THEME_PAD, -10)
themeTitle:SetText("THEMES")
themeTitle:SetTextColor(C.accent[1], C.accent[2], C.accent[3], 1)

local themeRule = themePanel:CreateTexture(nil, "ARTWORK")
themeRule:SetHeight(1)
themeRule:SetPoint("TOPLEFT", THEME_PAD, -30)
themeRule:SetPoint("TOPRIGHT", -THEME_PAD, -30)
themeRule:SetColorTexture(C.line[1], C.line[2], C.line[3], 0.35)

local themeTabBar = CreateFrame("Frame", nil, themePanel)
themeTabBar:SetPoint("TOPLEFT", THEME_PAD, -38)
themeTabBar:SetPoint("TOPRIGHT", -THEME_PAD, -38)
themeTabBar:SetHeight(THEME_TAB_H)

local themeBody = CreateFrame("Frame", nil, themePanel)
themeBody:SetPoint("TOPLEFT", THEME_PAD, -70)
themeBody:SetPoint("TOPRIGHT", -THEME_PAD, -70)

local themeCatcher = CreateFrame("Button", nil, UIParent)
themeCatcher:SetFrameStrata("FULLSCREEN_DIALOG")
themeCatcher:SetFrameLevel(themePanel:GetFrameLevel() - 1)
themeCatcher:SetAllPoints(UIParent)
themeCatcher:EnableMouse(true)
themeCatcher:Hide()

local function HideThemePanel()
  themePanel:Hide()
  themeCatcher:Hide()
  gearIcon:SetVertexColor(C.subtitle[1], C.subtitle[2], C.subtitle[3], 1)
end

local function StyleThemeTabs()
  for _, tab in ipairs(themeTabs) do
    local on = tab.group == themeActiveGroup
    tab.label:SetTextColor(
      on and C.accent[1] or C.subtitle[1],
      on and C.accent[2] or C.subtitle[2],
      on and C.accent[3] or C.subtitle[3],
      1
    )
    tab.underline:SetColorTexture(
      C.accent[1], C.accent[2], C.accent[3],
      on and 0.95 or 0
    )
    tab:SetBackdropColor(C.accent[1], C.accent[2], C.accent[3], on and 0.10 or 0)
  end
end

local function StyleThemeRows()
  local selected = RT.GetSelectedThemeId()
  for _, row in ipairs(themeRows) do
    local isSelected = row.theme.id == selected
    row.selected = isSelected
    local a = row.theme.accent
    local e = row.theme.ember or a
    row.swatchA:SetColorTexture(a[1], a[2], a[3], 1)
    row.swatchB:SetColorTexture(e[1], e[2], e[3], 1)
    row.check:SetText(isSelected and "●" or "")
    row.check:SetTextColor(a[1], a[2], a[3], 1)
    row.label:SetTextColor(
      isSelected and a[1] or 0.88,
      isSelected and a[2] or 0.88,
      isSelected and a[3] or 0.90,
      1
    )
    row:SetBackdropColor(C.accent[1], C.accent[2], C.accent[3], isSelected and 0.16 or 0)
    row:SetBackdropBorderColor(C.accent[1], C.accent[2], C.accent[3], isSelected and 0.35 or 0)
  end
  themeTitle:SetTextColor(C.accent[1], C.accent[2], C.accent[3], 1)
  themeRule:SetColorTexture(C.line[1], C.line[2], C.line[3], 0.40)
  SetBackdrop(themePanel, C.drop, C.border)
  StyleThemeTabs()
end

local function LayoutThemeRows()
  local y = 0
  for _, row in ipairs(themeRows) do
    if row.theme.group == themeActiveGroup then
      row:ClearAllPoints()
      row:SetPoint("TOPLEFT", 0, y)
      row:SetPoint("TOPRIGHT", 0, y)
      row:Show()
      y = y - (THEME_ROW_H + 2)
    else
      row:Hide()
    end
  end
  themeBody:SetHeight(math.max(1, -y))
  themePanel:SetHeight(-y + 86)
  StyleThemeRows()
end

local function SelectThemeGroup(group)
  themeActiveGroup = group
  LayoutThemeRows()
end

local function CreateThemePanel()
  local groups = RT.THEME_GROUPS or { "Style", "Nature", "Class" }
  local tabW = (THEME_PANEL_W - THEME_PAD * 2) / #groups
  for i, group in ipairs(groups) do
    local tab = CreateFrame("Button", nil, themeTabBar, "BackdropTemplate")
    tab:SetSize(tabW - 2, THEME_TAB_H)
    tab:SetPoint("TOPLEFT", (i - 1) * tabW, 0)
    tab.group = group
    SetBackdrop(tab, { 0, 0, 0, 0 }, { 0, 0, 0, 0 })

    tab.label = Font(tab, 10, "OUTLINE")
    tab.label:SetPoint("CENTER", 0, 1)
    tab.label:SetText(group:upper())

    tab.underline = tab:CreateTexture(nil, "ARTWORK")
    tab.underline:SetHeight(2)
    tab.underline:SetPoint("BOTTOMLEFT", 4, 1)
    tab.underline:SetPoint("BOTTOMRIGHT", -4, 1)
    tab.underline:SetColorTexture(1, 1, 1, 0)

    tab:SetScript("OnClick", function(self)
      SelectThemeGroup(self.group)
    end)
    tab:SetScript("OnEnter", function(self)
      if self.group ~= themeActiveGroup then
        self:SetBackdropColor(C.accent[1], C.accent[2], C.accent[3], 0.08)
      end
    end)
    tab:SetScript("OnLeave", function()
      StyleThemeTabs()
    end)

    themeTabs[#themeTabs + 1] = tab
  end

  for _, theme in ipairs(RT.GetThemeList()) do
    local row = CreateFrame("Button", nil, themeBody, "BackdropTemplate")
    row:SetHeight(THEME_ROW_H)
    row.theme = theme
    SetBackdrop(row, { 0, 0, 0, 0 }, { 0, 0, 0, 0 })

    row.swatchA = row:CreateTexture(nil, "ARTWORK")
    row.swatchA:SetSize(10, 10)
    row.swatchA:SetPoint("LEFT", 8, 0)

    row.swatchB = row:CreateTexture(nil, "ARTWORK")
    row.swatchB:SetSize(10, 10)
    row.swatchB:SetPoint("LEFT", row.swatchA, "RIGHT", 2, 0)

    row.label = Font(row, 11, "")
    row.label:SetPoint("LEFT", row.swatchB, "RIGHT", 8, 0)
    row.label:SetPoint("RIGHT", -22, 0)
    row.label:SetJustifyH("LEFT")
    row.label:SetText(theme.label)

    row.check = Font(row, 10, "")
    row.check:SetPoint("RIGHT", -8, 0)
    row.check:SetJustifyH("RIGHT")
    row.check:SetText("")

    row:SetScript("OnEnter", function(self)
      self:SetBackdropColor(C.accent[1], C.accent[2], C.accent[3], 0.22)
      self:SetBackdropBorderColor(C.accent[1], C.accent[2], C.accent[3], 0.25)
    end)
    row:SetScript("OnLeave", function(self)
      self:SetBackdropColor(C.accent[1], C.accent[2], C.accent[3], self.selected and 0.16 or 0)
      self:SetBackdropBorderColor(C.accent[1], C.accent[2], C.accent[3], self.selected and 0.35 or 0)
    end)
    row:SetScript("OnClick", function(self)
      RT.SetTheme(self.theme.id)
      StyleThemeRows()
    end)

    themeRows[#themeRows + 1] = row
  end

  local cur = RT.GetTheme(RT.GetSelectedThemeId and RT.GetSelectedThemeId() or "elvui")
  themeActiveGroup = (cur and cur.group) or "Style"
  LayoutThemeRows()
end

local function ToggleThemePanel()
  if themePanel:IsShown() then
    HideThemePanel()
    return
  end
  CloseCharDrop()
  local cur = RT.GetTheme(RT.GetSelectedThemeId())
  if cur and cur.group and cur.group ~= themeActiveGroup then
    themeActiveGroup = cur.group
  end
  LayoutThemeRows()
  themePanel:ClearAllPoints()
  themePanel:SetPoint("TOPRIGHT", gearBtn, "BOTTOMRIGHT", 0, -4)
  themePanel:Show()
  themeCatcher:Show()
  gearIcon:SetVertexColor(C.accent[1], C.accent[2], C.accent[3], 1)
end

themeCatcher:SetScript("OnClick", HideThemePanel)
gearBtn:SetScript("OnClick", ToggleThemePanel)
UI:HookScript("OnHide", HideThemePanel)
CreateThemePanel()

local function RecolorColumn(col)
  SetBackdrop(col, C.panel, C.border)
  local hc = C[col.headerKey] or C.accent
  col.stripe:SetColorTexture(hc[1], hc[2], hc[3], 0.85)
  col.titleFS:SetTextColor(hc[1], hc[2], hc[3], 1)
  col.subFS:SetTextColor(C.subtitle[1], C.subtitle[2], C.subtitle[3], 1)
  col.rule:SetColorTexture(C.line[1], C.line[2], C.line[3], C.line[4])
  for _, row in ipairs(col.rows) do
    local bg = row._even and C.rowEven or C.rowOdd
    SetBackdrop(row, bg, { 0, 0, 0, 0 })
    row.nLabel:SetTextColor(C.labelN[1], C.labelN[2], C.labelN[3], 1)
    row.hLabel:SetTextColor(C.labelH[1], C.labelH[2], C.labelH[3], 1)
    row.tag:SetTextColor(C.raid[1], C.raid[2], C.raid[3], 1)
    row.raidName:SetTextColor(C.subtitle[1], C.subtitle[2], C.subtitle[3], 1)
    if row.nBox then
      StyleStatusBox(row.nBox, row.nBox._borderColor or C.line, false)
    end
    if row.hBox then
      StyleStatusBox(row.hBox, row.hBox._borderColor or C.line, false)
    end
  end
end

local function RecolorCharacterDropdown()
  SetBackdrop(charDrop, C.dropBtn, C.border)
  SetBackdrop(dropList, C.drop, C.border)
  charDropArrow:SetTextColor(C.subtitle[1], C.subtitle[2], C.subtitle[3], 1)
  for _, row in ipairs(dropRows) do
    if row:IsShown() then
      row.label:SetTextColor(
        row._classR or C.subtitle[1],
        row._classG or C.subtitle[2],
        row._classB or C.subtitle[3],
        1
      )
      row:SetBackdropColor(C.accent[1], C.accent[2], C.accent[3], row._selected and 0.10 or 0)
    end
  end
end

function UI:ApplyTheme()
  LoadColors()
  SetBackdrop(UI, C.bg, C.border)
  SetBackdrop(header, C.panel, C.border)
  SetBackdrop(charBar, C.panel, C.border)
  accentTop:SetColorTexture(C.accent[1], C.accent[2], C.accent[3], 0.95)
  accentBot:SetColorTexture(C.header10[1], C.header10[2], C.header10[3], 0.45)
  title:SetText("|cff" .. (C.titleHex or "1784d1") .. "WEEKLY|r RAID TRACKER")
  title:SetTextColor(C.title[1], C.title[2], C.title[3], 1)
  charLabel:SetTextColor(C.subtitle[1], C.subtitle[2], C.subtitle[3], 1)
  weekLabel:SetTextColor(C.ember[1], C.ember[2], C.ember[3], 0.85)
  closeX:SetTextColor(C.subtitle[1], C.subtitle[2], C.subtitle[3], 1)
  gearIcon:SetVertexColor(
    themePanel:IsShown() and C.accent[1] or C.subtitle[1],
    themePanel:IsShown() and C.accent[2] or C.subtitle[2],
    themePanel:IsShown() and C.accent[3] or C.subtitle[3],
    1
  )
  RecolorCharacterDropdown()
  RecolorColumn(col10)
  RecolorColumn(col25)
  StyleThemeRows()
  if self:IsShown() then
    -- Recolor only — don't rescan lockouts on every theme click.
    self:Refresh({ skipSave = true })
  else
    UpdateWeeklyResetText()
  end
end

local boot = CreateFrame("Frame")
boot:RegisterEvent("PLAYER_LOGIN")
boot:SetScript("OnEvent", function()
  local db = RT.GetDB()
  angle = db.minimapAngle or 220
  UpdateMinimapPos()
  UI:ApplyPosition()
  UI:ApplyTheme()
  mm:Show()
end)

-- Park minimap button until login positions it.
mm:Hide()

-- ESC closes
tinsert(UISpecialFrames, "RaidTrackerFrame")

RT.UI = UI
