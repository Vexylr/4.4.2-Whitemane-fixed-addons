--[[
  RaidTracker — theme definitions
  Style (raids/UI) · Nature · Class
]]

RaidTracker = RaidTracker or {}
local RT = RaidTracker

local function C4(r, g, b, a)
  return { r, g, b, a or 1 }
end

local function Build(id, label, group, titleHex, accent, secondary)
  local r, g, b = accent[1], accent[2], accent[3]
  local sr, sg, sb = secondary[1], secondary[2], secondary[3]
  local dark = 0.045
  return {
    id = id,
    label = label,
    group = group,
    titleHex = titleHex,
    bg        = C4(dark + r * 0.06, dark + g * 0.06, dark + b * 0.08, 0.93),
    panel     = C4(0.06 + r * 0.10, 0.06 + g * 0.10, 0.07 + b * 0.12, 0.91),
    rowEven   = C4(r, g, b, 0.05),
    rowOdd    = C4(1, 1, 1, 0),
    border    = C4(0.12 + r * 0.25, 0.12 + g * 0.25, 0.14 + b * 0.28, 1),
    accent    = C4(r, g, b, 1),
    accentDim = C4(r, g, b, 0.40),
    ember     = C4(math.min(1, r + 0.12), math.min(1, g + 0.12), math.min(1, b + 0.15), 1),
    title     = C4(0.94, 0.94, 0.96, 1),
    subtitle  = C4(0.45 + r * 0.20, 0.45 + g * 0.20, 0.48 + b * 0.22, 1),
    header10  = C4(sr, sg, sb, 1),
    header25  = C4(r, g, b, 1),
    raid      = C4(0.86 + r * 0.08, 0.86 + g * 0.08, 0.88 + b * 0.08, 1),
    labelN    = C4(0.55 + sr * 0.25, 0.55 + sg * 0.25, 0.58 + sb * 0.25, 1),
    labelH    = C4(math.min(1, r + 0.08), math.min(1, g + 0.05), math.min(1, b + 0.08), 1),
    -- Status colors are fixed across themes (semantic, not accent-tinted).
    open      = C4(0.35, 0.90, 0.45, 1), -- green
    partial   = C4(1.00, 0.86, 0.25, 1), -- yellow
    done      = C4(0.95, 0.32, 0.32, 1), -- red
    zero      = C4(0.42, 0.42, 0.48, 1),
    unlocked  = C4(0.34, 0.34, 0.40, 1),
    reset     = C4(0.52, 0.52, 0.60, 1),
    resetHot  = C4(math.min(1, r + 0.15), math.min(1, g + 0.10), math.min(1, b + 0.12), 1),
    close     = C4(0.90, 0.40, 0.45, 1),
    line      = C4(r, g, b, 0.14),
    drop      = C4(0.05 + r * 0.05, 0.05 + g * 0.05, 0.06 + b * 0.08, 0.97),
    dropBtn   = C4(0.08 + r * 0.10, 0.08 + g * 0.10, 0.10 + b * 0.12, 0.96),
  }
end

local STYLE = {
  Build("elvui", "ElvUI", "Style", "1784d1",
    { 0.09, 0.52, 0.82 }, { 0.45, 0.78, 1.00 }),
  Build("bwd", "Blackwing Descent", "Style", "c41e3a",
    { 0.72, 0.12, 0.18 }, { 0.55, 0.42, 0.35 }),
  Build("bot", "Bastion of Twilight", "Style", "a335ee",
    { 0.64, 0.21, 0.93 }, { 0.78, 0.48, 1.00 }),
  Build("to4w", "Throne of Four Winds", "Style", "69ccf0",
    { 0.35, 0.70, 0.95 }, { 0.90, 0.94, 1.00 }),
  Build("fl", "Firelands", "Style", "ffb000",
    { 1.00, 0.55, 0.08 }, { 1.00, 0.88, 0.25 }),
  Build("ds", "Dragon Soul", "Style", "d4a017",
    { 0.85, 0.65, 0.18 }, { 0.40, 0.72, 0.98 }),
}

local NATURE = {
  Build("rainforest", "Rainforest", "Nature", "2ecc71",
    { 0.18, 0.72, 0.40 }, { 0.45, 0.85, 0.55 }),
  Build("woodland", "Woodland", "Nature", "8b6914",
    { 0.45, 0.55, 0.22 }, { 0.72, 0.58, 0.32 }),
  Build("thunderstorm", "Thunderstorm", "Nature", "5b8def",
    { 0.35, 0.45, 0.85 }, { 0.85, 0.90, 1.00 }),
  Build("mist", "Morning Mist", "Nature", "7fbfb0",
    { 0.45, 0.70, 0.68 }, { 0.75, 0.88, 0.85 }),
  Build("aurora", "Aurora", "Nature", "40e0d0",
    { 0.25, 0.85, 0.75 }, { 0.55, 0.45, 0.95 }),
}

local CLASS = {
  Build("deathknight", "Death Knight", "Class", "c41f3b",
    { 0.77, 0.12, 0.23 }, { 0.95, 0.40, 0.45 }),
  Build("druid", "Druid", "Class", "ff7d0a",
    { 1.00, 0.49, 0.04 }, { 0.95, 0.72, 0.30 }),
  Build("hunter", "Hunter", "Class", "abd473",
    { 0.67, 0.83, 0.45 }, { 0.45, 0.78, 0.55 }),
  Build("mage", "Mage", "Class", "69ccf0",
    { 0.41, 0.80, 0.94 }, { 0.70, 0.88, 1.00 }),
  Build("paladin", "Paladin", "Class", "f58cba",
    { 0.96, 0.55, 0.73 }, { 1.00, 0.78, 0.88 }),
  Build("priest", "Priest", "Class", "ffffff",
    { 0.85, 0.88, 0.92 }, { 0.65, 0.75, 0.95 }),
  Build("rogue", "Rogue", "Class", "fff569",
    { 1.00, 0.96, 0.41 }, { 0.85, 0.78, 0.35 }),
  Build("shaman", "Shaman", "Class", "0070de",
    { 0.00, 0.44, 0.87 }, { 0.35, 0.70, 1.00 }),
  Build("warlock", "Warlock", "Class", "9482c9",
    { 0.58, 0.51, 0.79 }, { 0.75, 0.55, 0.95 }),
  Build("warrior", "Warrior", "Class", "c79c6e",
    { 0.78, 0.61, 0.43 }, { 0.90, 0.75, 0.55 }),
}

-- ElvUI
do
  local t = STYLE[1]
  t.bg = C4(0.06, 0.06, 0.07, 0.92)
  t.panel = C4(0.09, 0.09, 0.11, 0.88)
  t.border = C4(0, 0, 0, 1)
  t.header10 = C4(0.45, 0.78, 1.00, 1)
  t.header25 = C4(1.00, 0.72, 0.38, 1)
end

-- BWD: Nefarian — cold obsidian, blood crimson, bronze (NOT lava).
do
  local t = STYLE[2]
  t.bg = C4(0.04, 0.03, 0.04, 0.95)
  t.panel = C4(0.10, 0.07, 0.08, 0.93)
  t.border = C4(0.22, 0.10, 0.10, 1)
  t.accent = C4(0.78, 0.14, 0.18, 1)       -- blood
  t.accentDim = C4(0.50, 0.08, 0.10, 0.45)
  t.ember = C4(0.72, 0.55, 0.38, 1)         -- bronze
  t.header10 = C4(0.70, 0.55, 0.42, 1)      -- aged bronze
  t.header25 = C4(0.85, 0.18, 0.22, 1)      -- crimson
  t.subtitle = C4(0.55, 0.42, 0.42, 1)
  t.resetHot = C4(0.90, 0.35, 0.30, 1)
  t.line = C4(0.70, 0.20, 0.20, 0.18)
  t.rowEven = C4(0.70, 0.12, 0.15, 0.06)
  t.titleHex = "c41e3a"
end

-- BoT
do
  local t = STYLE[3]
  t.bg = C4(0.06, 0.04, 0.10, 0.94)
  t.panel = C4(0.11, 0.07, 0.16, 0.92)
  t.border = C4(0.28, 0.14, 0.40, 1)
  t.header10 = C4(0.70, 0.55, 0.95, 1)
  t.header25 = C4(0.85, 0.30, 0.95, 1)
end

-- To4W
do
  local t = STYLE[4]
  t.bg = C4(0.05, 0.07, 0.11, 0.93)
  t.panel = C4(0.08, 0.11, 0.16, 0.91)
  t.title = C4(0.96, 0.98, 1.00, 1)
  t.header10 = C4(0.92, 0.95, 1.00, 1)
  t.header25 = C4(0.40, 0.75, 0.98, 1)
end

-- Firelands: Ragnaros — bright sulfur / molten gold (warm, hot, distinct from BWD).
do
  local t = STYLE[5]
  t.bg = C4(0.08, 0.04, 0.01, 0.94)
  t.panel = C4(0.14, 0.07, 0.02, 0.92)
  t.border = C4(0.45, 0.22, 0.04, 1)
  t.accent = C4(1.00, 0.62, 0.10, 1)        -- molten gold-orange
  t.accentDim = C4(0.95, 0.40, 0.05, 0.45)
  t.ember = C4(1.00, 0.90, 0.35, 1)          -- sulfur yellow
  t.header10 = C4(1.00, 0.88, 0.30, 1)       -- sulfur
  t.header25 = C4(1.00, 0.45, 0.05, 1)       -- lava
  t.subtitle = C4(0.70, 0.50, 0.28, 1)
  t.resetHot = C4(1.00, 0.80, 0.20, 1)
  t.line = C4(1.00, 0.55, 0.10, 0.20)
  t.rowEven = C4(1.00, 0.50, 0.08, 0.07)
  t.titleHex = "ffb000"
end

-- Dragon Soul
do
  local t = STYLE[6]
  t.bg = C4(0.05, 0.05, 0.07, 0.93)
  t.panel = C4(0.09, 0.08, 0.11, 0.91)
  t.accent = C4(0.85, 0.65, 0.18, 1)
  t.header10 = C4(0.40, 0.72, 0.98, 1)
  t.header25 = C4(0.92, 0.72, 0.28, 1)
  t.ember = C4(0.55, 0.75, 1.00, 1)
  t.titleHex = "d4a017"
end

-- Rainforest
do
  local t = NATURE[1]
  t.bg = C4(0.03, 0.07, 0.04, 0.94)
  t.panel = C4(0.06, 0.12, 0.08, 0.92)
  t.border = C4(0.12, 0.32, 0.18, 1)
  t.header10 = C4(0.55, 0.90, 0.55, 1)
  t.header25 = C4(0.20, 0.70, 0.40, 1)
  t.ember = C4(0.70, 0.95, 0.55, 1)
end

-- Woodland
do
  local t = NATURE[2]
  t.bg = C4(0.06, 0.05, 0.03, 0.94)
  t.panel = C4(0.11, 0.09, 0.05, 0.92)
  t.border = C4(0.28, 0.22, 0.10, 1)
  t.header10 = C4(0.75, 0.65, 0.35, 1)
  t.header25 = C4(0.45, 0.58, 0.25, 1)
  t.ember = C4(0.85, 0.70, 0.40, 1)
end

-- Thunderstorm
do
  local t = NATURE[3]
  t.bg = C4(0.04, 0.05, 0.10, 0.95)
  t.panel = C4(0.08, 0.09, 0.16, 0.93)
  t.border = C4(0.20, 0.25, 0.40, 1)
  t.accent = C4(0.55, 0.65, 1.00, 1)
  t.ember = C4(0.95, 0.95, 1.00, 1)         -- lightning flash
  t.header10 = C4(0.85, 0.90, 1.00, 1)
  t.header25 = C4(0.45, 0.55, 0.95, 1)
  t.resetHot = C4(0.90, 0.92, 1.00, 1)
end

-- Morning Mist
do
  local t = NATURE[4]
  t.bg = C4(0.05, 0.07, 0.08, 0.92)
  t.panel = C4(0.09, 0.12, 0.13, 0.90)
  t.border = C4(0.25, 0.35, 0.35, 1)
  t.header10 = C4(0.80, 0.90, 0.88, 1)
  t.header25 = C4(0.40, 0.70, 0.68, 1)
end

-- Aurora
do
  local t = NATURE[5]
  t.bg = C4(0.04, 0.05, 0.09, 0.94)
  t.panel = C4(0.07, 0.09, 0.14, 0.92)
  t.border = C4(0.18, 0.30, 0.40, 1)
  t.accent = C4(0.30, 0.85, 0.78, 1)
  t.ember = C4(0.65, 0.50, 1.00, 1)
  t.header10 = C4(0.40, 0.90, 0.85, 1)
  t.header25 = C4(0.65, 0.45, 0.95, 1)
end

RT.THEME_ORDER = {}
RT.THEMES = {}
RT.THEME_GROUPS = { "Style", "Nature", "Class" }

local function register(list)
  for _, theme in ipairs(list) do
    RT.THEMES[theme.id] = theme
    RT.THEME_ORDER[#RT.THEME_ORDER + 1] = theme.id
  end
end

register(STYLE)
register(NATURE)
register(CLASS)

RT.DEFAULT_THEME = "elvui"

function RT.GetTheme(id)
  return RT.THEMES[id] or RT.THEMES[RT.DEFAULT_THEME]
end

function RT.GetThemeList(groupFilter)
  local list = {}
  for _, id in ipairs(RT.THEME_ORDER) do
    local theme = RT.THEMES[id]
    if theme and (not groupFilter or theme.group == groupFilter) then
      list[#list + 1] = theme
    end
  end
  return list
end

function RT.CopyThemeColors(id, dest)
  local src = RT.GetTheme(id)
  dest = dest or {}
  for k, v in pairs(src) do
    if type(v) == "table" and v[1] then
      dest[k] = { v[1], v[2], v[3], v[4] }
    end
  end
  dest.id = src.id
  dest.label = src.label
  dest.group = src.group
  dest.titleHex = src.titleHex
  return dest
end
