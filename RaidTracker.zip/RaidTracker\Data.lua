--[[
  RaidTracker — Cataclysm raid definitions
  Active: BH / BWD / BoT / To4W
  FL / DS: hidden until the player enters that raid once (account-wide).
]]

RaidTracker = RaidTracker or {}

-- Display order, short tags, expected encounters, name matchers.
-- Heroic BoT includes Sinestra (5); Normal is 4.
-- requiresVisit = true → hidden until RaidTracker marks the raid visited.
RaidTracker.RAIDS = {
  {
    key = "BH",
    tag = "BH",
    name = "Baradin Hold",
    encountersN = 3,
    encountersH = nil, -- no heroic
    match = { "baradin" },
    bossesN = {
      "Argaloth",
      "Occu'thar",
      "Alizabal",
    },
  },
  {
    key = "BWD",
    tag = "BWD",
    name = "Blackwing Descent",
    encountersN = 6,
    encountersH = 6,
    match = { "blackwing descent", "blackwing" },
    bossesN = {
      "Magmaw",
      "Omnotron Defense System",
      "Maloriak",
      "Atramedes",
      "Chimaeron",
      "Nefarian",
    },
  },
  {
    key = "BOT",
    tag = "BoT",
    name = "The Bastion of Twilight",
    encountersN = 4,
    encountersH = 5,
    match = { "bastion of twilight", "bastion" },
    bossesN = {
      "Halfus Wyrmbreaker",
      "Theralion and Valiona",
      "Ascendant Council",
      "Cho'gall",
    },
    bossesH = {
      "Halfus Wyrmbreaker",
      "Theralion and Valiona",
      "Ascendant Council",
      "Cho'gall",
      "Sinestra",
    },
  },
  {
    key = "TOT4W",
    tag = "To4W",
    name = "Throne of the Four Winds",
    short = "Throne of Four Winds",
    encountersN = 2,
    encountersH = 2,
    match = { "throne of the four", "four winds" },
    bossesN = {
      "Conclave of Wind",
      "Al'Akir",
    },
  },
  {
    key = "FL",
    tag = "FL",
    name = "Firelands",
    encountersN = 7,
    encountersH = 7,
    match = { "firelands" },
    -- InstanceMapID from GetInstanceInfo() return #8 (locale-safe).
    instanceMapIDs = { 720 },
    requiresVisit = true,
    bossesN = {
      "Beth'tilac",
      "Lord Rhyolith",
      "Alysrazor",
      "Shannox",
      "Baleroc",
      "Majordomo Staghelm",
      "Ragnaros",
    },
  },
  {
    key = "DS",
    tag = "DS",
    name = "Dragon Soul",
    encountersN = 8,
    encountersH = 8,
    match = { "dragon soul" },
    -- InstanceMapID from GetInstanceInfo() return #8 (locale-safe).
    instanceMapIDs = { 967 },
    requiresVisit = true,
    bossesN = {
      "Morchok",
      "Warlord Zon'ozz",
      "Yor'sahj the Unsleeping",
      "Hagara the Stormbinder",
      "Ultraxion",
      "Warmaster Blackhorn",
      "Spine of Deathwing",
      "Madness of Deathwing",
    },
  },
}

function RaidTracker.IsRaidActive(raid)
  if not raid then
    return false
  end
  if not raid.requiresVisit then
    return true
  end
  -- Visit unlock still applies in /rt test — FL/DS stay hidden until entered.
  if RaidTracker.IsRaidVisited then
    return RaidTracker.IsRaidVisited(raid.key)
  end
  return false
end

function RaidTracker.ActiveRaids()
  local list = {}
  for _, raid in ipairs(RaidTracker.RAIDS) do
    if RaidTracker.IsRaidActive(raid) then
      list[#list + 1] = raid
    end
  end
  return list
end

function RaidTracker.RaidByKey(key)
  if not key then
    return nil
  end
  for _, raid in ipairs(RaidTracker.RAIDS) do
    if raid.key == key then
      return raid
    end
  end
  return nil
end

-- Cataclysm raid difficulty IDs (fallback/confirmation when maxPlayers is missing or ambiguous).
RaidTracker.DIFF_10N = 3
RaidTracker.DIFF_25N = 4
RaidTracker.DIFF_10H = 5
RaidTracker.DIFF_25H = 6

-- Prefer InstanceMapID (locale-safe); fall back to localized name needles.
function RaidTracker.MatchRaid(instanceName, instanceMapID)
  local mapID = tonumber(instanceMapID)
  if mapID then
    for _, raid in ipairs(RaidTracker.RAIDS) do
      local ids = raid.instanceMapIDs
      if ids then
        for _, id in ipairs(ids) do
          if id == mapID then
            return raid
          end
        end
      end
    end
  end

  if not instanceName or instanceName == "" then
    return nil
  end
  local lower = instanceName:lower()
  for _, raid in ipairs(RaidTracker.RAIDS) do
    for _, needle in ipairs(raid.match or {}) do
      if lower:find(needle, 1, true) then
        return raid
      end
    end
  end
  return nil
end

function RaidTracker.MatchRaidByMapID(instanceMapID)
  return RaidTracker.MatchRaid(nil, instanceMapID)
end

function RaidTracker.SizeAndHeroic(difficultyId, maxPlayers, difficultyName)
  local size = tonumber(maxPlayers)
  local heroic = false

  if difficultyName then
    local dn = difficultyName:lower()
    if dn:find("heroic", 1, true) then
      heroic = true
    end
    if not size then
      local n = dn:match("(%d+)%s*player") or dn:match("(%d+)%s*man")
      size = n and tonumber(n) or nil
    end
  end

  if difficultyId == RaidTracker.DIFF_10N or difficultyId == RaidTracker.DIFF_10H then
    size = 10
  elseif difficultyId == RaidTracker.DIFF_25N or difficultyId == RaidTracker.DIFF_25H then
    size = 25
  end

  if difficultyId == RaidTracker.DIFF_10H or difficultyId == RaidTracker.DIFF_25H then
    heroic = true
  elseif GetDifficultyInfo then
    local _, _, isHeroic, _, displayHeroic = GetDifficultyInfo(difficultyId)
    if isHeroic or displayHeroic then
      heroic = true
    end
  end

  if size ~= 10 and size ~= 25 then
    size = size or 10
  end

  return size, heroic
end
