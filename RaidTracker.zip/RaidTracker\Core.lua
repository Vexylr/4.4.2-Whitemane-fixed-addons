--[[
  RaidTracker — weekly raid completion tracking (pre/post reset)
]]

local ADDON = ...
RaidTracker = RaidTracker or {}

local RT = RaidTracker
local db

local DEFAULTS = {
  point = "CENTER",
  relPoint = "CENTER",
  x = 0,
  y = 0,
  scale = 1,
  theme = "elvui",
  selectedChar = nil,
  weekId = nil, -- server-time stamp of the upcoming weekly reset when last saved
  characters = {},
  -- Account-wide: raid keys (FL, DS) unlocked by entering that instance once.
  visitedRaids = {},
}

local function Now()
  if GetServerTime then
    return GetServerTime()
  end
  return time()
end

local function CharKey()
  local name = UnitName("player")
  local realm = GetRealmName()
  if not name then
    return nil
  end
  return name .. "-" .. (realm or "?")
end

local function DeepCopyDefaults()
  local t = {}
  for k, v in pairs(DEFAULTS) do
    if type(v) == "table" then
      t[k] = {}
    else
      t[k] = v
    end
  end
  return t
end

local function EnsureDB()
  if type(RaidTrackerDB) ~= "table" then
    RaidTrackerDB = DeepCopyDefaults()
  end
  db = RaidTrackerDB
  for k, v in pairs(DEFAULTS) do
    if db[k] == nil then
      if type(v) == "table" then
        db[k] = {}
      else
        db[k] = v
      end
    end
  end
  if type(db.characters) ~= "table" then
    db.characters = {}
  end
  if type(db.visitedRaids) ~= "table" then
    db.visitedRaids = {}
  end
  return db
end

function RT.GetDB()
  return EnsureDB()
end

function RT.IsRaidVisited(key)
  EnsureDB()
  return not not (key and db.visitedRaids[key])
end

-- Persist unlock; returns true if this call newly unlocked the raid.
function RT.MarkRaidVisited(key, opts)
  opts = opts or {}
  EnsureDB()
  local raid = RT.RaidByKey and RT.RaidByKey(key)
  if not raid or not raid.requiresVisit then
    return false
  end
  if db.visitedRaids[key] then
    return false
  end
  db.visitedRaids[key] = true
  if not opts.silent then
    RT.Print((raid.name or key) .. " unlocked — now tracking weekly lockouts.")
  end
  if RT.UI and RT.UI.OnActiveRaidsChanged then
    RT.UI:OnActiveRaidsChanged()
  end
  return true
end

-- True once every requiresVisit raid is unlocked (stop retrying).
local function AllVisitRaidsUnlocked()
  for _, raid in ipairs(RT.RAIDS) do
    if raid.requiresVisit and not RT.IsRaidVisited(raid.key) then
      return false
    end
  end
  return true
end

-- Entering Firelands / Dragon Soul unlocks it.
-- Primary key: InstanceMapID (720 / 967). Name match is fallback only.
-- Returns true if currently inside a matched requiresVisit raid (already or newly unlocked).
function RT.CheckInstanceVisit()
  if not GetInstanceInfo then
    return false
  end

  local name, instanceType, _, _, _, _, _, instanceMapID = GetInstanceInfo()
  local inInstance, inType
  if IsInInstance then
    inInstance, inType = IsInInstance()
  end

  -- Map-ID path: locale-safe; accept even if type string is briefly inconsistent.
  local raid = RT.MatchRaid(nil, instanceMapID)
  if raid and raid.requiresVisit then
    RT.MarkRaidVisited(raid.key)
    return true
  end

  -- Name fallback only when we are clearly inside a raid instance.
  local looksLikeRaid = (instanceType == "raid")
    or (inInstance and inType == "raid")
  if looksLikeRaid and name and name ~= "" then
    raid = RT.MatchRaid(name)
    if raid and raid.requiresVisit then
      RT.MarkRaidVisited(raid.key)
      return true
    end
  end

  return false
end

-- Zoning can briefly report stale instance data. Retry a few times after enter.
local visitRetryToken = 0
local VISIT_RETRY_DELAYS = { 0, 0.25, 1.0, 3.0 }

local function After(delay, fn)
  if delay <= 0 then
    fn()
    return
  end
  if C_Timer and C_Timer.After then
    C_Timer.After(delay, fn)
    return
  end
  local f = CreateFrame("Frame")
  local t = 0
  f:SetScript("OnUpdate", function(self, elapsed)
    t = t + elapsed
    if t >= delay then
      self:SetScript("OnUpdate", nil)
      fn()
    end
  end)
end

function RT.ScheduleInstanceVisitChecks()
  if AllVisitRaidsUnlocked() then
    return
  end
  visitRetryToken = visitRetryToken + 1
  local token = visitRetryToken
  for _, delay in ipairs(VISIT_RETRY_DELAYS) do
    After(delay, function()
      if token ~= visitRetryToken then
        return
      end
      if AllVisitRaidsUnlocked() then
        return
      end
      EnsureDB()
      RT.CheckInstanceVisit()
    end)
  end
end

-- If the account already has a saved lockout for FL/DS, treat it as visited.
function RT.UnlockFromSavedInstances()
  local n = GetNumSavedInstances and GetNumSavedInstances() or 0
  for i = 1, n do
    local name, _, _, _, _, _, _, isRaid = GetSavedInstanceInfo(i)
    if isRaid and name then
      local raid = RT.MatchRaid(name)
      if raid and raid.requiresVisit then
        RT.MarkRaidVisited(raid.key, { silent = true })
      end
    end
  end
end

-- Also unlock from any alt's cached lockout data (entered before this build).
function RT.UnlockFromCachedLockouts()
  EnsureDB()
  if type(db.characters) ~= "table" then
    return
  end
  for _, char in pairs(db.characters) do
    local lockouts = char and char.lockouts
    if type(lockouts) == "table" then
      for _, sizeKey in ipairs({ "10", "25" }) do
        local side = lockouts[sizeKey]
        if type(side) == "table" then
          for key, modes in pairs(side) do
            local raid = RT.RaidByKey(key)
            if raid and raid.requiresVisit and type(modes) == "table" then
              for _, mode in ipairs({ "N", "H" }) do
                local slot = modes[mode]
                if slot and slot.locked then
                  RT.MarkRaidVisited(key, { silent = true })
                  break
                end
              end
            end
          end
        end
      end
    end
  end
end

function RT.GetSelectedThemeId()
  EnsureDB()
  local id = db.theme or RT.DEFAULT_THEME or "elvui"
  if not RT.THEMES[id] then
    id = RT.DEFAULT_THEME or "elvui"
  end
  return id
end

function RT.SetTheme(id)
  EnsureDB()
  if not RT.THEMES[id] then
    return false
  end
  db.theme = id
  if RT.UI and RT.UI.ApplyTheme then
    RT.UI:ApplyTheme()
  end
  return true
end

function RT.Print(msg)
  local theme = RT.GetTheme(RT.GetSelectedThemeId())
  local hex = (theme and theme.titleHex) or "1784d1"
  DEFAULT_CHAT_FRAME:AddMessage("|cff" .. hex .. "RaidTracker|r: " .. tostring(msg))
end

-- Whitemane server clock: fixed GMT+2 (Paris). Weekly raid reset = Wednesday 11:00.
-- Do NOT use C_DateAndTime.GetSecondsUntilWeeklyReset — that follows Blizzard US (Tuesday).
local SERVER_UTC_OFFSET = 2 * 3600
local WEEKLY_RESET_WDAY = 4 -- Wednesday (Lua date: 1=Sunday … 7=Saturday)
local WEEKLY_RESET_HOUR = 11
local WEEKLY_RESET_MIN = 0

function RT.GetWeeklyResetSeconds()
  local now = Now()
  -- Shift into server wall-clock, then read components as if UTC.
  local st = date("!*t", now + SERVER_UTC_OFFSET)
  local secondsIntoDay = st.hour * 3600 + st.min * 60 + st.sec
  local resetIntoDay = WEEKLY_RESET_HOUR * 3600 + WEEKLY_RESET_MIN * 60

  local daysUntil = (WEEKLY_RESET_WDAY - st.wday) % 7
  if daysUntil == 0 and secondsIntoDay >= resetIntoDay then
    daysUntil = 7
  end

  return daysUntil * 86400 - secondsIntoDay + resetIntoDay
end

-- Stable id for "this raid week": unix time of the next weekly reset.
-- Returns nil when the weekly-reset API is unavailable (avoids mismatched fallbacks).
function RT.GetWeekId()
  local untilReset = RT.GetWeeklyResetSeconds()
  if untilReset then
    return Now() + untilReset
  end
  return nil
end

function RT.FormatDuration(seconds)
  seconds = math.max(0, math.floor(tonumber(seconds) or 0))
  if seconds <= 0 then
    return "0m"
  end
  local d = math.floor(seconds / 86400)
  local h = math.floor((seconds % 86400) / 3600)
  local m = math.floor((seconds % 3600) / 60)
  if d > 0 then
    return string.format("%dd %dh", d, h)
  end
  if h > 0 then
    return string.format("%dh %dm", h, m)
  end
  return string.format("%dm", m)
end

function RT.FormatReset(seconds)
  return RT.FormatDuration(seconds)
end

-- Current raid week bounds from last weekly reset → next weekly reset.
function RT.GetWeekBounds()
  local untilReset = RT.GetWeeklyResetSeconds()
  if not untilReset then
    return nil, nil
  end
  local weekSecs = 7 * 24 * 3600
  local weekEnd = Now() + untilReset
  return weekEnd - weekSecs, weekEnd
end

-- Pretty label: "08-01 / 08-07"
function RT.FormatWeekLabel()
  local weekStart, weekEnd = RT.GetWeekBounds()
  if not weekStart or not weekEnd then
    return "— / —"
  end
  local endDay = weekEnd - 1
  return string.format("%s / %s", date("%m-%d", weekStart), date("%m-%d", endDay))
end

local function EmptySlot(expected)
  return {
    locked = false,
    status = "OPEN", -- OPEN | PARTIAL | DONE
    killed = 0,
    total = expected or 0,
    reset = 0,
    resetAt = 0, -- absolute server time when this lockout expires
    extended = false,
    bosses = {},
    difficultyName = nil,
  }
end

local function BuildEmptyLockouts()
  local lockouts = { ["10"] = {}, ["25"] = {} }
  for _, raid in ipairs(RT.RAIDS) do
    lockouts["10"][raid.key] = {
      N = EmptySlot(raid.encountersN),
      H = raid.encountersH and EmptySlot(raid.encountersH) or nil,
    }
    lockouts["25"][raid.key] = {
      N = EmptySlot(raid.encountersN),
      H = raid.encountersH and EmptySlot(raid.encountersH) or nil,
    }
  end
  return lockouts
end

local function SlotStatus(killed, total, locked)
  if not locked then
    return "OPEN"
  end
  if total > 0 and killed >= total then
    return "DONE"
  end
  -- Locked but not fully cleared — includes 0 kills (just entered/locked this week).
  return "PARTIAL"
end

local function ScanBosses(instanceIndex, numEncounters)
  local bosses = {}
  local killed = 0
  local total = numEncounters or 0
  if GetSavedInstanceEncounterInfo and total > 0 then
    for e = 1, total do
      local bossName, _, isKilled = GetSavedInstanceEncounterInfo(instanceIndex, e)
      bosses[e] = {
        name = bossName or ("Boss " .. e),
        killed = not not isKilled,
      }
      if isKilled then
        killed = killed + 1
      end
    end
  end
  return bosses, killed, total
end

function RT.ScanLockouts()
  local lockouts = BuildEmptyLockouts()
  local extras = { ["10"] = {}, ["25"] = {} }
  local now = Now()

  local n = GetNumSavedInstances and GetNumSavedInstances() or 0
  for i = 1, n do
    local name, _, reset, difficultyId, locked, extended, _, isRaid, maxPlayers, difficultyName, numEncounters, encounterProgress =
      GetSavedInstanceInfo(i)

    -- Only active lockouts count as "done this week".
    if isRaid and name and locked then
      local size, heroic = RT.SizeAndHeroic(difficultyId, maxPlayers, difficultyName)
      local sizeKey = tostring(size)
      local side = lockouts[sizeKey]
      local raid = RT.MatchRaid(name)
      local bosses, killed, total = ScanBosses(i, numEncounters)

      -- No per-boss data (numEncounters missing/0): fall back to the instance's
      -- overall encounter-progress counter for the kill count.
      if total == 0 and encounterProgress and encounterProgress > 0 then
        killed = encounterProgress
      end

      local expected = raid and (heroic and raid.encountersH or raid.encountersN) or 0
      total = total > 0 and total or expected
      local resetSec = tonumber(reset) or 0
      local resetAt = resetSec > 0 and (now + resetSec) or 0

      local slot = {
        locked = true,
        status = SlotStatus(killed, total, true),
        killed = killed,
        total = total,
        reset = resetSec,
        resetAt = resetAt,
        extended = not not extended,
        bosses = bosses,
        difficultyName = difficultyName,
        instanceName = name,
      }

      if raid and side[raid.key] then
        local mode = heroic and "H" or "N"
        if mode == "H" and not side[raid.key].H then
          mode = "N"
        end
        side[raid.key][mode] = slot
      else
        extras[sizeKey][#extras[sizeKey] + 1] = {
          key = "EXTRA" .. i,
          tag = name:sub(1, 8),
          name = name,
          N = not heroic and slot or EmptySlot(0),
          H = heroic and slot or nil,
        }
      end
    end
  end

  return lockouts, extras
end

-- After weekly reset, expired lockouts become OPEN again (for alts / cached data).
-- Only trust absolute resetAt — relative `reset` countdowns go stale for offline alts
-- and must not wipe Hel's DONE state while you're logged into Karma.
function RT.ExpireStaleLockouts(lockouts)
  if type(lockouts) ~= "table" then
    return lockouts
  end
  local now = Now()
  for _, sizeKey in ipairs({ "10", "25" }) do
    local side = lockouts[sizeKey]
    if type(side) == "table" then
      for _, modes in pairs(side) do
        for _, mode in ipairs({ "N", "H" }) do
          local slot = modes and modes[mode]
          if slot and slot.locked then
            if slot.resetAt and slot.resetAt > 0 and slot.resetAt <= now then
              modes[mode] = EmptySlot(slot.total or 0)
            elseif slot.resetAt and slot.resetAt > now then
              slot.reset = slot.resetAt - now
              slot.status = SlotStatus(slot.killed or 0, slot.total or 0, true)
            elseif slot.status ~= "DONE" and slot.status ~= "PARTIAL" and slot.status ~= "OPEN" then
              slot.status = SlotStatus(slot.killed or 0, slot.total or 0, true)
            end
          elseif slot and not slot.status then
            slot.status = slot.locked and SlotStatus(slot.killed or 0, slot.total or 0, true) or "OPEN"
          end
        end
      end
    end
  end
  return lockouts
end

-- Clears a single locked slot only if its lockout is not clearly still in the
-- future — used during the once-per-week rollover sweep below, where any
-- lockout without a definite future resetAt is treated as stale.
local function ClearSlotIfPast(slot, expected, now)
  if not slot or not slot.locked then
    return slot
  end
  if slot.resetAt and slot.resetAt > now then
    return slot
  end
  return EmptySlot(expected or slot.total)
end

-- Expires both the matched-raid lockouts and any unmatched "extra" instance
-- lockouts for one character's saved data (both share the same {10,25} shape).
local function ExpireCharacterLockouts(data)
  if not data then
    return
  end
  if data.lockouts then
    RT.ExpireStaleLockouts(data.lockouts)
  end
  if data.extras then
    RT.ExpireStaleLockouts(data.extras)
  end
end

-- If the account crossed a weekly reset since last save, wipe cached lockouts for alts
-- that haven't logged in yet this week (so we don't show last week's DONE forever).
function RT.ApplyWeeklyRollover()
  EnsureDB()
  local weekId = RT.GetWeekId()
  if not weekId then
    return false
  end
  if not db.weekId then
    db.weekId = weekId
    return false
  end
  -- weekId is "time of next reset". When that moment passes, next GetWeekId jumps ~7d ahead.
  if weekId <= (db.weekId + 60) then
    return false
  end

  local now = Now()
  for _, data in pairs(db.characters) do
    if data then
      ExpireCharacterLockouts(data)
      -- New raid week: clear lockouts that no longer have a future resetAt.
      if data.lockouts then
        for _, sizeKey in ipairs({ "10", "25" }) do
          local side = data.lockouts[sizeKey]
          if side then
            for _, raid in ipairs(RT.RAIDS) do
              local modes = side[raid.key]
              if modes then
                modes.N = ClearSlotIfPast(modes.N, raid.encountersN, now)
                if modes.H then
                  modes.H = ClearSlotIfPast(modes.H, raid.encountersH, now)
                end
              end
            end
          end
        end
      end
      data.weekId = weekId
    end
  end
  db.weekId = weekId
  return true
end

-- Always writes the LOGGED-IN character only. Never touches other alts' rows.
-- RaidTrackerDB is ## SavedVariables (account-wide), so Hel's lockouts stay
-- visible while you are logged into Karma.
function RT.SaveCurrentCharacter()
  EnsureDB()
  RT.ApplyWeeklyRollover()
  local key = CharKey()
  if not key then
    return
  end

  local _, classFile = UnitClass("player")
  local lockouts, extras = RT.ScanLockouts()
  local weekId = RT.GetWeekId()

  db.characters[key] = {
    name = UnitName("player"),
    realm = GetRealmName(),
    class = classFile,
    updated = Now(),
    weekId = weekId,
    lockouts = lockouts,
    extras = extras,
  }
  if weekId then
    db.weekId = weekId
  end

  -- Do not force-select the logged-in char; viewer may be looking at an alt.
  if not db.selectedChar then
    db.selectedChar = key
  end

  return db.characters[key]
end

function RT.GetCharacterList()
  EnsureDB()
  local me = CharKey()
  local list = {}
  for key, data in pairs(db.characters) do
    if type(data) == "table" and data.name then
      list[#list + 1] = { key = key, data = data }
    end
  end
  table.sort(list, function(a, b)
    -- Logged-in character first, then A–Z by name.
    if me then
      if a.key == me and b.key ~= me then
        return true
      end
      if b.key == me and a.key ~= me then
        return false
      end
    end
    local an = (a.data and a.data.name) or a.key
    local bn = (b.data and b.data.name) or b.key
    return an:lower() < bn:lower()
  end)
  return list
end

function RT.CharKey()
  return CharKey()
end

function RT.GetSelectedCharacter()
  EnsureDB()
  RT.ApplyWeeklyRollover()
  local me = CharKey()
  local key = db.selectedChar or me
  local data = key and db.characters[key]

  -- Selected char has no saved data (e.g. stale selection) — fall back to
  -- the logged-in character, then to whoever sorts first in the list.
  if not data and me then
    key, data = me, db.characters[me]
  end
  if not data then
    local list = RT.GetCharacterList()
    if list[1] then
      key, data = list[1].key, list[1].data
    end
  end

  ExpireCharacterLockouts(data)
  return key or me, data
end

function RT.SelectCharacter(key)
  EnsureDB()
  if key and db.characters[key] then
    db.selectedChar = key
    return true
  end
  return false
end

function RT.ProgressFraction(slot)
  if not slot or not slot.locked then
    return nil
  end
  local total = slot.total or 0
  local killed = slot.killed or 0
  if total <= 0 then
    return string.format("%d", killed)
  end
  return string.format("%d/%d", killed, total)
end

-- Weekly status label for a difficulty slot.
function RT.SlotLabel(slot, expected)
  if not slot or not slot.locked or slot.status == "OPEN" then
    return "OPEN", "OPEN"
  end
  if slot.status == "DONE" or (slot.total > 0 and slot.killed >= slot.total) then
    return "DONE", "DONE"
  end
  return "PARTIAL", "PARTIAL"
end

local frame = CreateFrame("Frame")
frame:RegisterEvent("ADDON_LOADED")
frame:RegisterEvent("PLAYER_LOGIN")
frame:RegisterEvent("UPDATE_INSTANCE_INFO")
frame:RegisterEvent("PLAYER_ENTERING_WORLD")
frame:RegisterEvent("ZONE_CHANGED_NEW_AREA")
frame:RegisterEvent("ZONE_CHANGED_INDOORS")
frame:RegisterEvent("ENCOUNTER_END")
frame:RegisterEvent("BOSS_KILL")

frame:SetScript("OnEvent", function(_, event, arg1)
  if event == "ADDON_LOADED" and arg1 == ADDON then
    EnsureDB()
  elseif event == "PLAYER_LOGIN" then
    EnsureDB()
    RT.ApplyWeeklyRollover()
    RT.UnlockFromCachedLockouts()
    RT.ScheduleInstanceVisitChecks()
    if RequestRaidInfo then
      RequestRaidInfo()
    end
  elseif event == "PLAYER_ENTERING_WORLD"
    or event == "ZONE_CHANGED_NEW_AREA"
    or event == "ZONE_CHANGED_INDOORS"
  then
    EnsureDB()
    RT.ScheduleInstanceVisitChecks()
    if event == "PLAYER_ENTERING_WORLD" then
      RT.ApplyWeeklyRollover()
      if RequestRaidInfo then
        RequestRaidInfo()
      end
    end
  elseif event == "UPDATE_INSTANCE_INFO" then
    -- Late retry: instance APIs + saved lockouts are both ready here.
    RT.CheckInstanceVisit()
    RT.ScheduleInstanceVisitChecks()
    RT.UnlockFromSavedInstances()
    if not RT.IsTestMode() then
      RT.SaveCurrentCharacter()
    end
    if RT.UI and RT.UI.Refresh and RT.UI.IsShown and RT.UI:IsShown() then
      -- skipSave keeps /rt test rows from being replaced by a real scan mid-demo.
      RT.UI:Refresh({ skipSave = true })
    end
  elseif event == "ENCOUNTER_END" or event == "BOSS_KILL" then
    RT.CheckInstanceVisit()
    if RequestRaidInfo then
      RequestRaidInfo()
    end
  end
end)

-- Demo lockouts for /rt test — not written to SavedVariables.
function RT.IsTestMode()
  return not not RT.testMode
end

function RT.SetTestMode(on)
  RT.testMode = not not on
  return RT.testMode
end

local function BossListFor(raid, heroic)
  if not raid then
    return nil
  end
  if heroic and raid.bossesH then
    return raid.bossesH
  end
  return raid.bossesN or raid.bossesH
end

local function TestSlot(killed, total, locked, bossNames)
  local resetSec = RT.GetWeeklyResetSeconds() or (3 * 24 * 3600)
  local resetAt = Now() + resetSec
  if not locked then
    return {
      locked = false,
      status = "OPEN",
      killed = 0,
      total = total or 0,
      reset = 0,
      resetAt = 0,
      extended = false,
      bosses = {},
    }
  end
  if bossNames and #bossNames > 0 then
    total = #bossNames
  else
    total = total or 0
  end
  killed = math.max(0, math.min(killed or 0, total))
  local bosses = {}
  for i = 1, total do
    bosses[i] = {
      name = (bossNames and bossNames[i]) or ("Boss " .. i),
      killed = i <= killed,
    }
  end
  local status = "PARTIAL"
  if total > 0 and killed >= total then
    status = "DONE"
  elseif killed <= 0 then
    status = "PARTIAL"
  end
  return {
    locked = true,
    status = status,
    killed = killed,
    total = total,
    reset = resetSec,
    resetAt = resetAt,
    extended = false,
    bosses = bosses,
    difficultyName = "Test",
  }
end

local function TestRaidSlot(raid, killed, locked, heroic)
  local names = BossListFor(raid, heroic)
  local total = heroic and (raid.encountersH or 0) or (raid.encountersN or 0)
  return TestSlot(killed, total, locked, names)
end

function RT.BuildTestLockouts()
  -- Mix of OPEN / PARTIAL / DONE across 10 and 25 so themes are easy to judge.
  local lockouts = { ["10"] = {}, ["25"] = {} }
  local byKey = {}
  for _, raid in ipairs(RT.RAIDS) do
    byKey[raid.key] = raid
    lockouts["10"][raid.key] = {
      N = TestRaidSlot(raid, 0, false, false),
      H = raid.encountersH and TestRaidSlot(raid, 0, false, true) or nil,
    }
    lockouts["25"][raid.key] = {
      N = TestRaidSlot(raid, 0, false, false),
      H = raid.encountersH and TestRaidSlot(raid, 0, false, true) or nil,
    }
  end

  local function set(size, key, mode, killed, locked)
    local raid = byKey[key]
    if not raid or not lockouts[size][key] then
      return
    end
    lockouts[size][key][mode] = TestRaidSlot(raid, killed, locked, mode == "H")
  end

  -- 10-man demo
  set("10", "BH", "N", 3, true)      -- DONE
  set("10", "BWD", "N", 3, true)     -- PARTIAL
  set("10", "BWD", "H", 6, true)     -- DONE
  set("10", "BOT", "N", 0, false)    -- OPEN
  set("10", "BOT", "H", 2, true)     -- PARTIAL
  set("10", "TOT4W", "N", 2, true)   -- DONE
  set("10", "TOT4W", "H", 0, false)  -- OPEN

  -- 25-man demo (different pattern)
  set("25", "BH", "N", 1, true)      -- PARTIAL
  set("25", "BWD", "N", 6, true)     -- DONE
  set("25", "BWD", "H", 2, true)     -- PARTIAL
  set("25", "BOT", "N", 4, true)     -- DONE
  set("25", "BOT", "H", 0, false)    -- OPEN
  set("25", "TOT4W", "N", 0, false)  -- OPEN
  set("25", "TOT4W", "H", 1, true)   -- PARTIAL

  -- FL / DS test data (rows still hidden until visitedRaids unlock)
  set("10", "FL", "N", 4, true)
  set("10", "FL", "H", 0, false)
  set("10", "DS", "N", 0, false)
  set("10", "DS", "H", 3, true)
  set("25", "FL", "N", 7, true)
  set("25", "FL", "H", 2, true)
  set("25", "DS", "N", 5, true)
  set("25", "DS", "H", 8, true)

  return lockouts
end

SLASH_RAIDTRACKER1 = "/rt"
SLASH_RAIDTRACKER2 = "/raidtracker"
SLASH_RAIDTRACKER3 = "/raidtrack"
SlashCmdList.RAIDTRACKER = function(msg)
  msg = (msg or ""):lower():match("^%s*(.-)%s*$")
  if msg == "reset" then
    EnsureDB()
    db.point, db.relPoint, db.x, db.y = "CENTER", "CENTER", 0, 0
    db.scale = 1
    if RT.UI and RT.UI.ApplyPosition then
      RT.UI:ApplyPosition()
    end
    RT.Print("Window position reset.")
    return
  end
  if msg == "refresh" then
    if RequestRaidInfo then
      RequestRaidInfo()
    end
    RT.Print("Refreshing weekly lockouts…")
    return
  end
  if msg == "week" then
    local s = RT.GetWeeklyResetSeconds()
    if s then
      RT.Print("Weekly reset in " .. RT.FormatDuration(s))
    else
      RT.Print("Weekly reset timer unavailable.")
    end
    return
  end
  if msg == "test" or msg == "test on" then
    RT.SetTestMode(true)
    RT.Print("Test mode ON — fake OPEN / PARTIAL / DONE lockouts. |cffff6666Not saved.|r")
    if RT.UI then
      if RT.UI.ResetTicker then
        RT.UI:ResetTicker()
      end
      if not RT.UI:IsShown() then
        RT.UI:Toggle()
      else
        RT.UI:Refresh({ skipSave = true })
      end
    end
    return
  end
  if msg == "test off" or msg == "test real" then
    RT.SetTestMode(false)
    RT.Print("Test mode OFF — showing real lockouts.")
    if RT.UI and RT.UI.Refresh then
      if RT.UI.ResetTicker then
        RT.UI:ResetTicker()
      end
      RT.UI:Refresh()
    end
    return
  end
  local themeId = msg:match("^theme%s+(.+)$")
  if themeId then
    themeId = themeId:lower():gsub("%s+", "")
    if RT.SetTheme(themeId) then
      RT.Print("Theme: " .. (RT.GetTheme(themeId).label or themeId))
    else
      RT.Print("Unknown theme. Try: elvui, bwd, fl, rainforest, thunderstorm, warlock, …")
    end
    return
  end
  if RT.UI and RT.UI.Toggle then
    RT.UI:Toggle()
  end
end
