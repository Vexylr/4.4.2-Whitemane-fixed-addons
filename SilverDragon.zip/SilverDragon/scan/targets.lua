local myname, ns = ...

local core = LibStub("AceAddon-3.0"):GetAddon("SilverDragon")
local module = core:NewModule("Scan_Targets", "AceEvent-3.0")
local Debug = core.Debug

local HBD = LibStub("HereBeDragons-2.0")

local UnitExists, UnitIsVisible, UnitPlayerControlled, UnitName, UnitLevel, UnitCreatureType, UnitGUID = UnitExists, UnitIsVisible, UnitPlayerControlled, UnitName, UnitLevel, UnitCreatureType, UnitGUID
function module:OnInitialize()
	self.db = core.db:RegisterNamespace("Scan_Targets", {
		profile = {
			mouseover = true,
			targets = true,
			nameplate = true,
			-- Classic/Cata private servers often omit the rare UnitClassification flag.
			rare_only = not ns.CLASSIC,
		},
	})
	-- "Dead rares" used to live here as well as on Announce, two switches with the
	-- same name in different sections. Core's covers both now. It defaulted on, so
	-- a stored value here only ever means it was turned off.
	if self.db.profile.dead ~= nil then
		if not self.db.profile.dead then
			core.db.profile.dead = false
		end
		self.db.profile.dead = nil
	end

	local config = core:GetModule("Config", true)
	if config then
		config.options.args.scanning.plugins.targets = {
			targets = {
				type = "group",
				name = "Targets",
				get = function(info) return self.db.profile[info[#info]] end,
				set = function(info, v) self.db.profile[info[#info]] = v end,
				args = {
					mouseover = config.toggle("Mouseover", "Check mobs that you mouse over.", 10),
					targets = config.toggle("Targets", "Check the targets of people in your group.", 20),
					nameplate = config.toggle("Nameplates", "Check units whose nameplates appear.", 30),
					rare_only = config.toggle("Rare only", "Only look for mobs that are still flagged as rare", 40),
				},
			},
		}
	end
end

function module:OnEnable()
	core.RegisterCallback(self, "Scan")

	self:RegisterEvent("PLAYER_TARGET_CHANGED")
	self:RegisterEvent("UPDATE_MOUSEOVER_UNIT")
	self:RegisterEvent("NAME_PLATE_UNIT_ADDED")
end

function module:PLAYER_TARGET_CHANGED()
	self:ProcessUnit('target', 'target')
end

function module:UPDATE_MOUSEOVER_UNIT()
	self:ProcessUnit('mouseover', 'mouseover')
end

function module:NAME_PLATE_UNIT_ADDED(event, unit)
	self:ProcessUnit(unit, 'nameplate')
end

function module:Scan(callback, zone)
	if not (self.db.profile.targets and IsInGroup()) then
		return
	end
	self:ProcessUnit('targettarget', 'grouptarget')
	local prefix = IsInRaid() and 'raid' or 'party'
	for i=1, GetNumGroupMembers() do
		self:ProcessUnit(prefix .. i .. 'target', 'grouptarget')
	end
end

--Rares not actually flagged as rare
local rare_nonflags = {
	[3868] = true, -- Blood Seeker
	[49822] = true, -- Jadefang
	[49913] = true, -- Lady La-La
	[50005] = true, -- Poseidus
	[50009] = true, -- Mobus
	[50050] = true, -- Shok'sharak
	[50051] = true, -- Ghostcrawler
	[50052] = true, -- Burgy Blackheart
	[50053] = true, -- Thartuk the Exile
	[50056] = true, -- Garr
	[50057] = true, -- Blazewing
	[50058] = true, -- Terrorpene
	[50059] = true, -- Golgarok
	[50060] = true, -- Terborus
	[50061] = true, -- Xariona
	[50062] = true, -- Aeonaxx
	[50063] = true, -- Akma'hat
	[50064] = true, -- Cyrus the Black
	[50065] = true, -- Armagedillo
	[50085] = true, -- Overlord Sunderfury
	[50086] = true, -- Tarvus the Vile
	[50089] = true, -- Julak-Doom
	[50138] = true, -- Karoma
	[50154] = true, -- Madexx
	[50159] = true, -- Sambas
	[50409] = true, -- Mysterious Camel Figurine
	[50959] = true, -- Karkin
	[51236] = true, -- Aeonaxx (engaged)
	[51401] = true, -- Madexx
	[51402] = true, -- Madexx
	[51403] = true, -- Madexx
	[51404] = true, -- Madexx
	[54318] = true, -- Ankha
	[54319] = true, -- Magria
	[54320] = true, -- Ban'thalos
	[58336] = true, -- Darkmoon Rabbit
	[62346] = true, -- Galleon
	[69161] = true, -- Oondasta
}

function module:ProcessUnit(unit, source)
	if not UnitExists(unit) then return end
	if not UnitIsVisible(unit) then return end
	local id = core:UnitID(unit)
	if not id then return end
	local zone = HBD:GetPlayerZone()
	if not zone then return end -- there are only a few places where this will happen
	if UnitPlayerControlled(unit) and not core:IsCustom(id, zone) then return end -- helps filter out player-pets
	local unittype = UnitClassification(unit)
	local is_rare = (id and rare_nonflags[id]) or (unittype == 'rare' or unittype == 'rareelite')
	local is_dead = UnitIsDead(unit)
	if is_dead and not core.db.profile.dead then return end
	local should_process = false

	if core:IsCustom(id, zone) then
		-- Manually-added mobs: always get announced
		should_process = true
	elseif is_rare then
		-- It's actually rare, so it gets announced
		should_process = true
	elseif ns.mobdb[id] then
		-- It's a known mob, but no longer flagged as rare, so we announce based on the setting
		should_process = not self.db.profile.rare_only
	end

	if should_process then
		-- from this point on, it's a rare
		-- Prime the name cache
		core:NameForMob(id, unit)

		local x, y = HBD:GetPlayerZonePosition()

		if
			(source == 'target' and not self.db.profile.targets)
			or (source == 'mouseover' and not self.db.profile.mouseover)
			or (source == 'nameplate' and not self.db.profile.nameplate)
		then
			return
		end

		-- id, zone, x, y, is_dead, source, unit, silent, force, GUID
		core:NotifyForMob(id, zone, x, y, is_dead, source or 'target', unit, false, false, UnitGUID(unit))
	end
end
