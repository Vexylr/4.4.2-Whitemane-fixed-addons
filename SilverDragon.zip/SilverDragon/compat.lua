-- Whitemane Cata Classic 4.4.2 (Interface 40402) shims.
-- Loaded first so Ace/LibSink/C_AddOns call sites do not nil-error.
local _, ns = ...

local toc = tonumber(select(4, GetBuildInfo()) or 0) or 0
ns.CATA_CLASSIC = toc >= 40000 and toc < 50000

if not C_AddOns then
	C_AddOns = {}
end
C_AddOns.GetAddOnMetadata = C_AddOns.GetAddOnMetadata or GetAddOnMetadata
C_AddOns.GetAddOnInfo = C_AddOns.GetAddOnInfo or GetAddOnInfo
C_AddOns.IsAddOnLoaded = C_AddOns.IsAddOnLoaded or IsAddOnLoaded
C_AddOns.EnableAddOn = C_AddOns.EnableAddOn or EnableAddOn
C_AddOns.LoadAddOn = C_AddOns.LoadAddOn or LoadAddOn

if not C_ChatInfo then
	C_ChatInfo = {}
end
if not C_ChatInfo.SendChatMessage and SendChatMessage then
	C_ChatInfo.SendChatMessage = SendChatMessage
end

if not C_Timer then
	C_Timer = {}
end
if not C_Timer.After then
	local holder = CreateFrame("Frame")
	local waiters = {}
	holder:SetScript("OnUpdate", function(_, elapsed)
		local i = 1
		while i <= #waiters do
			local w = waiters[i]
			w.t = w.t - elapsed
			if w.t <= 0 then
				table.remove(waiters, i)
				if w.rep and not w.cancelled then
					w.t = w.dur
					waiters[#waiters + 1] = w
				end
				if not w.cancelled then
					pcall(w.fn)
				end
			else
				i = i + 1
			end
		end
	end)
	local function handle(delay, fn, rep)
		local w = { t = delay, dur = delay, fn = fn, rep = rep, cancelled = false }
		waiters[#waiters + 1] = w
		return {
			Cancel = function()
				w.cancelled = true
			end,
		}
	end
	function C_Timer.After(delay, fn)
		handle(delay, fn, false)
	end
	function C_Timer.NewTicker(interval, fn)
		return handle(interval, fn, true)
	end
	function C_Timer.NewTimer(delay, fn)
		return handle(delay, fn, false)
	end
end

if not C_EventUtils then
	C_EventUtils = {}
end
if not C_EventUtils.IsEventValid then
	function C_EventUtils.IsEventValid(event)
		if event == "VIGNETTE_MINIMAP_UPDATED" then
			return not not (C_VignetteInfo and C_VignetteInfo.GetVignettes)
		end
		if event == "UNIT_DIED" or event == "PLAYER_LOGIN" or event == "ADDON_LOADED" then
			return true
		end
		if event == "RECEIVED_ACHIEVEMENT_LIST" then
			return not not GetAchievementInfo
		end
		return false
	end
end

if not CreateAtlasMarkup then
	function CreateAtlasMarkup()
		return ""
	end
end
